# -*- coding: utf-8 -*-
"""thang_form.py - Form WinForms (pyRevit 7, CPython 3).
MB co hinh bac + mui ten LEN; MC co dim, gach cat be tong, dam, thep dung ky hieu VN.
Moi so lieu tren hinh la O VANG: bam vao de sua. Dam / thep co khung nhap rieng ben phai.
Dung COMPOSITION (khong ke thua Form) de tranh rac roi pythonnet.
"""
import json
import math
import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
from System import Array
from System.Drawing import Color, Font, Pen, SolidBrush, PointF, Size, Point
from System.Drawing.Drawing2D import SmoothingMode, DashStyle, HatchBrush, HatchStyle
from System.Windows.Forms import (Form, Panel, Button, Label, TextBox, ComboBox, CheckBox,
                                  GroupBox, TabControl, TabPage, DockStyle, FlatStyle,
                                  FormStartPosition, ComboBoxStyle, SaveFileDialog,
                                  DialogResult, BorderStyle, MessageBox, Keys, Cursors,
                                  MouseButtons)
import System.Reflection as _refl

import thang_model as M

XANH = Color.FromArgb(30, 136, 229)
DEN = Color.FromArgb(20, 20, 20)
DO = Color.FromArgb(220, 30, 30)
NEN = Color.FromArgb(244, 246, 250)

SO_DUONG = ("rong", "dai", "so_bac", "day", "day_cn_dau", "day_cn_cuoi")   # phai > 0
SO_KHONG_AM = ("cn_dau", "cn_cuoi")                                         # phai >= 0
LOAI_DAM = ["Dầm chân thang", "Dầm giữa thang", "Dầm đầu thang"]
KEY_DAM = ["chan", "giua", "dau"]


def _fmt(v):
    try:
        if abs(v - round(v)) < 1e-6:
            return "%d" % round(v)
        return "%.1f" % v
    except Exception:
        return str(v)


def _dbuf(ctrl):
    try:
        pi = ctrl.GetType().GetProperty(
            "DoubleBuffered", _refl.BindingFlags.Instance | _refl.BindingFlags.NonPublic)
        pi.SetValue(ctrl, True, None)
    except Exception:
        pass


def _pts(lst):
    return Array[PointF]([PointF(float(x), float(y)) for x, y in lst])


def _fit(points, w, h, pad=40.0):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    bw, bh = max(maxx - minx, 1.0), max(maxy - miny, 1.0)
    k = min((w - 2 * pad) / bw, (h - 2 * pad) / bh)
    k = max(k, 1e-6)
    ox = (w - bw * k) / 2.0 - minx * k
    oy = (h - bh * k) / 2.0 + maxy * k
    return (lambda x, y: (ox + x * k, oy - y * k)), k


class HienThang(object):
    def __init__(self, thang):
        self.t = thang
        self.t.setdefault("dam", [])
        self.act = ("close", None)
        self.sel = 0
        self.dam_sel = None
        self._loading = False
        self.c = {}
        self.hits_mb = []
        self.hits_mc = {}
        self.pn_mc = []
        self.ed = None
        self._lay = []
        self._styled = []
        self._ui_scale = 1.0
        self._font_pt = 8.5
        self._in_layout = False
        self.zoom_mb = 1.0
        self.pan_mb = [0.0, 0.0]
        self.zoom_mc = {}
        self.pan_mc = {}
        self._drag = None
        self._suppress_click = False
        self.font = Font("Segoe UI", 8.5)
        self.fontb = Font("Segoe UI", 9.0)
        self.fontt = Font("Segoe UI", 8.0)
        # but / co ve dung chung (tao 1 lan)
        self.b_den = SolidBrush(DEN)
        self.b_xam = SolidBrush(Color.FromArgb(90, 90, 90))
        self.b_lbl = SolidBrush(Color.FromArgb(255, 250, 205))
        self.b_tinh = SolidBrush(Color.FromArgb(245, 245, 245))
        self.b_hud = SolidBrush(Color.FromArgb(242, 246, 252))
        self.b_leg = SolidBrush(Color.FromArgb(238, 255, 255, 255))
        self.p_lbl = Pen(Color.FromArgb(200, 170, 0), 1.0)
        self.p_tinh = Pen(Color.FromArgb(170, 170, 170), 1.0)
        self.p_hud = Pen(Color.FromArgb(180, 192, 210), 1.0)
        self.p_den = Pen(DEN, 1.0)
        self.p_den15 = Pen(DEN, 1.5)
        self.p_do = Pen(DO, 2.5)
        self.p_xanh3 = Pen(XANH, 3.0)
        self.p_den3 = Pen(DEN, 3.0)
        self.b_xanh = SolidBrush(XANH)
        self.b_cn = SolidBrush(Color.FromArgb(226, 230, 236))
        self.b_ve = SolidBrush(Color.FromArgb(214, 232, 250))
        self.p_buoc = Pen(Color.FromArgb(120, 150, 185), 1.0)
        self.p_len = Pen(Color.FromArgb(30, 100, 60), 2.0)
        self.b_len = SolidBrush(Color.FromArgb(30, 100, 60))
        self.b_be_tong = HatchBrush(HatchStyle.LightUpwardDiagonal, Color.FromArgb(170, 175, 185),
                                    Color.FromArgb(250, 251, 253))
        self.b_dam = HatchBrush(HatchStyle.DiagonalCross, Color.FromArgb(235, 150, 60),
                                Color.FromArgb(255, 238, 214))
        self.p_dam = Pen(Color.FromArgb(230, 120, 0), 1.5)
        self.p_dam_sel = Pen(Color.FromArgb(230, 120, 0), 3.0)
        self.p_t_duoi = Pen(Color.FromArgb(0, 70, 200), 2.5)
        self.p_t_tren = Pen(Color.FromArgb(200, 0, 0), 2.5)
        self.b_pb = SolidBrush(Color.FromArgb(0, 140, 70))
        self.b_trang = SolidBrush(Color.White)
        self.p_mb_duoi = Pen(Color.FromArgb(0, 70, 200), 1.0)
        self.p_mb_tren = Pen(Color.FromArgb(200, 0, 0), 1.0)
        self.p_mb_pb = Pen(Color.FromArgb(0, 140, 70), 1.0)
        self.p_dash = Pen(Color.Gray, 1.0)
        self.p_dash.DashStyle = DashStyle.Dash
        self.p_chain = Pen(DEN, 1.0)
        self.p_chain.DashStyle = DashStyle.DashDot
        self.p_chain_sel = Pen(XANH, 1.0)
        self.p_chain_sel.DashStyle = DashStyle.DashDot

        f = Form()
        self.f = f
        f.Text = "Vẽ cầu thang BTCT - nhận dạng từ Revit"
        f.ClientSize = Size(1480, 805)
        f.MinimumSize = Size(960, 680)
        f.MaximizeBox = True
        f.AutoScroll = False
        f.KeyPreview = True
        f.BackColor = NEN
        f.StartPosition = FormStartPosition.CenterScreen

        self._toolbar()
        self._khung()
        self._thong_so()
        self._nhom_dam()
        self._nhom_thep()
        self._nut_duoi()
        f.Resize += lambda s, e: self._bo_tri()
        f.KeyDown += self._on_form_key
        self._bo_tri()
        self.nap_tt()
        self.rebuild()

    # ---------------------------------------------------------------- dung UI
    def _reg(self, group, ctrl, x, y, w, h, fkind="norm"):
        self._lay.append((group, ctrl, float(x), float(y), float(w), float(h)))
        if fkind:
            ctrl.Font = self.font if fkind == "norm" else (self.fontb if fkind == "bold" else self.fontt)
            self._styled.append((ctrl, fkind))
        return ctrl

    def _gkey(self, parent):
        if parent is None or parent is self.f:
            return "top"
        if parent is getattr(self, "g_tt", None):
            return "tt"
        if parent is getattr(self, "g_dam", None):
            return "dam"
        if parent is getattr(self, "g_thep", None):
            return "thep"
        return "other"

    def _btn(self, text, x, y, w, fn, h=30, parent=None, chinh=False):
        b = Button()
        b.Text = text
        b.Location = Point(x, y)
        b.Size = Size(w, h)
        b.FlatStyle = FlatStyle.Flat
        if chinh:
            b.BackColor = XANH
            b.ForeColor = Color.White
        else:
            b.BackColor = Color.FromArgb(232, 238, 246)
        b.Click += fn
        (parent or self.f).Controls.Add(b)
        self._reg(self._gkey(parent), b, x, y, w, h, "norm")
        return b

    def _toolbar(self):
        self.btn_stairs = self._btn("Chọn Stairs", 10, 8, 110, lambda s, e: self._go("stairs"), 32, None, True)
        self.btn_gen = self._btn("Chọn Generic Model", 128, 8, 160, lambda s, e: self._go("generic"), 32, None, True)
        self.btn_tay = self._btn("Nhập tay (theo Loại thang)", 296, 8, 190, lambda s, e: self._go("tay", self.c["loai"].Text), 32)
        self.lb_nguon = Label()
        self.lb_nguon.Location = Point(500, 4)
        self.lb_nguon.Size = Size(970, 40)
        self.lb_nguon.Font = self.font
        self.f.Controls.Add(self.lb_nguon)
        self._styled.append((self.lb_nguon, "norm"))

    def _bind_canvas(self, pn, idx):
        _dbuf(pn)
        pn.Resize += lambda s, e: s.Invalidate()
        pn.MouseEnter += lambda s, e: self._on_enter(s)
        pn.MouseWheel += (lambda s, e, k=idx: self._on_wheel(s, e, k))
        pn.MouseDown += (lambda s, e, k=idx: self._on_down(s, e, k))
        pn.MouseMove += (lambda s, e, k=idx: self.move(s, e, k))
        pn.MouseUp += (lambda s, e, k=idx: self._on_up(s, e, k))
        pn.MouseDoubleClick += (lambda s, e, k=idx: self._on_dbl(s, e, k))
        pn.MouseClick += (lambda s, e, k=idx: self.click(s, e, k))

    def _khung(self):
        f = self.f
        self.pn_mb = Panel()
        self.pn_mb.Location = Point(10, 50)
        self.pn_mb.Size = Size(500, 496)
        self.pn_mb.BackColor = Color.White
        self.pn_mb.BorderStyle = BorderStyle.FixedSingle
        self.pn_mb.Paint += lambda s, e: self.paint_mb(e.Graphics, s)
        self._bind_canvas(self.pn_mb, -1)
        f.Controls.Add(self.pn_mb)

        self.tab = TabControl()
        self.tab.Location = Point(520, 50)
        self.tab.Size = Size(560, 496)
        self.tab.Font = self.font
        self._styled.append((self.tab, "norm"))
        self.tab.SelectedIndexChanged += self.on_tab
        f.Controls.Add(self.tab)

    def _lbl(self, parent, text, x, y, w=95):
        l = Label()
        l.Text = text
        l.Location = Point(x, y + 4)
        l.Size = Size(w, 20)
        l.Font = self.font
        parent.Controls.Add(l)
        self._reg(self._gkey(parent), l, x, y + 4, w, 20, "norm")

    def _txt(self, parent, key, label, x, y, w=140, lw=95):
        self._lbl(parent, label, x, y, lw)
        t = TextBox()
        t.Location = Point(x + lw + 3, y)
        t.Size = Size(w, 24)
        parent.Controls.Add(t)
        self._reg(self._gkey(parent), t, x + lw + 3, y, w, 24, "norm")
        self.c[key] = t
        return t

    def _cbo(self, parent, key, label, x, y, items, w=140, lw=95):
        self._lbl(parent, label, x, y, lw)
        c = ComboBox()
        c.DropDownStyle = ComboBoxStyle.DropDownList
        c.Location = Point(x + lw + 3, y)
        c.Size = Size(w, 24)
        for it in items:
            c.Items.Add(it)
        if items:
            c.SelectedIndex = 0
        parent.Controls.Add(c)
        self._reg(self._gkey(parent), c, x + lw + 3, y, w, 24, "norm")
        self.c[key] = c
        return c

    def _chk(self, parent, key, text, x, y, w=300):
        k = CheckBox()
        k.Text = text
        k.Location = Point(x, y)
        k.Size = Size(w, 24)
        k.Font = self.font
        parent.Controls.Add(k)
        self._reg(self._gkey(parent), k, x, y, w, 24, "norm")
        self.c[key] = k
        return k

    def _nhap(self, tb):
        """Nhap xong (roi o / Enter) -> ap dung."""
        tb.Leave += lambda s, e: self.on_thong_so()
        tb.KeyDown += self.on_thong_so_key

    def _thong_so(self):
        g = GroupBox()
        g.Text = "Thông tin thang"
        g.Location = Point(10, 556)
        g.Size = Size(1070, 190)
        self.f.Controls.Add(g)
        self.g_tt = g
        self._styled.append((g, "norm"))
        tl = ["1:10", "1:20", "1:25", "1:50", "1:100"]
        X1, X2, X3 = 15, 370, 725
        self._txt(g, "ten", "Tên thang :", X1, 24)
        self._txt(g, "so_luong", "Số lượng :", X1, 56)
        self._nhap(self._txt(g, "cote_chan", "Cote chân (m) :", X1, 88))
        self._cbo(g, "ty_le_mb", "Tỷ lệ MB :", X2, 24, tl)
        self._cbo(g, "loai", "Loại thang :", X2, 56, M.LOAI)
        tb = self._txt(g, "chia_bac", "Số bậc các vế :", X2, 88)
        tb.Leave += lambda s, e: self.on_chia()
        tb.KeyDown += self.on_chia_key
        self._cbo(g, "ty_le_mc", "Tỷ lệ MC :", X3, 24, tl)
        self._cbo(g, "kieu", "Kiểu bản thang :", X3, 56, ["Bản", "Dầm"])
        self._chk(g, "cat_thep", "Cắt thép (theo ×L ở khung Thép)", X3, 88, 300).CheckedChanged += lambda s, e: self.on_thong_so()
        self._chk(g, "thep_san_giong", "Thép sàn giống nhau", X1, 126)
        self._chk(g, "thep_ban_giong", "Thép bản thang giống nhau", X2, 126)
        self._chk(g, "khong_thep_mb", "Không bố trí thép MB", X3, 126)
        self._chk(g, "bac_dac_trung", "Chỉ vẽ bậc đặc trưng trên MC (nhấn mạnh bản thang)", X1, 156, 460).CheckedChanged += lambda s, e: self.on_thong_so()
        self.c["loai"].SelectedIndexChanged += self.on_loai

    # ---- khung DAM
    def _nhom_dam(self):
        g = GroupBox()
        g.Text = "Dầm thang (chân / giữa / đầu)"
        g.Location = Point(1090, 50)
        g.Size = Size(380, 274)
        self.f.Controls.Add(g)
        self.g_dam = g
        self._styled.append((g, "norm"))
        L = 135
        self._cbo(g, "dam_ds", "Dầm :", 12, 24, [], 212, L).SelectedIndexChanged += self.on_dam_ds
        self._cbo(g, "dam_loai", "Vị trí :", 12, 52, LOAI_DAM, 212, L).SelectedIndexChanged += self.on_dam_field_ev
        for key, lab, y in (("dam_b", "b - rộng (mm) :", 80), ("dam_h", "h - cao (mm) :", 108),
                            ("dam_z", "Cote đỉnh dầm (m) :", 136)):
            tb = self._txt(g, key, lab, 12, y, 212, L)
            tb.Leave += lambda s, e: self.on_dam_field()
            tb.KeyDown += self.on_dam_key
        self._cbo(g, "dam_ve", "Đặt ở vế :", 12, 164, [], 212, L).SelectedIndexChanged += self.on_dam_ve
        tb = self._txt(g, "dam_s", "Cách chân vế (mm) :", 12, 192, 212, L)
        tb.Leave += lambda s, e: self.on_dam_field()
        tb.KeyDown += self.on_dam_key
        self._btn("Thêm dầm", 12, 228, 112, lambda s, e: self.them_dam(), 32, g, True)
        self._btn("Xoá dầm", 132, 228, 100, lambda s, e: self.xoa_dam(), 32, g)
        self._btn("Quét dầm Revit", 240, 228, 128, lambda s, e: self._go("dam"), 32, g)

    # ---- khung THEP
    def _nhom_thep(self):
        g = GroupBox()
        g.Text = "Thép bản thang (TCVN 5574:2018)"
        g.Location = Point(1090, 332)
        g.Size = Size(380, 316)
        self.f.Controls.Add(g)
        self.g_thep = g
        self._styled.append((g, "norm"))
        A, B, lw, tw = 12, 196, 66, 74
        for key, lab, x, y in (("d_chu", "1  Ø (mm)", A, 22), ("a_chu", "1  a (mm)", B, 22),
                               ("d_mu", "2,3 Ø (mm)", A, 50), ("a_mu", "2,3 a (mm)", B, 50),
                               ("d_pb", "4  Ø (mm)", A, 78), ("a_pb", "4  a (mm)", B, 78),
                               ("cat_thep_l", "Mũ dài ×L₀", A, 106), ("abv", "Abv (mm)", B, 106)):
            self._nhap(self._txt(g, key, lab, x, y, tw, lw))
        self._nhap(self._txt(g, "neo", "Neo kéo/nén", A, 134, 74, 82))
        self._nhap(self._txt(g, "moc_d", "Móc (×d)", B, 134, tw, lw))
        for key, text, y in (("thep_duoi", "1  Thép chịu lực lớp dưới", 168),
                             ("thep_tren", "2,3  Thép mũ gối / lớp trên chiếu nghỉ", 192),
                             ("thep_pb", "4  Thép phân bố (đặt phía trong thép chính)", 216),
                             ("tach_goc_lom", "Bắt chéo nút gãy khúc (tách góc lõm TCVN)", 240),
                             ("thep_cn_suot", "Kéo thép chiếu nghỉ suốt ra dầm biên", 264)):
            k = self._chk(g, key, text, 12, y, 360)
            k.CheckedChanged += lambda s, e: self.on_thong_so()
        k = self._chk(g, "hien_thep", "HIỆN THÉP KIỂM TRA TRÊN HÌNH", 12, 288, 360)
        k.CheckedChanged += lambda s, e: self.on_thong_so()

    def _nut_duoi(self):
        b1 = Button()
        b1.Text = "Xuất dữ liệu (JSON)"
        b1.Location = Point(1090, 650)
        b1.Size = Size(180, 36)
        b1.FlatStyle = FlatStyle.Flat
        b1.BackColor = Color.FromArgb(232, 238, 246)
        b1.Click += lambda s, e: self.xuat_json()
        self.f.Controls.Add(b1)
        self.btn_json = b1
        self._styled.append((b1, "norm"))

        b2 = Button()
        b2.Text = "Đóng"
        b2.Location = Point(1280, 650)
        b2.Size = Size(190, 36)
        b2.FlatStyle = FlatStyle.Flat
        b2.BackColor = Color.FromArgb(232, 238, 246)
        b2.Click += lambda s, e: self._dong()
        self.f.Controls.Add(b2)
        self.btn_close = b2
        self._styled.append((b2, "norm"))

        l = Label()
        l.Text = "Bấm SỐ VÀNG để sửa | Lăn chuột: Zoom | Kéo chuột: Di chuyển | Nhấp đúp vùng trống: Vừa khung | Bấm dầm trên MC để chọn."
        l.Location = Point(10, 756)
        l.Size = Size(1070, 22)
        l.Font = self.font
        self.f.Controls.Add(l)
        self.lb_hd = l
        self._styled.append((l, "norm"))

    def _bo_tri(self):
        """Can chinh lai toan bo layout + co chu khi phong to / thu nho cua so."""
        if self._in_layout:
            return
        W = int(self.f.ClientSize.Width)
        H = int(self.f.ClientSize.Height)
        if W < 200 or H < 200:
            return
        self._in_layout = True
        try:
            self._ed_commit()
            s = max(0.86, min(W / 1480.0, H / 805.0, 1.45))
            self._ui_scale = s
            sc = lambda v: int(round(v * s))

            new_pt = max(7.5, round(8.5 * s * 2.0) / 2.0)
            if abs(new_pt - self._font_pt) >= 0.4:
                self._font_pt = new_pt
                old_f, old_fb, old_ft = self.font, self.fontb, self.fontt
                self.font = Font("Segoe UI", float(new_pt))
                self.fontb = Font("Segoe UI", float(new_pt + 0.5))
                self.fontt = Font("Segoe UI", float(max(7.0, new_pt - 0.5)))
                for ctrl, kind in self._styled:
                    try:
                        ctrl.Font = self.font if kind == "norm" else (self.fontb if kind == "bold" else self.fontt)
                    except Exception:
                        pass
                for of in (old_f, old_fb, old_ft):
                    try:
                        of.Dispose()
                    except Exception:
                        pass

            self.f.SuspendLayout()
            pad = sc(10)
            top_y = sc(50)
            rw = max(340, min(sc(380), int(W * 0.35)))
            tt_h = max(168, sc(190))
            tip_h = max(20, sc(22))
            draw_x = pad
            draw_w = max(460, W - rw - 3 * pad)
            draw_h = max(280, H - top_y - tt_h - tip_h - sc(22))
            mb_w = int((draw_w - pad) * 0.46)
            mc_w = draw_w - mb_w - pad

            self.pn_mb.Location = Point(draw_x, top_y)
            self.pn_mb.Size = Size(mb_w, draw_h)
            self.tab.Location = Point(draw_x + mb_w + pad, top_y)
            self.tab.Size = Size(mc_w, draw_h)

            self.g_tt.Location = Point(draw_x, top_y + draw_h + sc(8))
            self.g_tt.Size = Size(draw_w, tt_h)
            self.lb_hd.Location = Point(draw_x, top_y + draw_h + tt_h + sc(12))
            self.lb_hd.Size = Size(draw_w, tip_h)

            rx = draw_x + draw_w + pad
            right_tot = draw_h + sc(8) + tt_h
            btn_h = max(32, sc(36))
            avail_r = max(480, right_tot - btn_h - sc(18))
            dam_h = int(round(avail_r * 0.464))
            thep_h = avail_r - dam_h
            self.g_dam.Location = Point(rx, top_y)
            self.g_dam.Size = Size(rw, dam_h)
            self.g_thep.Location = Point(rx, top_y + dam_h + sc(8))
            self.g_thep.Size = Size(rw, thep_h)

            btn_y = top_y + dam_h + sc(8) + thep_h + sc(10)
            bw1 = int((rw - pad) * 0.49)
            self.btn_json.Location = Point(rx, btn_y)
            self.btn_json.Size = Size(bw1, btn_h)
            self.btn_close.Location = Point(rx + bw1 + pad, btn_y)
            self.btn_close.Size = Size(rw - bw1 - pad, btn_h)

            scales = {
                "top": (s, s),
                "tt": (draw_w / 1070.0, tt_h / 190.0),
                "dam": (rw / 380.0, dam_h / 274.0),
                "thep": (rw / 380.0, thep_h / 316.0),
            }
            for grp, ctrl, x0, y0, w0, h0 in self._lay:
                if grp not in scales:
                    continue
                sx, sy = scales[grp]
                ctrl.Location = Point(int(round(x0 * sx)), int(round(y0 * sy)))
                ctrl.Size = Size(max(20, int(round(w0 * sx))), max(16, int(round(h0 * sy))))

            nx = self.btn_tay.Right + sc(12)
            self.lb_nguon.Location = Point(nx, sc(4))
            self.lb_nguon.Size = Size(max(180, W - nx - pad), max(38, top_y - sc(8)))
            self.f.ResumeLayout(True)
            self.pn_mb.Invalidate()
            for pn in self.pn_mc:
                pn.Invalidate()
        finally:
            self._in_layout = False

    def _dong(self):
        self._ed_commit()
        self.f.Close()

    # ---------------------------------------------------------------- du lieu <-> UI
    def nap_tt(self):
        tt = self.t["tt"]
        self._loading = True
        for k in ("ten", "neo"):
            self.c[k].Text = str(tt[k])
        self.c["so_luong"].Text = str(tt["so_luong"])
        self.c["abv"].Text = _fmt(tt.get("abv", 20.0))
        self.c["moc_d"].Text = _fmt(tt.get("moc_d", 8.0))
        self.c["cat_thep_l"].Text = str(tt["cat_thep_l"])
        cc = tt.get("cote_chan")
        self.c["cote_chan"].Text = "" if cc is None else "%.3f" % (cc / 1000.0)
        for k, mac in (("d_chu", 12.0), ("a_chu", 150.0), ("d_mu", 10.0), ("a_mu", 150.0),
                       ("d_pb", 8.0), ("a_pb", 200.0)):
            self.c[k].Text = _fmt(tt.get(k, mac))
        for k in ("ty_le_mb", "ty_le_mc", "kieu"):
            self._chon(self.c[k], tt[k])
        for k in ("cat_thep", "thep_san_giong", "thep_ban_giong", "khong_thep_mb", "thep_tren",
                  "thep_duoi", "thep_pb", "tach_goc_lom", "thep_cn_suot", "hien_thep", "bac_dac_trung"):
            self.c[k].Checked = bool(tt.get(k, k in ("thep_pb", "tach_goc_lom", "thep_cn_suot", "hien_thep", "bac_dac_trung")))
        self._chon(self.c["loai"], self.t["loai"])
        self._loading = False

    def _chon(self, cb, text):
        for i in range(cb.Items.Count):
            if str(cb.Items[i]) == text:
                cb.SelectedIndex = i
                return

    @staticmethod
    def _so(text, mac_dinh):
        try:
            return float(str(text).replace(",", ".").replace("+", ""))
        except Exception:
            return mac_dinh

    @staticmethod
    def _cote_mm(v):
        """Nguoi dung go cote theo m (+3.600) - go so lon (>=200) thi hieu la mm."""
        return v * 1000.0 if abs(v) < 200.0 else v

    def doc_tt(self):
        tt = self.t["tt"]
        c = self.c
        tt["ten"] = c["ten"].Text
        tt["so_luong"] = int(self._so(c["so_luong"].Text, 1))
        tt["abv"] = self._so(c["abv"].Text, 20.0)
        tt["moc_d"] = self._so(c["moc_d"].Text, 8.0)
        tt["neo"] = c["neo"].Text
        tt["cat_thep_l"] = self._so(c["cat_thep_l"].Text, 0.25)
        for k in ("ty_le_mb", "ty_le_mc", "kieu"):
            tt[k] = str(c[k].Text)
        for k in ("cat_thep", "thep_san_giong", "thep_ban_giong", "khong_thep_mb", "thep_tren",
                  "thep_duoi", "thep_pb", "tach_goc_lom", "thep_cn_suot", "hien_thep", "bac_dac_trung"):
            tt[k] = bool(c[k].Checked)
        v = self._so(c["cote_chan"].Text, None)
        tt["cote_chan"] = None if v is None else self._cote_mm(v)
        for k, mac in (("d_chu", 12.0), ("a_chu", 150.0), ("d_mu", 10.0), ("a_mu", 150.0),
                       ("d_pb", 8.0), ("a_pb", 200.0)):
            tt[k] = max(1.0, self._so(c[k].Text, mac))
        self.t["loai"] = str(c["loai"].Text)

    def _nhan_nguon(self):
        kt = M.kiem_tra_tieu_chuan(self.t, min(self.sel, max(0, len(self.t["runs"]) - 1)))
        tc_txt = ""
        if kt["items"]:
            loi = [x["ten"] for x in kt["items"] if not x["dat"]]
            tc_txt = " | TCVN: %s (2h+b=%d, α=%.1f°)" % (
                "Đạt" if not loi else "Lưu ý: " + ", ".join(loi), round(kt["cong_thuc"]), kt["goc"])
        self.lb_nguon.Text = "Nguồn: %s  |  %d vế, %d chiếu nghỉ, %d dầm%s\n%s" % (
            self.t.get("nguon", ""), len(self.t["runs"]), len(self.t["landings"]),
            len(self.t.get("dam", [])), tc_txt, "; ".join(self.t.get("ghi_chu", [])))

    def rebuild(self):
        """Do lai cac tab MC + ve lai MB theo self.t (sau khi pick / nhap tay / doi loai)."""
        self._loading = True
        self._ed_commit(True)
        self._nhan_nguon()
        self.tab.TabPages.Clear()
        self.pn_mc = []
        self.hits_mc = {}
        for i in range(len(self.t["runs"])):
            pg = TabPage("MC %d-%d" % (i + 1, i + 1))
            pn = Panel()
            pn.Dock = DockStyle.Fill
            pn.BackColor = Color.White
            pn.Paint += (lambda s, e, k=i: self.paint_mc(e.Graphics, s, k))
            self._bind_canvas(pn, i)
            pg.Controls.Add(pn)
            self.pn_mc.append(pn)
            self.tab.TabPages.Add(pg)
        self.sel = 0
        if self.dam_sel is not None and self.dam_sel >= len(self.t.get("dam", [])):
            self.dam_sel = None
        self.c["chia_bac"].Text = "-".join(str(int(r["so_bac"])) for r in self.t["runs"])
        self._loading = False
        self.dam_nap()
        self.pn_mb.Invalidate()

    def ve_lai(self):
        self.c["chia_bac"].Text = "-".join(str(int(r["so_bac"])) for r in self.t["runs"])
        self._nhan_nguon()
        self.pn_mb.Invalidate()
        for pn in self.pn_mc:
            pn.Invalidate()

    # ---------------------------------------------------------------- su kien chung
    def _go(self, action, extra=None):
        self._ed_commit()
        self.doc_tt()
        self.act = (action, extra)
        self.f.Close()

    def on_thong_so(self):
        if self._loading:
            return
        self.doc_tt()
        self.ve_lai()

    def on_thong_so_key(self, s, e):
        if e.KeyCode == Keys.Enter:
            e.SuppressKeyPress = True
            self.on_thong_so()

    def on_loai(self, s, e):
        """Doi Loai thang -> dung lai thang tuong ung (1/2/3/4 ve, Chu L)."""
        if self._loading:
            return
        self._ed_commit()
        self.doc_tt()
        self.t = M.doi_loai(self.t, self.t["loai"])
        self.zoom_mb = 1.0
        self.pan_mb = [0.0, 0.0]
        self.zoom_mc = {}
        self.pan_mc = {}
        self.rebuild()

    def on_chia_key(self, s, e):
        if e.KeyCode == Keys.Enter:
            e.SuppressKeyPress = True
            self.on_chia()

    def on_chia(self):
        if self._loading:
            return
        txt = str(self.c["chia_bac"].Text).replace(",", "-").replace(" ", "-")
        try:
            chia = [int(x) for x in txt.split("-") if x.strip()]
        except Exception:
            chia = []
        cur = [int(r["so_bac"]) for r in self.t["runs"]]
        if chia == cur:
            return
        if len(chia) != len(cur) or any(c < 1 for c in chia):
            MessageBox.Show("Cần nhập đúng %d số bậc (mỗi số ≥ 1), ví dụ: %s" % (
                len(cur), "-".join(str(c) for c in cur)))
            self.c["chia_bac"].Text = "-".join(str(c) for c in cur)
            return
        self._ed_commit()
        self.doc_tt()
        self.t = M.doi_loai(self.t, self.t["loai"], chia)
        self.rebuild()

    def on_tab(self, s, e):
        if self._loading:
            return
        self.sel = max(0, self.tab.SelectedIndex)
        self.pn_mb.Invalidate()

    def xuat_json(self):
        self._ed_commit()
        self.doc_tt()
        dlg = SaveFileDialog()
        dlg.Filter = "JSON (*.json)|*.json"
        dlg.FileName = "thang_%s.json" % self.t["tt"]["ten"]
        if dlg.ShowDialog() == DialogResult.OK:
            with open(dlg.FileName, "w", encoding="utf-8") as fp:
                json.dump(self.t, fp, ensure_ascii=False, indent=2)
            MessageBox.Show("Đã lưu: " + dlg.FileName)

    # ---------------------------------------------------------------- khung DAM: logic
    def _ve_cua_dam(self, d):
        for i, r in enumerate(self.t["runs"]):
            if M.dam_hien_o_ve(r, d):
                return i
        return min(self.sel, len(self.t["runs"]) - 1)

    def _s_trong_ve(self, d, k):
        return M.dam_trong_ve(self.t["runs"][k], d)[0]

    def dam_nap(self):
        """Do danh sach dam va cac o nhap theo dam dang chon."""
        self._loading = True
        dams = self.t.get("dam", [])
        cb = self.c["dam_ds"]
        cb.Items.Clear()
        for j, d in enumerate(dams):
            cb.Items.Add("%d. %s  %s×%s" % (j + 1, M.DAM_TEN.get(d.get("vi_tri"), "Dầm"), _fmt(d["b"]), _fmt(d["h"])))
        cv = self.c["dam_ve"]
        cv.Items.Clear()
        for i in range(len(self.t["runs"])):
            cv.Items.Add("Vế %d" % (i + 1))
        j = self.dam_sel
        if j is not None and 0 <= j < len(dams):
            d = dams[j]
            cb.SelectedIndex = j
            if d.get("vi_tri") in KEY_DAM:
                self.c["dam_loai"].SelectedIndex = KEY_DAM.index(d["vi_tri"])
            self.c["dam_b"].Text = _fmt(d["b"])
            self.c["dam_h"].Text = _fmt(d["h"])
            self.c["dam_z"].Text = "%.3f" % (M.cote_mm(self.t, d["ztop"]) / 1000.0)
            k = self._ve_cua_dam(d)
            cv.SelectedIndex = k
            self.c["dam_s"].Text = _fmt(self._s_trong_ve(d, k))
        else:
            for key in ("dam_b", "dam_h", "dam_z", "dam_s"):
                self.c[key].Text = ""
        self._loading = False

    def on_dam_ds(self, s, e):
        if self._loading:
            return
        j = self.c["dam_ds"].SelectedIndex
        self.dam_sel = j if j >= 0 else None
        self.dam_nap()
        self.ve_lai()

    def on_dam_ve(self, s, e):
        """Doi 'Dat o ve' -> chi doi so hien thi, KHONG di chuyen dam."""
        if self._loading or self.dam_sel is None:
            return
        k = max(0, self.c["dam_ve"].SelectedIndex)
        d = self.t["dam"][self.dam_sel]
        self._loading = True
        self.c["dam_s"].Text = _fmt(self._s_trong_ve(d, k))
        self._loading = False

    def on_dam_key(self, s, e):
        if e.KeyCode == Keys.Enter:
            e.SuppressKeyPress = True
            self.on_dam_field()

    def on_dam_field_ev(self, s, e):
        self.on_dam_field()

    def on_dam_field(self):
        """Ap dung cac o nhap vao dam dang chon."""
        j = self.dam_sel
        if self._loading or j is None or not (0 <= j < len(self.t["dam"])):
            return
        d = self.t["dam"][j]
        foot = self.t["tt"].get("cote_chan") or 0.0
        b = self._so(self.c["dam_b"].Text, d["b"])
        h = self._so(self.c["dam_h"].Text, d["h"])
        if b > 0:
            d["b"] = b
        if h > 0:
            d["h"] = h
        z = self._so(self.c["dam_z"].Text, None)
        if z is not None:
            d["ztop"] = self._cote_mm(z) - foot
        k = max(0, self.c["dam_ve"].SelectedIndex)
        k = min(k, len(self.t["runs"]) - 1)
        sv = self._so(self.c["dam_s"].Text, None)
        if sv is not None and abs(sv - self._s_trong_ve(d, k)) > 0.6:
            M.dam_dat_s(self.t["runs"][k], d, sv)
        i = self.c["dam_loai"].SelectedIndex
        if 0 <= i < 3:
            d["vi_tri"] = KEY_DAM[i]
        self.dam_nap()
        self.ve_lai()

    def them_dam(self):
        self._ed_commit()
        self.doc_tt()
        i = self.c["dam_loai"].SelectedIndex
        vt = KEY_DAM[i] if 0 <= i < 3 else "chan"
        d = M.dam_moi(self.t, vt, self.sel)
        if d is None:
            MessageBox.Show("Chưa có vế nào để đặt dầm.")
            return
        self.t["dam"].append(d)
        self.dam_sel = len(self.t["dam"]) - 1
        self.dam_nap()
        self.ve_lai()

    def xoa_dam(self):
        self._ed_commit()
        j = self.dam_sel
        if j is None or not (0 <= j < len(self.t["dam"])):
            MessageBox.Show("Chọn 1 dầm trong danh sách (hoặc bấm vào dầm trên mặt cắt) trước khi xoá.")
            return
        del self.t["dam"][j]
        self.dam_sel = None
        self.dam_nap()
        self.ve_lai()

    # ---------------------------------------------------------------- zoom / pan
    def _get_vp(self, idx):
        if idx < 0:
            return self.zoom_mb, self.pan_mb, self.pn_mb
        z = self.zoom_mc.get(idx, 1.0)
        p = self.pan_mc.setdefault(idx, [0.0, 0.0])
        pn = self.pn_mc[idx] if 0 <= idx < len(self.pn_mc) else None
        return z, p, pn

    def _set_zoom(self, idx, new_z, ax=None, ay=None):
        z_old, pan, pn = self._get_vp(idx)
        z_new = max(0.35, min(12.0, float(new_z)))
        if pn is not None:
            if ax is None:
                ax = float(pn.ClientSize.Width) / 2.0
            if ay is None:
                ay = float(pn.ClientSize.Height) / 2.0
        else:
            ax, ay = 0.0, 0.0
        ratio = z_new / max(z_old, 1e-6)
        pan[0] = ax - (ax - pan[0]) * ratio
        pan[1] = ay - (ay - pan[1]) * ratio
        if idx < 0:
            self.zoom_mb = z_new
        else:
            self.zoom_mc[idx] = z_new
        if pn is not None:
            pn.Invalidate()

    def _reset_vp(self, idx):
        _z, pan, pn = self._get_vp(idx)
        pan[0] = 0.0
        pan[1] = 0.0
        if idx < 0:
            self.zoom_mb = 1.0
        else:
            self.zoom_mc[idx] = 1.0
        if pn is not None:
            pn.Invalidate()

    def _tf_vp(self, tf0, k0, idx):
        z, pan, _pn = self._get_vp(idx)
        px, py = pan[0], pan[1]

        def tf(x, y):
            bx, by = tf0(x, y)
            return (bx * z + px, by * z + py)

        return tf, k0 * z

    def _draw_zoom_hud(self, g, hits, W, idx):
        z, _pan, _pn = self._get_vp(idx)
        pct = "%d%%" % int(round(z * 100.0))
        btns = [
            ("-", "zoom_out", 24.0),
            (pct, "zoom_reset", 48.0),
            ("+", "zoom_in", 24.0),
            ("Vừa", "zoom_reset", 36.0),
        ]
        gap = 4.0
        tot_w = sum(w for _, _, w in btns) + gap * (len(btns) - 1)
        x = float(W) - tot_w - 8.0
        y = 8.0
        h = 22.0
        for txt, key, bw in btns:
            g.FillRectangle(self.b_hud, x, y, bw, h)
            g.DrawRectangle(self.p_hud, x, y, bw, h)
            sz = g.MeasureString(txt, self.fontt)
            g.DrawString(txt, self.fontt, self.b_den, x + (bw - float(sz.Width)) / 2.0, y + (h - float(sz.Height)) / 2.0)
            hits.append((x, y, bw, h, key, idx))
            x += bw + gap

    def _on_enter(self, pn):
        if self.ed is None and not isinstance(self.f.ActiveControl, (TextBox, ComboBox)):
            try:
                pn.Focus()
            except Exception:
                pass

    def _on_wheel(self, pn, e, idx):
        self._ed_commit()
        try:
            e.Handled = True
        except Exception:
            pass
        z, _p, _pn = self._get_vp(idx)
        factor = 1.15 if e.Delta > 0 else (1.0 / 1.15)
        self._set_zoom(idx, z * factor, float(e.X), float(e.Y))

    def _on_down(self, pn, e, idx):
        if e.Button in (MouseButtons.Left, MouseButtons.Middle):
            if self.ed is None:
                try:
                    pn.Focus()
                except Exception:
                    pass
            _z, pan, _pn = self._get_vp(idx)
            self._drag = [idx, e.X, e.Y, pan[0], pan[1], False]

    def _on_up(self, pn, e, idx):
        if self._drag and self._drag[0] == idx:
            if self._drag[5]:
                self._suppress_click = True
            self._drag = None
            pn.Cursor = Cursors.Hand if self._tim(idx, e) else Cursors.Default

    def _on_dbl(self, pn, e, idx):
        if not self._tim(idx, e):
            self._ed_commit()
            self._reset_vp(idx)

    def _on_form_key(self, s, e):
        if not e.Control or self.ed is not None:
            return
        if isinstance(self.f.ActiveControl, (TextBox, ComboBox)):
            return
        idx = -1 if self.f.ActiveControl is self.pn_mb else self.sel
        z, _p, _pn = self._get_vp(idx)
        if e.KeyCode in (Keys.Oemplus, Keys.Add):
            e.SuppressKeyPress = True
            self._set_zoom(idx, z * 1.2)
        elif e.KeyCode in (Keys.OemMinus, Keys.Subtract):
            e.SuppressKeyPress = True
            self._set_zoom(idx, z / 1.2)
        elif e.KeyCode in (Keys.D0, Keys.NumPad0):
            e.SuppressKeyPress = True
            self._reset_vp(idx)

    # ---------------------------------------------------------------- sua truc tiep tren hinh
    def _nhan(self, g, hits, text, cx, cy, key, idx, dau=""):
        txt = dau + text
        sz = g.MeasureString(txt, self.font)
        w = float(sz.Width) + 6.0
        h = float(sz.Height) + 2.0
        x = float(cx) - w / 2.0
        y = float(cy) - h / 2.0
        g.FillRectangle(self.b_lbl, x, y, w, h)
        g.DrawRectangle(self.p_lbl, x, y, w, h)
        g.DrawString(txt, self.font, self.b_den, x + 3.0, y + 1.0)
        hits.append((x, y, w, h, key, idx))

    def _nhan_tinh(self, g, text, cx, cy):
        sz = g.MeasureString(text, self.font)
        w = float(sz.Width) + 6.0
        h = float(sz.Height) + 2.0
        x = float(cx) - w / 2.0
        y = float(cy) - h / 2.0
        g.FillRectangle(self.b_tinh, x, y, w, h)
        g.DrawRectangle(self.p_tinh, x, y, w, h)
        g.DrawString(text, self.font, self.b_xam, x + 3.0, y + 1.0)

    def _tim(self, idx, e):
        hits = self.hits_mb if idx < 0 else self.hits_mc.get(idx, [])
        found = None
        for (x, y, w, h, key, ri) in hits:
            if x <= e.X <= x + w and y <= e.Y <= y + h:
                found = (x, y, w, h, key, ri)
        return found

    def move(self, pn, e, idx):
        if self._drag and self._drag[0] == idx:
            dx = e.X - self._drag[1]
            dy = e.Y - self._drag[2]
            if not self._drag[5] and (abs(dx) > 4 or abs(dy) > 4 or e.Button == MouseButtons.Middle):
                self._drag[5] = True
                self._ed_commit()
            if self._drag[5]:
                _z, pan, _p = self._get_vp(idx)
                pan[0] = self._drag[3] + dx
                pan[1] = self._drag[4] + dy
                pn.Cursor = Cursors.SizeAll
                pn.Invalidate()
                return
        pn.Cursor = Cursors.Hand if self._tim(idx, e) else Cursors.Default

    def click(self, pn, e, idx):
        if self._suppress_click:
            self._suppress_click = False
            return
        hit = self._tim(idx, e)
        self._ed_commit()
        if not hit:
            return
        x, y, w, h, key, ri = hit
        if key == "zoom_in":
            z, _p, _pn = self._get_vp(idx)
            self._set_zoom(idx, z * 1.25)
            return
        if key == "zoom_out":
            z, _p, _pn = self._get_vp(idx)
            self._set_zoom(idx, z / 1.25)
            return
        if key == "zoom_reset":
            self._reset_vp(idx)
            return
        if key == "dam_sel":
            self.dam_sel = ri
            self.dam_nap()
            self.ve_lai()
            return
        if key == "chon_ve":
            if ri < self.tab.TabPages.Count:
                self.tab.SelectedIndex = ri
            return
        if idx < 0 and ri < self.tab.TabPages.Count and self.tab.SelectedIndex != ri:
            self.tab.SelectedIndex = ri
        self.sua(pn, x, y, w, h, ri, key)

    def _gia_tri(self, ri, key):
        t = self.t
        if key == "cote_chan":
            return "%.3f" % ((t["tt"].get("cote_chan") or 0.0) / 1000.0)
        if key == "z1":
            return "%.3f" % (M.cote_mm(t, t["runs"][ri]["z1"]) / 1000.0)
        if key.startswith("dam_"):
            d = t["dam"][ri]
            if key == "dam_b":
                return _fmt(d["b"])
            if key == "dam_h":
                return _fmt(d["h"])
            if key == "dam_z":
                return "%.3f" % (M.cote_mm(t, d["ztop"]) / 1000.0)
            if key.startswith("dam_s:"):
                return _fmt(M.dam_trong_ve(t["runs"][int(key.split(":")[1])], d)[0])
        return _fmt(t["runs"][ri][key])

    def sua(self, pn, x, y, w, h, ri, key):
        tb = TextBox()
        tb.Font = self.fontb
        tb.Text = self._gia_tri(ri, key)
        tb.Size = Size(int(max(w, 70.0)), int(h) + 4)
        tb.Location = Point(int(x), int(y) - 2)
        pn.Controls.Add(tb)
        self.ed = (tb, pn, ri, key)
        tb.KeyDown += self._ed_key
        tb.Leave += (lambda s, e: self._ed_commit())
        tb.Focus()
        tb.SelectAll()

    def _ed_key(self, s, e):
        if e.KeyCode == Keys.Enter:
            e.SuppressKeyPress = True
            self._ed_commit()
        elif e.KeyCode == Keys.Escape:
            e.SuppressKeyPress = True
            self._ed_commit(True)

    def _ap_dung(self, ri, key, v):
        t = self.t
        foot = t["tt"].get("cote_chan") or 0.0
        if key == "cote_chan":
            t["tt"]["cote_chan"] = self._cote_mm(v)
            self.c["cote_chan"].Text = "%.3f" % (t["tt"]["cote_chan"] / 1000.0)
            return True
        if key == "z1":
            return M.doi_z1(t, ri, self._cote_mm(v) - foot)
        if key.startswith("dam_"):
            d = t["dam"][ri]
            if key == "dam_b" and v > 0:
                d["b"] = v
            elif key == "dam_h" and v > 0:
                d["h"] = v
            elif key == "dam_z":
                d["ztop"] = self._cote_mm(v) - foot
            elif key.startswith("dam_s:"):
                M.dam_dat_s(t["runs"][int(key.split(":")[1])], d, v)
            else:
                return False
            return True
        if key in SO_DUONG and v <= 0:
            return False
        if key in SO_KHONG_AM and v < 0:
            return False
        t["runs"][ri][key] = int(round(v)) if key == "so_bac" else v
        return True

    def _ed_commit(self, huy=False):
        ed = self.ed
        if ed is None:
            return
        self.ed = None
        tb, pn, ri, key = ed
        txt = str(tb.Text)
        try:
            pn.Controls.Remove(tb)
            tb.Dispose()
        except Exception:
            pass
        if huy:
            return
        v = self._so(txt, None)
        if v is None:
            return
        try:
            if self._ap_dung(ri, key, v):
                self.dam_nap()
                self.ve_lai()
        except Exception:
            pass

    # ---------------------------------------------------------------- ve phu tro
    def _huong(self, tf, p0, vec):
        """Vecto don vi tren man hinh ung voi huong vec (he mat bang)."""
        o = tf(p0[0], p0[1])
        q = tf(p0[0] + vec[0] * 100.0, p0[1] + vec[1] * 100.0)
        dx, dy = q[0] - o[0], q[1] - o[1]
        n = math.hypot(dx, dy) or 1.0
        return (dx / n, dy / n)

    def _dau_mui(self, g, ax, ay, dx, dy, pen, kich=8.0):
        for da in (2.6, -2.6):
            c, s_ = math.cos(da), math.sin(da)
            hx = dx * c - dy * s_
            hy = dx * s_ + dy * c
            g.DrawLine(pen, float(ax), float(ay), float(ax + hx * kich), float(ay + hy * kich))

    def _mui_ten_cat(self, g, ex, ey, ud, vd, vao_trong, pen, so):
        """1 dau ky hieu mat cat: doan day doc theo duong cat + mui ten chi huong NHIN + so hieu."""
        tx, ty = ex + ud[0] * 16.0 * vao_trong, ey + ud[1] * 16.0 * vao_trong
        g.DrawLine(pen, float(ex), float(ey), float(tx), float(ty))
        ax, ay = ex + vd[0] * 26.0, ey + vd[1] * 26.0
        g.DrawLine(self.p_den, float(ex), float(ey), float(ax), float(ay))
        self._dau_mui(g, ax, ay, -vd[0], -vd[1], self.p_den)
        g.DrawString(so, self.fontb, self.b_den, float(ax + vd[0] * 6.0 - 4.0), float(ay + vd[1] * 6.0 - 8.0))

    def _so_hieu(self, g, px, py, ox, oy, so, mau_but):
        """Vong tron danh so thep + duong dan toi thanh thep."""
        cx, cy = px + ox, py + oy
        n = math.hypot(ox, oy) or 1.0
        g.DrawLine(self.p_den, float(px), float(py), float(cx - ox / n * 10.0), float(cy - oy / n * 10.0))
        g.FillEllipse(self.b_trang, float(cx - 10), float(cy - 10), 20.0, 20.0)
        g.DrawEllipse(mau_but, float(cx - 10), float(cy - 10), 20.0, 20.0)
        f_tag = self.fontt if len(so) > 1 else self.fontb
        sz = g.MeasureString(so, f_tag)
        g.DrawString(so, f_tag, self.b_den, float(cx - float(sz.Width) / 2.0), float(cy - float(sz.Height) / 2.0))

    # ---------------------------------------------------------------- ve MB
    def paint_mb(self, g, panel):
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.Clear(Color.White)
        self.hits_mb = []
        runs = self.t["runs"]
        if not runs:
            return
        h = M.mb_hinh(self.t)
        dams = self.t.get("dam", [])
        allp = [p for poly in h["runs"] + h["landings"] for p in poly]
        for d in dams:
            allp.extend(M.dam_poly(d))
        W, H = panel.ClientSize.Width, panel.ClientSize.Height
        tf0, k0 = _fit(allp, W, H, 80.0)
        tf, k = self._tf_vp(tf0, k0, -1)
        for poly in h["landings"]:
            sp = [tf(x, y) for x, y in poly]
            g.FillPolygon(self.b_cn, _pts(sp))
            g.DrawPolygon(self.p_den, _pts(sp))
        for i, poly in enumerate(h["runs"]):
            sp = [tf(x, y) for x, y in poly]
            g.FillPolygon(self.b_ve, _pts(sp))
            xs_, ys_ = [q[0] for q in sp], [q[1] for q in sp]
            self.hits_mb.append((min(xs_), min(ys_), max(xs_) - min(xs_), max(ys_) - min(ys_), "chon_ve", i))
        # bac thang (uu tien canh bac 3D that tu Revit gom bac cheo winder) + mui ten LEN
        bac_3d = self.t.get("bac_ve_3d") or []
        if bac_3d:
            for a0, b0 in bac_3d:
                pa = tf(a0[0], a0[1])
                pb = tf(b0[0], b0[1])
                g.DrawLine(self.p_buoc, float(pa[0]), float(pa[1]), float(pb[0]), float(pb[1]))
        for i, r in enumerate(runs):
            u = r["u"]
            v = (-u[1], u[0])
            p0 = r["p0"]
            hw = r["rong"] / 2.0
            L = r["dai"]
            if not bac_3d:
                n = max(1, min(int(r["so_bac"]), 60))
                for j in range(1, n):
                    s_ = L * j / float(n)
                    a = tf(p0[0] + u[0] * s_ - v[0] * hw, p0[1] + u[1] * s_ - v[1] * hw)
                    b = tf(p0[0] + u[0] * s_ + v[0] * hw, p0[1] + u[1] * s_ + v[1] * hw)
                    g.DrawLine(self.p_buoc, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            a = tf(p0[0] + u[0] * L * 0.1 + v[0] * hw * 0.62, p0[1] + u[1] * L * 0.1 + v[1] * hw * 0.62)
            b = tf(p0[0] + u[0] * L * 0.9 + v[0] * hw * 0.62, p0[1] + u[1] * L * 0.9 + v[1] * hw * 0.62)
            g.DrawLine(self.p_len, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            ud = self._huong(tf, p0, u)
            self._dau_mui(g, b[0], b[1], -ud[0], -ud[1], self.p_len, 10.0)
            g.DrawString("LÊN", self.fontt, self.b_len, float(a[0] + 3), float(a[1] - 14))
        for poly in h["landings"]:
            sp = [tf(x, y) for x, y in poly]
            g.DrawPolygon(self.p_den, _pts(sp))
        for i, poly in enumerate(h["runs"]):
            sp = [tf(x, y) for x, y in poly]
            g.DrawPolygon(self.p_do if i == self.sel else self.p_den, _pts(sp))
        for j, d in enumerate(dams):
            sp = [tf(x, y) for x, y in M.dam_poly(d)]
            g.FillPolygon(self.b_dam, _pts(sp))
            g.DrawPolygon(self.p_dam_sel if j == self.dam_sel else self.p_dam, _pts(sp))
        # thep (xem tren mat bang)
        if self.t["tt"].get("hien_thep") and 0 <= self.sel < len(runs):
            try:
                self._thep_mb(g, tf, k, runs[self.sel])
            except Exception:
                pass
        # ky hieu mat cat: duong cat DOC THEO VE, 2 dau co mui ten chi huong nhin
        for i, r in enumerate(runs):
            u = r["u"]
            v = (-u[1], u[0])
            p0 = r["p0"]
            sel = (i == self.sel)
            cn_d_mb = r["cn_dau"] if r.get("_ve_cn_dau_mb", True) else 0.0
            cn_c_mb = r["cn_cuoi"] if r.get("_ve_cn_cuoi_mb", True) else 0.0
            a = tf(p0[0] - u[0] * (cn_d_mb + 280.0), p0[1] - u[1] * (cn_d_mb + 280.0))
            e1 = r["dai"] + cn_c_mb + 280.0
            b = tf(p0[0] + u[0] * e1, p0[1] + u[1] * e1)
            ud = self._huong(tf, p0, u)
            vd = self._huong(tf, p0, v)
            g.DrawLine(self.p_chain_sel if sel else self.p_chain, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            pen = self.p_xanh3 if sel else self.p_den3
            so = str(i + 1)
            self._mui_ten_cat(g, a[0], a[1], ud, vd, 1.0, pen, so)
            self._mui_ten_cat(g, b[0], b[1], ud, vd, -1.0, pen, so)
        # o sua so (gian cach chong chong de khong de nhau tren ve ngan)
        for i, r in enumerate(runs):
            u = r["u"]
            v = (-u[1], u[0])
            p0 = r["p0"]
            hw = r["rong"] / 2.0
            L = r["dai"]
            c = tf(p0[0] + u[0] * L / 2.0, p0[1] + u[1] * L / 2.0)
            if i != self.sel:
                g.DrawString("Vế %d" % (i + 1), self.fontb, self.b_xam, float(c[0] - 14), float(c[1] - 18))
                self._nhan_tinh(g, "%s bậc" % _fmt(r["so_bac"]), c[0], c[1] + 6)
                continue
            g.DrawString("Vế %d  (MC %d-%d)" % (i + 1, i + 1, i + 1), self.fontb, self.b_den, float(c[0] - 42), float(c[1] - 54))
            self._nhan(g, self.hits_mb, _fmt(r["so_bac"]), c[0], c[1] - 24, "so_bac", i, "Bậc ")
            self._nhan(g, self.hits_mb, _fmt(r["day"]), c[0], c[1], "day", i, "Dày ")
            self._nhan_tinh(g, "%s → %s" % (M.fmt_cote(M.cote_mm(self.t, r["z0"])),
                                            M.fmt_cote(M.cote_mm(self.t, r["z1"]))), c[0], c[1] + 24)
            ud = self._huong(tf, p0, u)
            vd = self._huong(tf, p0, v)
            o = tf(p0[0], p0[1])
            self._nhan(g, self.hits_mb, _fmt(r["rong"]), o[0] - ud[0] * 64.0, o[1] - ud[1] * 64.0, "rong", i, "Rộng ")
            pd = tf(p0[0] - v[0] * hw + u[0] * L / 2.0, p0[1] - v[1] * hw + u[1] * L / 2.0)
            self._nhan(g, self.hits_mb, _fmt(L), pd[0] - vd[0] * 46.0, pd[1] - vd[1] * 46.0, "dai", i, "Dài ")
        # Nhan chieu nghi co bac phu (Chieu 1: 2 bac, Chieu cuoi: 3 bac -> dam)
        z0_min = min(r["z0"] for r in runs)
        u0 = runs[0]["u"]
        v0 = (-u0[1], u0[0])
        for ld in self.t.get("landings", []):
            bac_ld = ld.get("bac")
            if not bac_ld:
                continue
            lpoly = ld.get("poly") or []
            if not lpoly:
                continue
            lx = sum(p[0] for p in lpoly) / len(lpoly)
            ly = sum(p[1] for p in lpoly) / len(lpoly)
            # Dich nhe sang ben de tranh de len duong cat 1-1 giua ve
            lc = tf(lx + v0[0] * 140.0, ly + v0[1] * 140.0)
            is_top_ld = ld.get("z", 0.0) > z0_min + 200.0
            lbl = "Chiếu cuối (%d bậc→dầm)" % int(bac_ld) if is_top_ld else "Chiếu 1 (%d bậc)" % int(bac_ld)
            self._nhan_tinh(g, lbl, lc[0], lc[1])
        self._draw_zoom_hud(g, self.hits_mb, W, -1)

    def _thep_mb(self, g, tf, k, r):
        """Ky hieu rai thep tren mat bang chuan VN (1 thanh dai dien + duong rai co cham/gach + ghi chu)."""
        tt = self.t["tt"]
        abv = float(tt.get("abv", 20.0))
        u = r["u"]
        v = (-u[1], u[0])
        p0 = r["p0"]
        hw = r["rong"] / 2.0
        L = r["dai"]
        c1 = max(0.15, min(float(tt.get("cat_thep_l", 0.25)), 0.45)) * L

        def P(s_, t_):
            return tf(p0[0] + u[0] * s_ + v[0] * t_, p0[1] + u[1] * s_ + v[1] * t_)

        if tt.get("thep_duoi", True):
            # 1 thanh chiu luc dai dien o t = -0.25*hw + duong rai ngang
            t_rep = -hw * 0.25
            a, b = P(-r["cn_dau"] * 0.6, t_rep), P(L + r["cn_cuoi"] * 0.4, t_rep)
            g.DrawLine(self.p_t_duoi, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            ra, rb = P(L * 0.28, -hw + abv), P(L * 0.28, hw - abv)
            g.DrawLine(self.p_mb_duoi, float(ra[0]), float(ra[1]), float(rb[0]), float(rb[1]))
            rx, ry = P(L * 0.28, t_rep)
            g.FillEllipse(self.b_xanh, float(rx - 3.5), float(ry - 3.5), 7.0, 7.0)
        if tt.get("thep_tren", True):
            t_mu = hw * 0.28
            for s0, s1 in ((-r["cn_dau"] * 0.35, c1), (L - c1, L + r["cn_cuoi"] * 0.35)):
                a, b = P(s0, t_mu), P(s1, t_mu)
                g.DrawLine(self.p_t_tren, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
        if tt.get("thep_pb", True):
            s_rep = L * 0.72
            a, b = P(s_rep, -hw + abv), P(s_rep, hw - abv)
            g.DrawLine(self.p_mb_pb, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            ra, rb = P(L * 0.45, 0.0), P(L * 0.92, 0.0)
            g.DrawLine(self.p_mb_pb, float(ra[0]), float(ra[1]), float(rb[0]), float(rb[1]))
            rx, ry = P(s_rep, 0.0)
            g.FillEllipse(self.b_pb, float(rx - 3.5), float(ry - 3.5), 7.0, 7.0)

    # ---------------------------------------------------------------- ve thep tren mat cat
    def _thep_mc(self, g, tf, k, r, m, dams, W, H, idx):
        res = M.tinh_thep_mc(self.t, r, dams)
        tt = self.t["tt"]
        L = r["dai"]
        z0, z1 = r["z0"], r["z1"]
        kk = res["kk"]

        for bar in res["bars"]:
            nhom = bar["nhom"]
            if nhom == "duoi" and not tt.get("thep_duoi", True):
                continue
            if nhom == "tren" and not tt.get("thep_tren", True):
                continue
            pen = self.p_t_duoi if nhom == "duoi" else self.p_t_tren
            g.DrawLines(pen, _pts([tf(x, y) for x, y in bar["pts"]]))

        if tt.get("thep_pb", True):
            rad = max(1.8, res["d3"] * k / 2.0)
            for s_, z_ in res["dots"]:
                x, y = tf(s_, z_)
                g.FillEllipse(self.b_pb, float(x - rad), float(y - rad), float(2 * rad), float(2 * rad))

        # so hieu thep
        bar_ids = set(b["id"] for b in res["bars"])
        if tt.get("thep_duoi", True) and "1" in bar_ids:
            x, y = tf(L * 0.52, res["zb0"] + kk * (L * 0.52))
            self._so_hieu(g, x, y, 4.0, 34.0, "1", self.p_t_duoi)
        if tt.get("thep_duoi", True) and "5" in bar_ids and r["cn_cuoi"] >= 250.0:
            s5 = L + min(r["cn_cuoi"] * 0.48, 260.0)
            x, y = tf(s5, z1 - float(r["day_cn_cuoi"]) + float(tt.get("abv", 20.0)))
            self._so_hieu(g, x, y, 12.0, 28.0, "5", self.p_t_duoi)
        if tt.get("thep_tren", True):
            c1 = res["c1"]
            if "2" in bar_ids:
                s2 = min(c1 * 0.5, L * 0.35)
                x, y = tf(s2, res["zt0_sl"] + kk * s2)
                self._so_hieu(g, x, y, 8.0, -30.0, "2", self.p_t_tren)
            if "2a" in bar_ids and r["cn_dau"] >= 220.0:
                s2a = -min(r["cn_dau"] * 0.38, 220.0)
                x, y = tf(s2a, z0 - float(tt.get("abv", 20.0)))
                self._so_hieu(g, x, y, -12.0, -28.0, "2a", self.p_t_tren)
            if "3" in bar_ids:
                s3 = max(L - c1 * 0.5, L * 0.65)
                x, y = tf(s3, res["zt0_sl"] + kk * s3)
                self._so_hieu(g, x, y, -8.0, -30.0, "3", self.p_t_tren)
            if "3a" in bar_ids and r["cn_cuoi"] >= 250.0:
                s3a = L + min(r["cn_cuoi"] * 0.38, 220.0)
                x, y = tf(s3a, z1 - float(tt.get("abv", 20.0)))
                self._so_hieu(g, x, y, 14.0, -28.0, "3a", self.p_t_tren)
        if tt.get("thep_pb", True) and res["dots"]:
            s_ = L * 0.25
            x, y = tf(s_, res["zb0"] + kk * s_ + (res["d1"] / 2.0 + res["d3"] / 2.0) / max(res["ca"], 0.2))
            self._so_hieu(g, x, y, -26.0, 34.0, "4", self.p_mb_pb)

        dong = [bar["mota"] for bar in res["bars"]
                if (bar["nhom"] == "duoi" and tt.get("thep_duoi", True))
                or (bar["nhom"] == "tren" and tt.get("thep_tren", True))]
        if tt.get("thep_pb", True):
            dong.append("4  Thép phân bố Ø%s a%s (đặt phía trong thép chịu lực)" % (_fmt(res["d3"]), _fmt(res["a3"])))
        lh = max(15.0, float(self.fontt.GetHeight()) + 2.0)
        if dong:
            bg_h = lh * len(dong) + 8.0
            y0 = float(H) - bg_h - 4.0
            g.FillRectangle(self.b_leg, 4.0, y0, float(W - 8), bg_h)
            y = y0 + 4.0
            for tx in dong:
                g.DrawString(tx, self.fontt, self.b_den, 8.0, y)
                y += lh

    # ---------------------------------------------------------------- ve MC
    def paint_mc(self, g, panel, idx):
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.Clear(Color.White)
        hits = []
        self.hits_mc[idx] = hits
        runs = self.t["runs"]
        if idx >= len(runs):
            return
        r = runs[idx]
        m = M.mc_hinh(r)
        out = m["outline"]
        dams = self.t.get("dam", [])
        W, H = panel.ClientSize.Width, panel.ClientSize.Height
        z_sd = r.get("z_san_dau")
        z_sc = r.get("z_san_cuoi")
        nb_dau = int(r.get("bac_cn_dau") or 0)
        nb_cuoi = int(r.get("bac_cn_cuoi") or 0)
        zt = max([p[1] for p in out] + ([z_sc] if (nb_cuoi > 0 and z_sc is not None) else []))
        zlow = min([p[1] for p in out] + ([z_sd] if (nb_dau > 0 and z_sd is not None) else []))
        hien_thep = bool(self.t["tt"].get("hien_thep"))
        pts_fit = out + [(out[0][0], zt + 650.0), (out[0][0], zlow - (1500.0 if hien_thep else 750.0))]
        for d in dams:
            if M.dam_hien_o_ve(r, d):
                s_, _t, _c = M.dam_trong_ve(r, d)
                pts_fit += [(s_ - d["b"] / 2.0, d["ztop"]), (s_ + d["b"] / 2.0, d["ztop"] - d["h"])]
        tf0, k0 = _fit(pts_fit, W, H, 55.0)
        tf, k = self._tf_vp(tf0, k0, idx)
        # dam (ve duoi ban thang)
        for j, d in enumerate(dams):
            if not M.dam_hien_o_ve(r, d):
                continue
            s_, _t, _c = M.dam_trong_ve(r, d)
            a = tf(s_ - d["b"] / 2.0, d["ztop"])
            b2 = tf(s_ + d["b"] / 2.0, d["ztop"] - d["h"])
            x, y = min(a[0], b2[0]), min(a[1], b2[1])
            w, hh = abs(b2[0] - a[0]), abs(b2[1] - a[1])
            g.FillRectangle(self.b_dam, float(x), float(y), float(w), float(hh))
            g.DrawRectangle(self.p_dam_sel if j == self.dam_sel else self.p_dam,
                            float(x), float(y), float(w), float(hh))
            g.DrawString("%s %s×%s" % (M.DAM_TEN.get(d.get("vi_tri"), "Dầm"), _fmt(d["b"]), _fmt(d["h"])),
                         self.fontt, self.b_den, float(x), float(y + hh + 2))
            hits.append((x, y, w, hh, "dam_sel", j))
        bac_dac_trung = bool(self.t["tt"].get("bac_dac_trung", True))
        n_bac = max(1, int(r["so_bac"]))
        if bac_dac_trung and n_bac > 4 and m.get("slab_outline"):
            slab_sp = [tf(x, y) for x, y in m["slab_outline"]]
            g_, h_ = m["g"], m["h"]
            z0_r, z1_r, L_r = r["z0"], r["z1"], r["dai"]
            bot_steps = [
                (0.0, z0_r), (0.0, z0_r + h_), (g_, z0_r + h_),
                (g_, z0_r + 2.0 * h_), (2.0 * g_, z0_r + 2.0 * h_),
            ]
            top_steps = [
                (L_r - 2.0 * g_, z1_r - 2.0 * h_), (L_r - g_, z1_r - 2.0 * h_),
                (L_r - g_, z1_r - h_), (L_r, z1_r - h_), (L_r, z1_r),
            ]
            bs_sp = [tf(x, y) for x, y in bot_steps]
            ts_sp = [tf(x, y) for x, y in top_steps]
            g.FillPolygon(self.b_be_tong, _pts(bs_sp))
            g.FillPolygon(self.b_be_tong, _pts(ts_sp))
            g.FillPolygon(self.b_be_tong, _pts(slab_sp))
            g.DrawLines(self.p_den15, _pts(bs_sp))
            g.DrawLines(self.p_den15, _pts(ts_sp))
            nose_a = tf(2.0 * g_, z0_r + 2.0 * h_)
            nose_b = tf(L_r - 2.0 * g_, z1_r - 2.0 * h_)
            g.DrawLine(self.p_dash, float(nose_a[0]), float(nose_a[1]), float(nose_b[0]), float(nose_b[1]))
            g.DrawPolygon(self.p_den15, _pts(slab_sp))
        else:
            sp = [tf(x, y) for x, y in out]
            g.FillPolygon(self.b_be_tong, _pts(sp))
            g.DrawPolygon(self.p_den15, _pts(sp))

        L, Lb, Lt = r["dai"], r["cn_dau"], r["cn_cuoi"]
        # Bac phu tren Chieu 1 (buoc tu san/chan len ban Chieu 1) va Chieu cuoi (buoc tu Chieu cuoi len dam/san tren)
        if nb_dau > 0 and z_sd is not None and z_sd < r["z0"] - 20.0 and Lb >= 200.0:
            w_d = min(Lb * 0.68, nb_dau * 250.0)
            s_d0 = -Lb
            sg_d = w_d / float(nb_dau)
            sh_d = (r["z0"] - z_sd) / float(nb_dau)
            aux_d = [(s_d0, z_sd)]
            for k_b in range(nb_dau):
                aux_d.append((s_d0 + k_b * sg_d, z_sd + (k_b + 1) * sh_d))
                aux_d.append((s_d0 + (k_b + 1) * sg_d, z_sd + (k_b + 1) * sh_d))
            g.DrawLines(self.p_buoc, _pts([tf(x, y) for x, y in aux_d]))
            pa_d = tf(s_d0, r["z0"] - r["day_cn_dau"])
            pb_d = tf(s_d0, z_sd)
            g.DrawLine(self.p_dash, float(pa_d[0]), float(pa_d[1]), float(pb_d[0]), float(pb_d[1]))
            lbl_d = tf(-Lb * 0.5, r["z0"] + 150.0)
            self._nhan_tinh(g, "Chiếu 1 (%d bậc)" % nb_dau, lbl_d[0], lbl_d[1])
        if nb_cuoi > 0 and z_sc is not None and z_sc > r["z1"] + 20.0 and Lt >= 200.0:
            s_c0 = L + min(180.0, Lt * 0.18)
            sg_c = (L + Lt - s_c0) / float(nb_cuoi)
            sh_c = (z_sc - r["z1"]) / float(nb_cuoi)
            aux_c = [(s_c0, r["z1"])]
            for k_b in range(nb_cuoi):
                aux_c.append((s_c0 + k_b * sg_c, r["z1"] + (k_b + 1) * sh_c))
                aux_c.append((s_c0 + (k_b + 1) * sg_c, r["z1"] + (k_b + 1) * sh_c))
            aux_c.append((L + Lt, r["z1"]))
            aux_sp = [tf(x, y) for x, y in aux_c]
            g.FillPolygon(self.b_be_tong, _pts(aux_sp))
            g.DrawPolygon(self.p_buoc, _pts(aux_sp))
            lbl_c = tf((s_c0 + L + Lt) * 0.5, z_sc + 130.0)
            self._nhan_tinh(g, "Chiếu cuối (%d bậc → lên dầm)" % nb_cuoi, lbl_c[0], lbl_c[1])

        for s in set([0.0, L] + ([-Lb] if Lb >= 20.0 else []) + ([L + Lt] if Lt >= 20.0 else [])):
            a = tf(s, zt + 350)
            b = tf(s, zlow - 100)
            g.DrawLine(self.p_dash, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
        # duong cao do + cote
        has_sd_cote = (nb_dau > 0 and z_sd is not None and z_sd < r["z0"] - 20.0)
        if has_sd_cote:
            a = tf(-Lb - 300, z_sd)
            b = tf(L + Lt + 300, z_sd)
            g.DrawLine(self.p_dash, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            txt = M.fmt_cote(M.cote_mm(self.t, z_sd))
            if idx == 0:
                self._nhan(g, hits, txt, a[0] + 40, a[1] - 11, "cote_chan", idx, "Cote ")
            else:
                self._nhan_tinh(g, "Cote " + txt, a[0] + 40, a[1] - 11)
        for z, key in ((r["z0"], "z0"), (r["z1"], "z1")):
            a = tf(-Lb - 300, z)
            b = tf(L + Lt + 300, z)
            g.DrawLine(self.p_dash, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            txt = M.fmt_cote(M.cote_mm(self.t, z))
            cx, cy = a[0] + 40, a[1] - 11
            if key == "z0" and idx == 0 and not has_sd_cote:
                self._nhan(g, hits, txt, cx, cy, "cote_chan", idx, "Cote ")
            elif key == "z1":
                self._nhan(g, hits, txt, cx, cy, "z1", idx, "Cote ")
            else:
                self._nhan_tinh(g, "Cote " + txt, cx, cy)
        if nb_cuoi > 0 and z_sc is not None and z_sc > r["z1"] + 20.0:
            a = tf(-Lb - 300, z_sc)
            b = tf(L + Lt + 300, z_sc)
            g.DrawLine(self.p_dash, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
            txt = M.fmt_cote(M.cote_mm(self.t, z_sc))
            self._nhan_tinh(g, "Cote " + txt + " (lên dầm)", a[0] + 55, a[1] - 11)
        # duong kich thuoc ngang co gach xien o 2 dau + so vang o giua
        yy = zt + 350
        for s0, s1, key in ((-Lb, 0.0, "cn_dau"), (0.0, L, "dai"), (L, L + Lt, "cn_cuoi")):
            if s1 - s0 >= 20.0:
                a, b = tf(s0, yy), tf(s1, yy)
                g.DrawLine(self.p_den, float(a[0]), float(a[1]), float(b[0]), float(b[1]))
                for (x, y) in (a, b):
                    g.DrawLine(self.p_den, float(x - 4), float(y + 4), float(x + 4), float(y - 4))
                c = tf((s0 + s1) / 2.0, yy)
                self._nhan(g, hits, _fmt(s1 - s0), c[0], c[1] - 12, key, idx, "")
            else:
                cx_, cy_ = tf(s0, yy)
                off_x = -24.0 if key == "cn_dau" else 24.0
                self._nhan(g, hits, "0", cx_ + off_x, cy_ - 12, key, idx, "CN ")
        # thep kiem tra (ve truoc cac o so de o so nam tren)
        if hien_thep:
            try:
                self._thep_mc(g, tf, k, r, m, dams, W, H, idx)
            except Exception:
                pass
        c = tf(L * 0.38, r["z0"] + (r["z1"] - r["z0"]) * 0.38 + 750.0)
        self._nhan(g, hits, _fmt(r["so_bac"]), c[0], c[1], "so_bac", idx, "Bậc ")
        c = tf(L * 0.6, r["z0"] + (r["z1"] - r["z0"]) * 0.6 - m["dayv"] - 450.0)
        if not hien_thep:
            self._nhan(g, hits, _fmt(r["day"]), c[0], c[1], "day", idx, "Dày ")
        else:
            self._nhan(g, hits, _fmt(r["day"]), c[0] + 55, c[1] - 6, "day", idx, "Dày ")
        if Lb >= 20.0:
            c = tf(-Lb / 2.0, r["z0"] - r["day_cn_dau"] - 400.0)
            self._nhan(g, hits, _fmt(r["day_cn_dau"]), c[0], c[1], "day_cn_dau", idx, "Dày ")
        if Lt >= 20.0:
            c = tf(L + Lt / 2.0, r["z1"] - r["day_cn_cuoi"] - 400.0)
            self._nhan(g, hits, _fmt(r["day_cn_cuoi"]), c[0], c[1], "day_cn_cuoi", idx, "Dày ")
        # o sua cua dam dang chon
        j = self.dam_sel
        if j is not None and 0 <= j < len(dams) and M.dam_hien_o_ve(r, dams[j]):
            d = dams[j]
            s_ = M.dam_trong_ve(r, d)[0]
            cx = W - 80.0
            y0 = float(H) * 0.40
            g.DrawString("Dầm đang chọn: %s" % M.DAM_TEN.get(d.get("vi_tri"), ""), self.fontb, self.b_den, float(W - 190), y0)
            self._nhan(g, hits, _fmt(d["b"]), cx, y0 + 32.0, "dam_b", j, "b ")
            self._nhan(g, hits, _fmt(d["h"]), cx, y0 + 56.0, "dam_h", j, "h ")
            self._nhan(g, hits, M.fmt_cote(M.cote_mm(self.t, d["ztop"])), cx, y0 + 80.0, "dam_z", j, "Cote đỉnh ")
            self._nhan(g, hits, _fmt(s_), cx, y0 + 104.0, "dam_s:%d" % idx, j, "Vị trí s ")
        head = "Mặt cắt %d-%d (nhìn theo mũi tên)  |  cao %s, bậc %s x %s" % (
            idx + 1, idx + 1, _fmt(r["z1"] - r["z0"]), _fmt(m["h"]), _fmt(m["g"]))
        sz_hd = g.MeasureString(head, self.fontb)
        g.FillRectangle(self.b_leg, 4.0, 4.0, float(sz_hd.Width) + 8.0, float(sz_hd.Height) + 4.0)
        g.DrawString(head, self.fontb, self.b_den, 8.0, 6.0)
        self._draw_zoom_hud(g, hits, W, idx)


def hien_form(thang):
    """Tra ve (hanh_dong, tham_so_them, thang). hanh_dong: stairs | generic | tay | dam | close"""
    h = HienThang(thang)
    h.f.ShowDialog()
    return h.act[0], h.act[1], h.t

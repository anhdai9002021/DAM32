# -*- coding: utf-8 -*-
"""thang_revit.py - Doc du lieu thang tu Revit 2025 (pyRevit 7, CPython 3).
Chi DOC, khong tao/sua gi trong model. Moi so lieu doi sang mm roi giao cho thang_model.
Ho tro:
- Stairs voi nhieu StairsRun rieng
- Stairs voi 1 StairsRun nhieu doan (Create Sketch / Winder 2-3-4 ve) qua tach GetStairsPath + nhan dang bac 3D
- Model In-Place / DirectShape / CAD Mesh (Generic Model hoac Category Stairs)
"""
import math
from Autodesk.Revit.DB import (Options, ViewDetailLevel, Solid, Mesh, GeometryInstance,
                               PlanarFace, UnitUtils, UnitTypeId, BuiltInCategory,
                               FilteredElementCollector, BuiltInParameter)
from Autodesk.Revit.DB.Architecture import Stairs, StairsRun
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

import thang_model as M


def mm(v):
    return UnitUtils.ConvertFromInternalUnits(v, UnitTypeId.Millimeters)


def _xy(p):
    return (mm(p.X), mm(p.Y))


def _xyz(p):
    return (mm(p.X), mm(p.Y), mm(p.Z))


def _loop_pts(loop, z=False):
    out = []
    for c in loop:
        p = c.GetEndPoint(0)
        out.append(_xyz(p) if z else _xy(p))
    return out


# ------------------------------------------------------------------ pick
def _tao_filter(ten, ham):
    """ISelectionFilter viet bang Python (pythonnet 3 can __namespace__). Loi -> None (pick khong loc)."""
    try:
        cls = type(ten, (ISelectionFilter,), {
            "__namespace__": "ThangTool",
            "AllowElement": lambda self, e: bool(ham(e)),
            "AllowReference": lambda self, r, p: False,
        })
        return cls()
    except Exception:
        return None


def _la_cat(e, bic):
    try:
        return e.Category is not None and e.Category.BuiltInCategory == bic
    except Exception:
        return False


def _la_generic(e):
    return _la_cat(e, BuiltInCategory.OST_GenericModel) or (
        _la_cat(e, BuiltInCategory.OST_Stairs) and not isinstance(e, (Stairs, StairsRun))
    )


def _la_stairs_hoac_inplace(e):
    return isinstance(e, (Stairs, StairsRun)) or _la_cat(e, BuiltInCategory.OST_Stairs)


def _pick(fn, flt):
    try:
        return fn(flt)
    except OperationCanceledException:
        return None
    except Exception:
        if flt is None:
            raise
        try:
            return fn(None)  # filter loi -> pick khong loc
        except OperationCanceledException:
            return None


def pick_stairs(uidoc):
    """Pick MOT HOAC NHIEU Stairs / StairsRun (hoac thang In-Place category Stairs). Bam Finish khi xong."""
    flt = _tao_filter("LocStairs", _la_stairs_hoac_inplace)
    msg = "Chọn thang (Stairs) - chọn đủ các vế rồi bấm Finish"

    def fn(f):
        if f is None:
            return uidoc.Selection.PickObjects(ObjectType.Element, msg)
        return uidoc.Selection.PickObjects(ObjectType.Element, f, msg)
    refs = _pick(fn, flt)
    if not refs:
        return []
    return [uidoc.Document.GetElement(r.ElementId) for r in refs]


def chi_stairs(els):
    return [e for e in els if isinstance(e, (Stairs, StairsRun))]


def chi_inplace_stairs(els):
    return [e for e in els if not isinstance(e, (Stairs, StairsRun)) and _la_cat(e, BuiltInCategory.OST_Stairs)]


def mo_ta(el):
    try:
        cat = el.Category.Name if el.Category is not None else "-"
    except Exception:
        cat = "?"
    try:
        nm = el.Name
    except Exception:
        nm = ""
    return "Id=%s | Class=%s | Category=%s | Name=%s" % (el.Id.Value, el.GetType().Name, cat, nm)


def _curve_pts_xy(c):
    try:
        pts = [_xy(p) for p in c.Tessellate()]
        if len(pts) >= 2:
            return pts
    except Exception:
        pass
    try:
        return [_xy(c.GetEndPoint(0)), _xy(c.GetEndPoint(1))]
    except Exception:
        return []


def _run_path_segs(r):
    try:
        curves = [c for c in r.GetStairsPath()]
    except Exception:
        curves = []
    polylines = [_curve_pts_xy(c) for c in curves]
    polylines = [pl for pl in polylines if len(pl) >= 2]
    return curves, M.tach_duong_di_ve(polylines)


def _runs_cua_stairs(doc, st):
    runs = []
    try:
        runs = [doc.GetElement(rid) for rid in st.GetStairsRuns()]
        runs = [r for r in runs if r is not None]
    except Exception:
        runs = []
    if not runs:
        try:
            for rr in FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StairsRuns).WhereElementIsNotElementType():
                try:
                    pst = rr.GetStairs()
                    if pst is not None and pst.Id.Value == st.Id.Value:
                        runs.append(rr)
                except Exception:
                    pass
        except Exception:
            pass
    return runs


def chan_doan_stairs(doc, els):
    L = []
    sts = [e for e in els if isinstance(e, Stairs)]
    direct_runs = [e for e in els if isinstance(e, StairsRun)]
    for st in sts:
        runs = _runs_cua_stairs(doc, st)
        lds = list(st.GetStairsLandings())
        L.append("STAIRS %s: %d StairsRun, %d chiếu nghỉ" % (st.Id.Value, len(runs), len(lds)))
        for i, r in enumerate(runs, 1):
            try:
                pl = _loop_pts(r.GetFootprintBoundary())
                xs = [q[0] for q in pl]
                ys = [q[1] for q in pl]
                curves, segs = _run_path_segs(r)
                w_raw = round(mm(r.ActualRunWidth))
                w_inf = _do_rong_tu_poly(pl, segs) if w_raw < 200 else w_raw
                w_txt = "%s (đo %s)" % (w_raw, round(w_inf)) if (w_raw < 200 and w_inf) else str(w_raw)
                L.append("   StairsRun %d (Id=%s): z %s -> %s, rộng %s, path=%d curve -> %d đoạn, X[%s..%s] Y[%s..%s]" % (
                    i, r.Id.Value, round(mm(r.BaseElevation)), round(mm(r.TopElevation)),
                    w_txt, len(curves), len(segs),
                    round(min(xs)), round(max(xs)), round(min(ys)), round(max(ys))))
            except Exception as ex:
                L.append("   StairsRun %d: lỗi %s" % (i, ex))
    for i, r in enumerate(direct_runs, 1):
        try:
            curves, segs = _run_path_segs(r)
            L.append("RUN %d (Id=%s): z %s -> %s, rộng %s, path=%d curve -> %d đoạn" % (
                i, r.Id.Value, round(mm(r.BaseElevation)), round(mm(r.TopElevation)),
                round(mm(r.ActualRunWidth)), len(curves), len(segs)))
        except Exception as ex:
            L.append("RUN %d: lỗi %s" % (i, ex))
    return L


# ------------------------------------------------------------------ hinh hoc chung (Solid + Mesh + Triangulate)
def _solids(geo):
    if geo is None:
        return
    for g in geo:
        if isinstance(g, Solid):
            if g.Faces.Size > 0:
                yield g
        elif isinstance(g, GeometryInstance):
            for s in _solids(g.GetInstanceGeometry()):
                yield s


def _meshes(geo):
    if geo is None:
        return
    for g in geo:
        if isinstance(g, Mesh):
            yield g
        elif isinstance(g, GeometryInstance):
            for m in _meshes(g.GetInstanceGeometry()):
                yield m


def _mesh_tri(mesh, idx):
    try:
        return mesh.get_Triangle(idx)
    except Exception:
        return mesh.Triangle[idx]


def _tri_vertex(tri, k):
    try:
        return tri.get_Vertex(k)
    except Exception:
        return tri.Vertex[k]


def _tri_from_mesh(mesh):
    out = []
    try:
        nt = mesh.NumTriangles
    except Exception:
        return out
    for i in range(nt):
        try:
            tri = _mesh_tri(mesh, i)
            p0 = _xyz(_tri_vertex(tri, 0))
            p1 = _xyz(_tri_vertex(tri, 1))
            p2 = _xyz(_tri_vertex(tri, 2))
            ax, ay, az = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            bx, by, bz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
            nx = ay * bz - az * by
            ny = az * bx - ax * bz
            nz = ax * by - ay * bx
            ln = math.sqrt(nx * nx + ny * ny + nz * nz)
            if ln < 1e-4:
                continue
            out.append({"n": (nx / ln, ny / ln, nz / ln), "loops": [[p0, p1, p2]]})
        except Exception:
            continue
    return out


def _phan_loai_nz(nz):
    if nz > 0.99:
        return "ngang tren"
    if nz < -0.99:
        return "ngang duoi"
    if nz > 0.15:
        return "nghieng tren"
    if nz < -0.15:
        return "nghieng duoi"
    return "dung"


def _extract_faces(elems, opt=None):
    if opt is None:
        opt = Options()
        opt.DetailLevel = ViewDetailLevel.Fine
    faces = []
    stats = {"solids": 0, "meshes": 0, "planar": 0, "tri_faces": 0, "mesh_tris": 0, "loai": {}}
    for el in elems:
        try:
            geo = el.get_Geometry(opt)
        except Exception:
            geo = None
        if geo is None:
            continue
        for s in _solids(geo):
            stats["solids"] += 1
            for f in s.Faces:
                if isinstance(f, PlanarFace):
                    stats["planar"] += 1
                    n = f.FaceNormal
                    loops = [_loop_pts(lp, True) for lp in f.GetEdgesAsCurveLoops()]
                    loops = [lp for lp in loops if len(lp) >= 3]
                    if loops:
                        faces.append({"n": (n.X, n.Y, n.Z), "loops": loops, "planar": True})
                        k = _phan_loai_nz(n.Z)
                        stats["loai"][k] = stats["loai"].get(k, 0) + 1
                else:
                    stats["tri_faces"] += 1
                    try:
                        m = f.Triangulate()
                        tris = _tri_from_mesh(m) if m is not None else []
                        for tf in tris:
                            faces.append(tf)
                            k = _phan_loai_nz(tf["n"][2])
                            stats["loai"][k] = stats["loai"].get(k, 0) + 1
                    except Exception:
                        pass
        for m in _meshes(geo):
            stats["meshes"] += 1
            tris = _tri_from_mesh(m)
            stats["mesh_tris"] += len(tris)
            for tf in tris:
                faces.append(tf)
                k = _phan_loai_nz(tf["n"][2])
                stats["loai"][k] = stats["loai"].get(k, 0) + 1
    return faces, stats


def chan_doan_generic(elems):
    L = []
    for el in elems:
        _, st = _extract_faces([el])
        L.append("GENERIC %s: %d solid (%d phẳng, %d mặt cong), %d mesh (%d tam giác) -> %s" % (
            mo_ta(el), st["solids"], st["planar"], st["tri_faces"],
            st["meshes"], st["mesh_tris"], st["loai"]))
    return L


def pick_generic(uidoc):
    flt = _tao_filter("LocGeneric", _la_generic)
    msg = "Chọn bản thang BTCT (Generic Model / In-Place) - bấm Finish khi xong"

    def fn(f):
        if f is None:
            return uidoc.Selection.PickObjects(ObjectType.Element, msg)
        return uidoc.Selection.PickObjects(ObjectType.Element, f, msg)
    refs = _pick(fn, flt)
    if not refs:
        return []
    return [uidoc.Document.GetElement(r.ElementId) for r in refs]


def _faces_stairs(els):
    """Cac mat (phang + triangulate mat cong) cua hinh hoc Stairs / StairsRun, mm."""
    faces, _ = _extract_faces(els)
    return faces


def _day_ve(faces, poly, u, z0, z1):
    """Be day ban cua 1 ve, do tu hinh hoc Stairs: lay trung vi khoang cach vuong goc
    tu mat day nghieng den goc trong cua TUNG bac ngang (tranh bat nham goc winder ra 41/63 mm)."""
    try:
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        x0, x1, y0, y1 = min(xs) - 80, max(xs) + 80, min(ys) - 80, max(ys) + 80
        v = (-u[1], u[0])

        def trong(pts):
            cx = sum(p[0] for p in pts) / len(pts)
            cy = sum(p[1] for p in pts) / len(pts)
            return x0 <= cx <= x1 and y0 <= cy <= y1

        best = None
        for f in faces:
            n = f["n"]
            pts = [p for lp in f["loops"] for p in lp]
            if len(pts) < 3:
                continue
            if n[2] < -0.15 and n[0] * u[0] + n[1] * u[1] > 0.2 and trong(pts):
                zc = sum(p[2] for p in pts) / len(pts)
                if z0 - 800 <= zc <= z1 + 200:
                    dx = max(p[0] for p in pts) - min(p[0] for p in pts)
                    dy = max(p[1] for p in pts) - min(p[1] for p in pts)
                    lat = abs(n[0] * v[0] + n[1] * v[1])
                    bonus = (2.5 if (f.get("planar") or len(pts) >= 4) else 1.0) * (1.5 if lat < 0.25 else 0.5)
                    score = (dx * dx + dy * dy) * bonus
                    if best is None or score > best[0]:
                        best = (score, n, pts)
        if best is None:
            return None
        _, n, pts = best
        l = (n[0] ** 2 + n[1] ** 2 + n[2] ** 2) ** 0.5 or 1.0
        n = (n[0] / l, n[1] / l, n[2] / l)
        d0 = n[0] * pts[0][0] + n[1] * pts[0][1] + n[2] * pts[0][2]
        per_tread = []
        for f2 in faces:
            nn = f2["n"]
            pp = [p for lp in f2["loops"] for p in lp]
            if not pp:
                continue
            if nn[2] > 0.99 and trong(pp):
                zc = sum(p[2] for p in pp) / len(pp)
                if z0 + 20 <= zc <= z1 + 20:
                    d_t = None
                    for p in pp:
                        dist = d0 - (n[0] * p[0] + n[1] * p[1] + n[2] * p[2])
                        if dist > 0 and (d_t is None or dist < d_t):
                            d_t = dist
                    if d_t is not None and 75.0 <= d_t <= 500.0:
                        per_tread.append(d_t)
        if per_tread:
            per_tread.sort()
            return per_tread[len(per_tread) // 2]
    except Exception:
        pass
    return None


def _do_day_bot_faces(faces, p0, u, dai, rong, z0, z1):
    bot = []
    for f in faces:
        n = f["n"]
        if -0.99 <= n[2] < -0.15:
            pts = [p for lp in f["loops"] for p in lp]
            if len(pts) >= 3:
                bot.append({"n": n, "pts": pts, "loops": f["loops"]})
    d = M._do_day_tu_bot(p0, u, dai, rong, z0, z1, bot)
    return d if (d is not None and 75.0 <= d <= 500.0) else None


def _run_type_depth(doc, r):
    """Doc be day ban ket cau (Structural Depth) trong Type Properties cua StairsRun."""
    try:
        tid = r.GetTypeId()
        if tid is None:
            return None
        rt = doc.GetElement(tid)
        if rt is None:
            return None
        for bname in ("STAIRS_RUNTYPE_STRUCTURAL_DEPTH", "STAIRSTYPE_MONOLITHIC_THICKNESS"):
            bip = getattr(BuiltInParameter, bname, None)
            if bip is not None:
                p = rt.get_Parameter(bip)
                if p is not None and p.HasValue:
                    d = mm(p.AsDouble())
                    if 75.0 <= d <= 500.0:
                        return d
        for pname in ("Structural Depth", "Monolithic Thickness", "Chiều dày kết cấu", "Thickness"):
            p = rt.LookupParameter(pname)
            if p is not None and p.HasValue:
                d = mm(p.AsDouble())
                if 75.0 <= d <= 500.0:
                    return d
    except Exception:
        pass
    return None


def _do_rong_tu_poly(poly, segs):
    """Suy ra be rong ve khi ActualRunWidth == 0 (thang Sketch / Winder) bang raycast vuong goc len ranh footprint."""
    if not poly or len(poly) < 3 or not segs:
        return None
    n_pts = len(poly)
    cands = []
    # Uu tien doan dai nhat (thuong la ve thang giua)
    for seg in sorted(segs, key=lambda s: -s["dai"]):
        p0, p1, u = seg["p0"], seg["p1"], seg["u"]
        v = (-u[1], u[0])
        for frac in (0.35, 0.5, 0.65):
            mx = p0[0] + (p1[0] - p0[0]) * frac
            my = p0[1] + (p1[1] - p0[1]) * frac
            pos_ts, neg_ts = [], []
            for i in range(n_pts):
                ax, ay = poly[i]
                bx, by = poly[(i + 1) % n_pts]
                ex, ey = bx - ax, by - ay
                det = v[0] * (-ey) - v[1] * (-ex)
                if abs(det) < 1e-6:
                    continue
                rx, ry = ax - mx, ay - my
                t = (rx * (-ey) - ry * (-ex)) / det
                alpha = (v[0] * ry - v[1] * rx) / det
                if -1e-4 <= alpha <= 1.0 + 1e-4:
                    if t > 50.0:
                        pos_ts.append(t)
                    elif t < -50.0:
                        neg_ts.append(-t)
            if pos_ts and neg_ts:
                w = min(pos_ts) + min(neg_ts)
                if 400.0 <= w <= 3500.0 and abs(min(pos_ts) - min(neg_ts)) < 250.0:
                    cands.append(w)
            elif pos_ts or neg_ts:
                d = min(pos_ts) if pos_ts else min(neg_ts)
                if 200.0 <= d <= 1750.0:
                    cands.append(2.0 * d)
        if cands:
            break
    if not cands:
        return None
    cands.sort()
    return cands[len(cands) // 2]


def _cat_goc_segs(segs, w):
    """Tach cac ve tai goc re ~90 do cho thang Winder / Sketch:
    - Doan dai (> 1.25*w): cat bot hw o goc va gan ban goc cn = w (1000mm) de ve MC dung cau tao.
    - Doan ngan (<= 1.25*w): giu chieu dai walkline den tam goc C_k (khong keo dai lam giat bac 625mm)
      va gan phan goc ngoai cn = hw (500mm).
    - Tra ve (adj_segs, corners) trong do corners chua da giac w x w cho tung goc re.
    """
    m = len(segs)
    adj = [dict(s, cn_dau=None, cn_cuoi=None, box_s0=0.0, box_s1=s["dai"]) for s in segs]
    corners = []
    if m < 2 or w <= 10.0:
        return adj, corners
    hw = w / 2.0
    lens = [s["dai"] for s in segs]
    for k in range(m - 1):
        a = adj[k]
        b = adj[k + 1]
        dist = math.hypot(a["p1"][0] - b["p0"][0], a["p1"][1] - b["p0"][1])
        if dist > 350.0:
            continue
        dot = abs(a["u"][0] * b["u"][0] + a["u"][1] * b["u"][1])
        if dot >= 0.5:
            continue
        cx = (a["p1"][0] + b["p0"][0]) / 2.0
        cy = (a["p1"][1] + b["p0"][1]) / 2.0
        ua = a["u"]
        ub = b["u"]
        a_long = lens[k] > 1.25 * w
        b_long = lens[k + 1] > 1.25 * w

        if a_long:
            a["p1"] = (a["p1"][0] - ua[0] * hw, a["p1"][1] - ua[1] * hw)
            a["cn_cuoi"] = w
            a["box_s1"] = math.hypot(a["p1"][0] - a["p0"][0], a["p1"][1] - a["p0"][1])
        else:
            a["cn_cuoi"] = hw
            a["box_s1"] = lens[k] + hw

        if b_long:
            b["p0"] = (b["p0"][0] + ub[0] * hw, b["p0"][1] + ub[1] * hw)
            b["cn_dau"] = w
            b["box_s0"] = 0.0
        else:
            b["cn_dau"] = hw
            b["box_s0"] = -hw

        # Da giac goc w x w quanh C_k theo he truc (ua, ub)
        cpoly = [
            [cx - ua[0] * hw - ub[0] * hw, cy - ua[1] * hw - ub[1] * hw],
            [cx + ua[0] * hw - ub[0] * hw, cy + ua[1] * hw - ub[1] * hw],
            [cx + ua[0] * hw + ub[0] * hw, cy + ua[1] * hw + ub[1] * hw],
            [cx - ua[0] * hw + ub[0] * hw, cy - ua[1] * hw + ub[1] * hw],
        ]
        corners.append({"k": k, "poly": cpoly})

    for s in adj:
        s["dai"] = max(200.0, math.hypot(s["p1"][0] - s["p0"][0], s["p1"][1] - s["p0"][1]))
        if s["cn_dau"] is None:
            s["box_s0"] = 0.0
        if s["cn_cuoi"] is None:
            s["box_s1"] = s["dai"]
    return adj, corners


def _trong_box(pt, seg, hw):
    u = seg["u"]
    v = (-u[1], u[0])
    dx, dy = pt[0] - seg["p0"][0], pt[1] - seg["p0"][1]
    s = dx * u[0] + dy * u[1]
    t = dx * v[0] + dy * v[1]
    s0 = min(0.0, seg.get("box_s0", 0.0))
    s1 = max(seg["dai"], seg.get("box_s1", seg["dai"]))
    return (s0 - 20.0 <= s <= s1 + 20.0) and (abs(t) <= hw + 25.0)


def _chia_bac_theo_3d_va_vung(faces, adj_segs, w, z0, z1, tong_bac, riser):
    """Tinh cao do (z0_k, z1_k) va so bac tung ve dua tren mat bac 3D trong tung vung footprint khong chong cheo;
    neu thieu mat bac 3D thi chia theo chieu dai vung thang/goc thuc te."""
    m = len(adj_segs)
    dh = z1 - z0
    r_h = riser if (riser and riser > 1.0) else (dh / max(tong_bac, 1))
    hw = w / 2.0

    # Thu doc mat bac ngang (nz > 0.99) va gom theo tung vung box
    if faces and r_h > 20.0:
        box_zs = [[] for _ in range(m)]
        for f in faces:
            if f["n"][2] <= 0.99:
                continue
            pts = [p for lp in f["loops"] for p in lp]
            if len(pts) < 3:
                continue
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            if max(xs) - min(xs) < 120.0 and max(ys) - min(ys) < 120.0:
                continue
            cx = sum(p[0] for p in pts) / len(pts)
            cy = sum(p[1] for p in pts) / len(pts)
            zc = sum(p[2] for p in pts) / len(pts)
            if zc < z0 + 10.0 or zc > z1 + 10.0:
                continue
            for k, seg in enumerate(adj_segs):
                if _trong_box((cx, cy), seg, hw):
                    box_zs[k].append(zc)
                    break
        if all(len(zs) >= 1 for zs in box_zs):
            bounds = [z0]
            ok = True
            for k in range(m - 1):
                z_hi_k = max(box_zs[k])
                z_lo_nxt = min(box_zs[k + 1]) - r_h
                z_mid = z_hi_k if abs(z_hi_k - z_lo_nxt) < 1.5 * r_h else (z_hi_k + z_lo_nxt) / 2.0
                n_cum = max(k + 1, min(tong_bac - (m - 1 - k), int(round((z_mid - z0) / r_h))))
                z_snap = z0 + n_cum * r_h
                if z_snap <= bounds[-1] + 20.0:
                    ok = False
                    break
                bounds.append(z_snap)
            bounds.append(z1)
            if ok:
                out = []
                for k in range(m):
                    sb = max(1, int(round((bounds[k + 1] - bounds[k]) / r_h)))
                    out.append((bounds[k], bounds[k + 1], sb))
                if sum(x[2] for x in out) == tong_bac:
                    return out

    # Fallback: chia theo chieu dai vung footprint thuc te (1000..1250 cho goc, 3500 cho ve thang)
    counts = _chia_so_bac_theo_doan([{"arc_len": max(s["dai"], abs(s.get("box_s1", s["dai"]) - s.get("box_s0", 0.0)))} for s in adj_segs], tong_bac)
    out = []
    z_cur = z0
    tot_c = max(sum(counts), 1)
    for sb in counts:
        z_next = z_cur + dh * (float(sb) / tot_c)
        out.append((z_cur, z_next, sb))
        z_cur = z_next
    return out


def _trich_duong_bac(faces, z0, z1):
    """Trich cac canh mat bac 3D thuc te (gom ca bac cheo winder) tu PlanarFace ngang de ve MB."""
    segs = []
    seen = set()
    for f in faces:
        if not f.get("planar") or f["n"][2] <= 0.99:
            continue
        for lp in f["loops"]:
            if len(lp) < 3:
                continue
            zc = sum(p[2] for p in lp) / len(lp)
            if zc < z0 + 10.0 or zc > z1 + 10.0:
                continue
            n = len(lp)
            for i in range(n):
                a, b = lp[i], lp[(i + 1) % n]
                if math.hypot(b[0] - a[0], b[1] - a[1]) < 120.0:
                    continue
                ka = (int(round(a[0] / 5.0)), int(round(a[1] / 5.0)))
                kb = (int(round(b[0] / 5.0)), int(round(b[1] / 5.0)))
                key = (ka, kb) if ka <= kb else (kb, ka)
                if key in seen:
                    continue
                seen.add(key)
                segs.append([[a[0], a[1]], [b[0], b[1]]])
    return segs


def _rect_poly(p0, p1, u, rong):
    v = (-u[1], u[0])
    hw = rong / 2.0
    return [
        (p0[0] - v[0] * hw, p0[1] - v[1] * hw),
        (p1[0] - v[0] * hw, p1[1] - v[1] * hw),
        (p1[0] + v[0] * hw, p1[1] + v[1] * hw),
        (p0[0] + v[0] * hw, p0[1] + v[1] * hw),
    ]


def _chia_so_bac_theo_doan(segs, tong_bac):
    """Phan bo tong_bac cho cac doan duong di theo ty le chieu dai."""
    n = len(segs)
    if n == 0:
        return []
    tong_bac = max(n, int(round(tong_bac)))
    weights = [max(s["arc_len"], 1.0) for s in segs]
    tot = sum(weights)
    counts = [max(1, int(round(tong_bac * w / tot))) for w in weights]
    diff = tong_bac - sum(counts)
    while diff != 0:
        if diff > 0:
            idx = max(range(n), key=lambda k: weights[k] / counts[k])
            counts[idx] += 1
            diff -= 1
        else:
            cands = [k for k in range(n) if counts[k] > 1]
            if not cands:
                break
            idx = min(cands, key=lambda k: weights[k] / counts[k])
            counts[idx] -= 1
            diff += 1
    return counts


def _ten_stairs(sts):
    for st in sts:
        try:
            p = st.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)
            if p is not None:
                v = p.AsString()
                if v:
                    return v
        except Exception:
            pass
    return None


def _z_gan_diem(faces, pt, r_max=650.0):
    best_d = None
    best_z = None
    for f in faces:
        if f["n"][2] <= 0.95:
            continue
        pts = [p for lp in f["loops"] for p in lp]
        if not pts:
            continue
        cx = sum(p[0] for p in pts) / len(pts)
        cy = sum(p[1] for p in pts) / len(pts)
        d = math.hypot(cx - pt[0], cy - pt[1])
        if d <= r_max and (best_d is None or d < best_d):
            best_d = d
            best_z = sum(p[2] for p in pts) / len(pts)
    return best_z


def _dao_segs(segs):
    return [
        {
            "p0": s["p1"], "p1": s["p0"],
            "u": (-s["u"][0], -s["u"][1]),
            "dai": s["dai"], "arc_len": s["arc_len"],
        }
        for s in reversed(segs)
    ]


# ------------------------------------------------------------------ A: Stairs
def doc_stairs(doc, sts):
    if not isinstance(sts, (list, tuple)):
        sts = [sts]
    riser = None
    sts_objs = []
    run_objs = []
    seen_st = set()
    seen_run = set()
    for el in sts:
        if isinstance(el, Stairs):
            if el.Id.Value not in seen_st:
                seen_st.add(el.Id.Value)
                sts_objs.append(el)
        elif isinstance(el, StairsRun):
            try:
                pst = el.GetStairs()
            except Exception:
                pst = None
            if pst is not None and pst.Id.Value not in seen_st:
                seen_st.add(pst.Id.Value)
                sts_objs.append(pst)
            if el.Id.Value not in seen_run:
                seen_run.add(el.Id.Value)
                run_objs.append(el)

    # Gom tat ca StairsRun va StairsLandings tu Stairs (tranh trung lap)
    landings_objs = []
    seen_ld = set()
    for st in sts_objs:
        try:
            if riser is None:
                riser = mm(st.ActualRiserHeight)
        except Exception:
            pass
        for r in _runs_cua_stairs(doc, st):
            if r.Id.Value not in seen_run:
                seen_run.add(r.Id.Value)
                run_objs.append(r)
        try:
            for lid in st.GetStairsLandings():
                if lid.Value not in seen_ld:
                    seen_ld.add(lid.Value)
                    l = doc.GetElement(lid)
                    if l is not None:
                        landings_objs.append(l)
        except Exception:
            pass

    faces = _faces_stairs(run_objs) if run_objs else []
    if not faces and sts_objs:
        faces = _faces_stairs(sts_objs)

    raw_runs, raw_lds = [], []
    split_notes = []
    bac_ve_3d = []
    da_tach_tu_path = False
    for r in run_objs:
        try:
            poly = _loop_pts(r.GetFootprintBoundary())
        except Exception:
            poly = []
        z0, z1 = mm(r.BaseElevation), mm(r.TopElevation)
        rev = z1 < z0
        if rev:
            z0, z1 = z1, z0
        curves, segs = _run_path_segs(r)
        try:
            rong = mm(r.ActualRunWidth)
        except Exception:
            rong = None
        if not rong or rong < 200.0:
            rong = _do_rong_tu_poly(poly, segs)
        w = rong or 1000.0

        if rev and segs:
            segs = _dao_segs(segs)
        elif segs and faces:
            za = _z_gan_diem(faces, segs[0]["p0"])
            zb = _z_gan_diem(faces, segs[-1]["p1"])
            if za is not None and zb is not None and zb < za - 100.0:
                segs = _dao_segs(segs)

        type_depth = _run_type_depth(doc, r)
        if faces:
            bac_ve_3d.extend(_trich_duong_bac(faces, z0, z1))

        if len(segs) >= 2:
            da_tach_tu_path = True
            try:
                tong_bac = int(r.ActualRisersNumber)
            except Exception:
                tong_bac = 0
            if tong_bac < len(segs):
                tong_bac = int(round((z1 - z0) / riser)) if riser and riser > 1 else M.goi_y_so_bac(z1 - z0)
                tong_bac = max(len(segs), tong_bac)

            adj_segs, corners = _cat_goc_segs(segs, w)
            z_slices = _chia_bac_theo_3d_va_vung(faces, adj_segs, w, z0, z1, tong_bac, riser)
            seg_runs = []
            for idx_s, (seg, (z_a, z_b, sb)) in enumerate(zip(adj_segs, z_slices)):
                pl_seg = _rect_poly(seg["p0"], seg["p1"], seg["u"], w)
                day = type_depth or _day_ve(faces, pl_seg, seg["u"], z_a, z_b) or _do_day_bot_faces(
                    faces, seg["p0"], seg["u"], seg["dai"], w, z_a, z_b)
                sr = {
                    "poly": pl_seg, "u": seg["u"], "z0": z_a, "z1": z_b,
                    "rong": w, "day": day, "so_bac": sb,
                    "_seg": seg,
                }
                if seg.get("cn_dau") is not None:
                    sr["cn_dau"] = seg["cn_dau"]
                    sr["_ve_cn_dau_mb"] = False
                elif idx_s == 0 and not raw_lds and not landings_objs:
                    sr["cn_dau"] = 600.0
                    sr["_ve_cn_dau_mb"] = False
                if seg.get("cn_cuoi") is not None:
                    sr["cn_cuoi"] = seg["cn_cuoi"]
                    sr["_ve_cn_cuoi_mb"] = False
                elif idx_s == len(adj_segs) - 1 and not landings_objs:
                    sr["cn_cuoi"] = 600.0
                    sr["_ve_cn_cuoi_mb"] = False
                seg_runs.append(sr)

            # Lay be day chuan tu doan ve thang dai nhat (tranh nhieu o goc winder)
            straight_days = [sr["day"] for sr in sorted(seg_runs, key=lambda x: -math.hypot(x["poly"][1][0] - x["poly"][0][0], x["poly"][1][1] - x["poly"][0][1]))
                             if sr["day"] and sr["day"] >= 85.0]
            shared_day = type_depth or (straight_days[0] if straight_days else None) or 130.0
            for sr in seg_runs:
                seg_len = sr["_seg"]["dai"]
                if type_depth:
                    sr["day"] = type_depth
                elif not sr["day"] or sr["day"] < 85.0 or (seg_len <= 1.25 * w and abs(sr["day"] - shared_day) > 12.0):
                    sr["day"] = shared_day
                sr.pop("_seg", None)

            # Giu nguyen tat ca cac ve (ke ca ve ngan 2-4 bac o dau/cuoi thang 3 ve, chu L, winder)
            for cr in corners:
                zc = z_slices[cr["k"]][1]
                raw_lds.append({"poly": cr["poly"], "zs": [zc], "day": shared_day})
            raw_runs.extend(seg_runs)
            split_notes.append("StairsRun Id=%s (rộng %d, dày %d): tách thành %d vế (%s bậc)" % (
                r.Id.Value, round(w), round(shared_day), len(seg_runs),
                "-".join(str(x["so_bac"]) for x in seg_runs)))
        else:
            if segs:
                u = segs[0]["u"]
            elif curves:
                a, b = curves[0].GetEndPoint(0), curves[-1].GetEndPoint(1)
                u = (mm(b.X - a.X), mm(b.Y - a.Y))
                if rev:
                    u = (-u[0], -u[1])
            else:
                u = (0.0, 1.0)
            if not poly and segs:
                poly = _rect_poly(segs[0]["p0"], segs[0]["p1"], u, w)
            day = type_depth or _day_ve(faces, poly, u, z0, z1) or _do_day_bot_faces(
                faces, poly[0] if poly else (0.0, 0.0), u, 2000.0, w, z0, z1)
            raw_runs.append({"poly": poly, "u": u, "z0": z0, "z1": z1, "rong": w, "day": day})

    for l in landings_objs:
        try:
            poly = _loop_pts(l.GetFootprintBoundary())
            base = mm(l.BaseElevation)
            th = mm(l.Thickness)
            raw_lds.append({"poly": poly, "zs": [base, base + th], "day": th})
        except Exception:
            pass

    # Fallback 3D chi khi GetStairsPath KHONG tach duoc nhieu doan (Revit gom winder vao 1 curve)
    fallback_note = None
    if not da_tach_tu_path and len(raw_runs) <= 1 and faces:
        step_runs = M.tu_faces_steps_only(faces, riser)
        if len(step_runs) >= 2:
            raw_runs = []
            for idx_sr, sr in enumerate(step_runs):
                p0 = sr["p0"]
                u = sr["u"]
                p1 = (p0[0] + u[0] * sr["dai"], p0[1] + u[1] * sr["dai"])
                rr = {
                    "poly": _rect_poly(p0, p1, u, sr["rong"]),
                    "u": u,
                    "z0": sr["z0"],
                    "z1": sr["z1"],
                    "rong": sr["rong"],
                    "day": sr["day"],
                    "so_bac": sr["so_bac"],
                }
                if idx_sr == 0 and not landings_objs:
                    rr["cn_dau"] = 600.0
                    rr["_ve_cn_dau_mb"] = False
                if idx_sr == len(step_runs) - 1 and not landings_objs:
                    rr["cn_cuoi"] = 600.0
                    rr["_ve_cn_cuoi_mb"] = False
                raw_runs.append(rr)
            fallback_note = "Tách thêm từ hình học bậc 3D của Stairs: %d vế (%s bậc)" % (
                len(raw_runs), "-".join(str(x["so_bac"]) for x in raw_runs))

    t = M.tu_stairs(raw_runs, raw_lds, riser)
    if bac_ve_3d:
        t["bac_ve_3d"] = bac_ve_3d
    t["ghi_chu"].append("Đọc từ %d Stairs / %d StairsRun: nhận %d vế, %d chiếu nghỉ" % (
        len(sts_objs), len(run_objs), len(raw_runs), len(raw_lds)))
    t["ghi_chu"].extend(split_notes)
    if fallback_note:
        t["ghi_chu"].append(fallback_note)
    n_do = len([r for r in raw_runs if r.get("day")])
    if n_do == len(raw_runs):
        t["ghi_chu"].append("Dày bản đo từ hình học Stairs")
    else:
        t["ghi_chu"].append("Dày bản: đo được %d/%d vế, vế còn lại tạm 120 - bấm vào số trên hình để sửa" % (n_do, len(raw_runs)))
    try:
        zb_abs = min(rr.get("z_san_dau", rr["z0"]) for rr in raw_runs)
        zb_rel = min(r.get("z_san_dau", r["z0"]) for r in t["runs"])
        t["z_goc"] = zb_abs - zb_rel
    except Exception:
        t["z_goc"] = None
    ten = _ten_stairs(sts_objs)
    if ten:
        t["ten"] = ten
        t["tt"]["ten"] = ten
        t["ten_tu_revit"] = True
    return t


# ------------------------------------------------------------------ B: Generic Model / Mesh / In-Place
def doc_generic(doc, elems):
    faces, stats = _extract_faces(elems)
    t = M.tu_faces(faces)
    t["ghi_chu"].append("Đã đọc %d đối tượng (%d solid, %d mesh): %d mặt (%d phẳng, %d tam giác cong/mesh)" % (
        len(elems), stats["solids"], stats["meshes"], len(faces),
        stats["planar"], len(faces) - stats["planar"]))
    return t


# ------------------------------------------------------------------ Quet dam (Structural Framing)
def _bb(el):
    try:
        b = el.get_BoundingBox(None)
    except Exception:
        return None
    if b is None:
        return None
    return (mm(b.Min.X), mm(b.Max.X), mm(b.Min.Y), mm(b.Max.Y), mm(b.Min.Z), mm(b.Max.Z))


def _dam_hinh(el):
    """(x, y, dx, dy, dai, b, h, z_dinh_tuyet_doi) cua 1 dam, mm. Khong doc duoc -> None."""
    try:
        cv = el.Location.Curve
        p, q = cv.GetEndPoint(0), cv.GetEndPoint(1)
    except Exception:
        return None
    dx, dy = mm(q.X - p.X), mm(q.Y - p.Y)
    ln = (dx * dx + dy * dy) ** 0.5
    if ln < 100.0:
        return None
    dx, dy = dx / ln, dy / ln
    opt = Options()
    opt.DetailLevel = ViewDetailLevel.Fine
    geo = el.get_Geometry(opt)
    if geo is None:
        return None
    ts, zs = [], []
    for sol in _solids(geo):
        for e in sol.Edges:
            c = e.AsCurve()
            for k in (0, 1):
                pt = c.GetEndPoint(k)
                ts.append(mm(pt.X) * (-dy) + mm(pt.Y) * dx)
                zs.append(mm(pt.Z))
    if not ts:
        return None
    return (mm((p.X + q.X) / 2.0), mm((p.Y + q.Y) / 2.0), dx, dy, ln,
            max(ts) - min(ts), max(zs) - min(zs), max(zs))


def quet_dam(doc, thang):
    """Quet dam (Structural Framing) nam ngang o chan / giua / dau thang.
    Tra ve (danh_sach_dam, dong_bao_cao). Khong quet duoc -> (None, [ly do])."""
    zg = thang.get("z_goc")
    if zg is None or not thang["runs"]:
        return None, ["Chỉ quét dầm được khi thang đọc từ Revit (Chọn Stairs / Generic Model), "
                      "không quét được với thang nhập tay. Thang nhập tay: dùng nút + Dầm chân/giữa/đầu."]
    h = M.mb_hinh(thang)
    pts = [q for poly in h["runs"] + h["landings"] for q in poly]
    x0, x1 = min(q[0] for q in pts) - 1500.0, max(q[0] for q in pts) + 1500.0
    y0, y1 = min(q[1] for q in pts) - 1500.0, max(q[1] for q in pts) + 1500.0
    ztot = max(r["z1"] for r in thang["runs"])
    out, bo = [], 0
    for el in FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType():
        bb = _bb(el)
        if bb is None:
            continue
        if bb[1] < x0 or bb[0] > x1 or bb[3] < y0 or bb[2] > y1:
            continue
        if bb[5] < zg - 1500.0 or bb[4] > zg + ztot + 1500.0:
            continue
        g = _dam_hinh(el)
        if g is None:
            continue
        d = {"x": g[0], "y": g[1], "dx": g[2], "dy": g[3], "len": g[4], "b": g[5], "h": g[6],
             "ztop": g[7] - zg, "nguon": "Revit Id=%s" % el.Id.Value}
        vt = M.phan_loai_dam(thang, d)
        if vt is None:
            bo += 1
            continue
        d["vi_tri"] = vt
        out.append(d)
    L = ["Quét dầm: tìm thấy %d dầm ngang ở thang (bỏ qua %d dầm gần thang nhưng song song/ngoài thang)" % (len(out), bo)]
    for tn, tl in (("chan", "chân thang"), ("giua", "giữa thang"), ("dau", "đầu thang")):
        for d in [x for x in out if x["vi_tri"] == tn]:
            L.append("  Dầm %s: %s | b=%d, h=%d | đỉnh cách chân thang %+d mm" % (
                tl, d["nguon"], round(d["b"]), round(d["h"]), round(d["ztop"])))
    if not out:
        L.append("  (không có dầm nào - dùng nút + Dầm chân/giữa/đầu để thêm tay)")
    return out, L

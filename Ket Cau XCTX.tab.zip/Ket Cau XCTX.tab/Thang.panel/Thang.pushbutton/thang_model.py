# -*- coding: utf-8 -*-
"""thang_model.py
Du lieu chung cua tool thang + hinh hoc & cau tao ban thang BTCT theo TCVN 5574:2018 / thuc te VN.
DON VI: mm. Khong import Revit / WinForms -> test duoc ngoai Revit.

Cau truc:
thang = {
  "ten", "loai", "nguon", "ghi_chu": [...],
  "runs":     [ run, ... ]        # theo thu tu di len
  "landings": [ {"poly": [[x,y],..], "zs": [z..], "z": z, "day": mm}, ... ]
  "tt": {thong so form & thep TCVN}
}
run = {"p0":[x,y]  tam mep dau ve (mat bang),  "u":[ux,uy] huong di len,
       "rong","dai"  (dai = chieu dai ve tren mat bang),
       "z0","z1" cao do mat chieu nghi duoi / tren,
       "so_bac","day" (day ban, vuong goc),
       "cn_dau","cn_cuoi" chieu dai chieu nghi truoc/sau ve,
       "day_cn_dau","day_cn_cuoi"}
"""
import math

LOG = []


def _log(s):
    LOG.append(s)
    print(s)


LOAI = ["1 vế", "2 vế", "3 vế", "4 vế", "Chữ L"]
TOL_Z = 80.0


# ---------------------------------------------------------------- vector 2D
def _unit(x, y):
    l = math.hypot(x, y)
    return (x / l, y / l) if l > 1e-9 else (0.0, 1.0)


def _normal(u):
    return (-u[1], u[0])


def _area_xy(pts):
    a = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i][0], pts[i][1]
        x2, y2 = pts[(i + 1) % n][0], pts[(i + 1) % n][1]
        a += x1 * y2 - x2 * y1
    return a / 2.0


# ---------------------------------------------------------------- tao du lieu & TCVN
def goi_y_so_bac(h):
    """Goi y so bac theo chieu cao bac chuan VN (~165 mm, nam trong 150..180 mm)."""
    return max(1, int(round(abs(h) / 165.0)))


def goi_y_day_ban(L_tinh_toan):
    """Chieu day ban thang theo kinh nghiem VN: L0 / 28, lam tron boi 10 mm, toi thieu 100 mm."""
    hb = max(100.0, math.ceil((L_tinh_toan / 28.0) / 10.0) * 10.0)
    return min(hb, 250.0)


def tt_mac_dinh():
    return {
        "ten": "T1", "so_luong": 2, "ty_le_mb": "1:25", "ty_le_mc": "1:25",
        "kieu": "Bản",                 # "Bản" (ban chiu luc) | "Dầm" (ban tua len con thang)
        "abv": 20.0,                   # lop BT bao ve chuan TCVN 5574:2018 (15-20mm trong nha)
        "neo": "35/25",                # neo keo / neo nen (x d), theo B20-B25 + CB300-V/CB400-V
        "moc_d": 8.0,                  # chieu dai moc cau tao (6d..10d)
        "cat_thep": True, "cat_thep_l": 0.25,  # cat mu goi 1/4 nhip tinh toan L0
        "tach_goc_lom": True,          # BAT BUOC theo TCVN: bat cheo / tach thep tai nut gay khuc goc lom
        "thep_cn_suot": True,          # keo thep chieu nghi suot ra goi dam bien neu khong co dam o nach
        "thep_san_giong": True, "thep_ban_giong": True, "khong_thep_mb": False,
        "thep_tren": True, "thep_duoi": True,
        "cote_chan": None,             # cote chan thang (mm); None = +-0.000
        "d_chu": 12.0, "a_chu": 150.0, # 1: thep chiu luc lop duoi ban nghieng
        "d_mu": 10.0, "a_mu": 150.0,   # 2,3: thep mu / chiu mo-men am tai goi (thuong d10..d12)
        "d_pb": 8.0, "a_pb": 200.0,    # 4: thep phan bo vuong goc (d6..d8 a200)
        "thep_pb": True, "hien_thep": True,
        "bac_dac_trung": True,         # chi ve bac dac trung tren MC de nhan manh cau tao ban thang
    }


def tao_run(p0, u, rong, dai, z0, z1, so_bac=None, day=120.0):
    if so_bac is None:
        so_bac = goi_y_so_bac(z1 - z0)
    u = _unit(u[0], u[1])
    return {
        "p0": [float(p0[0]), float(p0[1])], "u": [u[0], u[1]],
        "rong": float(rong), "dai": float(dai),
        "z0": float(z0), "z1": float(z1),
        "so_bac": int(so_bac), "day": float(day),
        "cn_dau": 1200.0, "cn_cuoi": 1200.0,
        "day_cn_dau": float(day), "day_cn_cuoi": float(day),
    }


def run_tu_poly(poly, u, z0, z1, rong=None, day=120.0, so_bac=None):
    """Tao run tu da giac mat bang + huong u (huong di len)."""
    u = _unit(u[0], u[1])
    v = _normal(u)
    ss = [x * u[0] + y * u[1] for x, y in poly]
    ts = [x * v[0] + y * v[1] for x, y in poly]
    smin, smax, tmin, tmax = min(ss), max(ss), min(ts), max(ts)
    tc = (tmin + tmax) / 2.0
    p0 = (smin * u[0] + tc * v[0], smin * u[1] + tc * v[1])
    return tao_run(p0, u, rong or (tmax - tmin), smax - smin, z0, z1, so_bac, day)


def gan_chieu_nghi(runs, landings, tol=TOL_Z):
    """Voi moi ve: tim chieu nghi dau/cuoi (cung cao do, nam sat dau/cuoi ve)
    de lay chieu dai + day. Khong thay thi giu mac dinh 1200 (hoac 0 neu noi tiep truc tiep sang ve ke tiep)."""
    for r in runs:
        u = r["u"]
        v = _normal(u)
        p0 = r["p0"]
        half = r["rong"] / 2.0
        L = r["dai"]
        dau, cuoi = None, None
        for ld in landings:
            ss, ts = [], []
            for x, y in ld["poly"]:
                dx, dy = x - p0[0], y - p0[1]
                ss.append(dx * u[0] + dy * u[1])
                ts.append(dx * v[0] + dy * v[1])
            if min(max(ts), half) - max(min(ts), -half) < 100.0:
                continue
            smin, smax = min(ss), max(ss)
            if any(abs(z - r["z0"]) <= tol for z in ld["zs"]) and smax <= 100.0 and smin < -50.0:
                c = -smin
                if dau is None or c > dau[0]:
                    dau = (c, ld)
            if any(abs(z - r["z1"]) <= tol for z in ld["zs"]) and smin >= L - 100.0 and smax > L + 50.0:
                c = smax - L
                if cuoi is None or c > cuoi[0]:
                    cuoi = (c, ld)
        if dau:
            r["cn_dau"] = dau[0]
            r["day_cn_dau"] = dau[1].get("day", r["day"])
        if cuoi:
            r["cn_cuoi"] = cuoi[0]
            r["day_cn_cuoi"] = cuoi[1].get("day", r["day"])
        r["_co_cn_dau"] = bool(dau) or bool(r.pop("_fix_cn_dau", False))
        r["_co_cn_cuoi"] = bool(cuoi) or bool(r.pop("_fix_cn_cuoi", False))
        if "_ve_cn_dau_mb" not in r:
            r["_ve_cn_dau_mb"] = bool(dau)
        if "_ve_cn_cuoi_mb" not in r:
            r["_ve_cn_cuoi_mb"] = bool(cuoi)

    # Neu 2 ve lien tiep noi truc tiep (bac cheo winder / khong co chieu nghi o giua) -> khong bia cn = 1200
    for i in range(len(runs) - 1):
        r1, r2 = runs[i], runs[i + 1]
        if r1.get("_co_cn_cuoi") or r2.get("_co_cn_dau"):
            continue
        if abs(r1["z1"] - r2["z0"]) > tol:
            continue
        e1 = (r1["p0"][0] + r1["u"][0] * r1["dai"], r1["p0"][1] + r1["u"][1] * r1["dai"])
        s2 = r2["p0"]
        if math.hypot(e1[0] - s2[0], e1[1] - s2[1]) <= r1["rong"] + r2["rong"] + 200.0:
            r1["cn_cuoi"] = 0.0
            r1["_co_cn_cuoi"] = True
            r1["_ve_cn_cuoi_mb"] = False
            r2["cn_dau"] = 0.0
            r2["_co_cn_dau"] = True
            r2["_ve_cn_dau_mb"] = False


def doan_loai(runs):
    n = len(runs)
    if n <= 1:
        return "1 vế"
    if n == 2:
        u1, u2 = runs[0]["u"], runs[1]["u"]
        return "Chữ L" if abs(u1[0] * u2[0] + u1[1] * u2[1]) < 0.5 else "2 vế"
    return "3 vế" if n == 3 else "4 vế"


def hoan_thien(runs, landings, ten="T1", nguon="tay", ghi_chu=None):
    runs = sorted(runs, key=lambda r: r["z0"])
    gan_chieu_nghi(runs, landings)
    z_cands = [r["z0"] for r in runs] + [r["z_san_dau"] for r in runs if r.get("z_san_dau") is not None]
    zmin = min(z_cands) if z_cands else 0.0
    for r in runs:
        r["z0"] -= zmin
        r["z1"] -= zmin
        if r.get("z_san_dau") is not None:
            r["z_san_dau"] -= zmin
        if r.get("z_san_cuoi") is not None:
            r["z_san_cuoi"] -= zmin
    for ld in landings:
        ld["zs"] = [z - zmin for z in ld["zs"]]
        ld["z"] = ld["z"] - zmin if "z" in ld else ld["zs"][0]
    tt = tt_mac_dinh()
    tt["ten"] = ten
    notes = list(ghi_chu or [])
    for i, r in enumerate(runs, 1):
        if not r.get("_co_cn_dau", True):
            notes.append("Vế %d: chưa thấy chiếu nghỉ đầu, tạm dùng %d mm" % (i, r["cn_dau"]))
        if not r.get("_co_cn_cuoi", True):
            notes.append("Vế %d: chưa thấy chiếu nghỉ cuối, tạm dùng %d mm" % (i, r["cn_cuoi"]))
    return {"ten": ten, "loai": doan_loai(runs), "nguon": nguon, "ghi_chu": notes,
            "runs": runs, "landings": landings, "tt": tt,
            "z_goc": zmin,
            "dam": []}


# ---------------------------------------------------------------- C: nhap tay (kich thuoc chuan VN)
def _rect(P, d, a, b, t0, t1):
    n = _normal(d)

    def pt(s, t):
        return [P[0] + d[0] * s + n[0] * t, P[1] + d[1] * s + n[1] * t]
    return [pt(a, t0), pt(b, t0), pt(b, t1), pt(a, t1)]


def tao_tay(loai="2 vế", rong=1100.0, dai=2700.0, cao=1650.0, khe=150.0, day=140.0, cn=1200.0):
    """Mac dinh chuan VN: 10 bac/ve x cao 165mm x rong bac 270mm => 2h+b = 600mm;
    ban rong 1100mm, day 140mm (dat L0/28 voi nhip ~3.9m), chieu nghi 1200mm, tu dong dat dam."""
    turns = {"1 vế": [], "2 vế": ["U"], "3 vế": ["L", "L"],
             "4 vế": ["L", "L", "L"], "Chữ L": ["L"]}.get(loai, [])
    sg = -1.0
    pos = (0.0, 0.0)
    d = (0.0, 1.0)
    z = 0.0
    runs, landings = [], []
    landings.append({"poly": _rect(pos, d, -cn, 0.0, -rong / 2.0, rong / 2.0), "zs": [0.0], "z": 0.0, "day": day})
    for i in range(len(turns) + 1):
        di = dai[i] if isinstance(dai, (list, tuple)) else dai
        ci = cao[i] if isinstance(cao, (list, tuple)) else cao
        runs.append(tao_run(pos, d, rong, di, z, z + ci, None, day))
        z += ci
        E = (pos[0] + d[0] * di, pos[1] + d[1] * di)
        nrm = _normal(d)
        if i < len(turns):
            if turns[i] == "U":
                off = sg * (rong + khe)
                ts = [-rong / 2.0, rong / 2.0, off - rong / 2.0, off + rong / 2.0]
                landings.append({"poly": _rect(E, d, 0.0, cn, min(ts), max(ts)), "zs": [z], "z": z, "day": day})
                pos = (E[0] + nrm[0] * off, E[1] + nrm[1] * off)
                d = (-d[0], -d[1])
            else:
                landings.append({"poly": _rect(E, d, 0.0, rong, -rong / 2.0, rong / 2.0), "zs": [z], "z": z, "day": day})
                pos = (E[0] + d[0] * rong / 2.0 + nrm[0] * sg * rong / 2.0,
                       E[1] + d[1] * rong / 2.0 + nrm[1] * sg * rong / 2.0)
                d = (nrm[0] * sg, nrm[1] * sg)
        else:
            landings.append({"poly": _rect(E, d, 0.0, cn, -rong / 2.0, rong / 2.0), "zs": [z], "z": z, "day": day})
    t = hoan_thien(runs, landings, "T1", "Nhập tay (chuẩn VN)")
    t["loai"] = loai
    t["z_goc"] = None
    # Dat san he dam chuan thuc te VN: dam chan + dam chieu nghi giua + dam dau
    t["dam"] = dam_mac_dinh(t)
    return t


def dam_mac_dinh(thang, b=220.0, h=350.0):
    """Tao bo dam mac dinh theo so do ban thang gay khuc VN:
    - Dam chan thang (s = -b/2 hoac mep ngoai chieu nghi dau neu co cn)
    - Dam chieu nghi giua (tai bien ngoai chieu nghi trung gian)
    - Dam dau thang (tai bien ngoai chieu nghi tren cung / san tang)
    """
    runs = thang.get("runs") or []
    if not runs:
        return []
    out = []
    d_chan = dam_moi(thang, "chan", 0, b, h)
    if d_chan:
        out.append(d_chan)
    for i in range(len(runs) - 1):
        d_giua = dam_moi(thang, "giua", i, b, h)
        if d_giua:
            out.append(d_giua)
    d_dau = dam_moi(thang, "dau", len(runs) - 1, b, h)
    if d_dau:
        out.append(d_dau)
    return out


def chia_mac_dinh(n, tong):
    """Chia tong so bac cho n ve. 3 ve: ve dau/cuoi ngan (~20%), ve giua dai (~60%)."""
    if n <= 1:
        return [tong]
    if n == 3:
        a = max(1, int(round(tong * 0.2)))
        return [a, max(1, tong - 2 * a), a]
    base = tong // n
    ds = [base] * n
    for i in range(tong - base * n):
        ds[i] += 1
    return ds


def doi_loai(thang, loai, chia=None):
    """Doi loai thang (1/2/3/4 ve, Chu L) va dung lai theo SO BAC tung ve."""
    n = {"1 vế": 1, "2 vế": 2, "3 vế": 3, "4 vế": 4, "Chữ L": 2}.get(loai, 1)
    runs = thang.get("runs") or []
    if runs:
        r_ref = max(runs, key=lambda r: r["dai"])
        tot_h = sum(max(r["z1"] - r["z0"], 1.0) for r in runs)
        tot_b = max(sum(max(int(r["so_bac"]), 1) for r in runs), 1)
        riser = tot_h / tot_b
        so_ref = max(r_ref["so_bac"], 1)
        going = r_ref["dai"] / so_ref
        tong = max(1, int(round(tot_h / riser)))
        rong, day = r_ref["rong"], r_ref["day"]
        cn = r_ref["cn_cuoi"] if r_ref["cn_cuoi"] >= 700.0 else 1200.0
    else:
        riser, going, tong, rong, day, cn = 165.0, 270.0, 20, 1100.0, 140.0, 1200.0
    ghi = []
    if chia and len(chia) == n and all(c >= 1 for c in chia):
        counts = [int(c) for c in chia]
        if sum(counts) != tong:
            ghi.append("Tổng số bậc %d khác thang gốc %d -> tổng cao thay đổi theo" % (sum(counts), tong))
    else:
        counts = chia_mac_dinh(n, tong)
    t = tao_tay(loai, rong=rong, dai=[c * going for c in counts],
                cao=[c * riser for c in counts], day=day, cn=cn)
    for r, c in zip(t["runs"], counts):
        r["so_bac"] = c
    t["tt"] = thang["tt"]
    t["ten"] = thang.get("ten", "T1")
    t["loai"] = loai
    t["nguon"] = "Nhập tay (chia lại từ: %s)" % thang.get("nguon", "")
    t["ghi_chu"] = ghi + ["Chia %d bậc thành %s (cao bậc %d, bước bậc %d)" % (
        sum(counts), "-".join(str(c) for c in counts), round(riser), round(going))]
    return t


# ---------------------------------------------------------------- A: Stairs
def tach_duong_di_ve(polylines):
    """Noi cac doan duong di (GetStairsPath) theo thu tu lien tuc roi tach thanh cac ve thang theo huong.
    Moi polyline trong polylines la list [(x, y), ...] (mm).
    Tra ve list dict {"p0": (x,y), "p1": (x,y), "u": (ux,uy), "dai": mm, "arc_len": mm}.
    """
    cleaned = []
    for pl in polylines or []:
        pts = [(float(p[0]), float(p[1])) for p in pl]
        if len(pts) < 2:
            continue
        tot = sum(math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(len(pts) - 1))
        if tot >= 10.0:
            cleaned.append(pts)
    if not cleaned:
        return []

    # Xep chuoi lien tuc (noi dau-duoi gan nhat) va theo doi chieu da so cac curve goc
    used = [False] * len(cleaned)
    used[0] = True
    chains = [list(cleaned[0])]
    chain_votes = [[1]]  # +1: cung chieu goc, -1: bi dao chieu khi noi
    while not all(used):
        cur = chains[-1]
        head, tail = cur[0], cur[-1]
        best = None
        for idx, pl in enumerate(cleaned):
            if used[idx]:
                continue
            d_ts = math.hypot(pl[0][0] - tail[0], pl[0][1] - tail[1])
            d_te = math.hypot(pl[-1][0] - tail[0], pl[-1][1] - tail[1])
            d_hs = math.hypot(pl[0][0] - head[0], pl[0][1] - head[1])
            d_he = math.hypot(pl[-1][0] - head[0], pl[-1][1] - head[1])
            cand = min((d_ts, "ts", idx), (d_te, "te", idx), (d_hs, "hs", idx), (d_he, "he", idx))
            if best is None or cand[0] < best[0]:
                best = cand
        dist, mode, idx = best
        used[idx] = True
        pl = cleaned[idx]
        if dist <= 500.0:
            if mode == "ts":
                cur.extend(pl[1:])
                chain_votes[-1].append(1)
            elif mode == "te":
                cur.extend(list(reversed(pl))[1:])
                chain_votes[-1].append(-1)
            elif mode == "he":
                chains[-1] = pl + cur[1:]
                chain_votes[-1].append(1)
            else:  # hs
                chains[-1] = list(reversed(pl)) + cur[1:]
                chain_votes[-1].append(-1)
        else:
            chains.append(list(pl))
            chain_votes.append([1])
    for ci in range(len(chains)):
        if sum(chain_votes[ci]) < 0:
            chains[ci] = list(reversed(chains[ci]))

    # Tach thanh cac doan don gian >= 30mm
    raw_segs = []
    for ch in chains:
        for i in range(len(ch) - 1):
            a, b = ch[i], ch[i + 1]
            l = math.hypot(b[0] - a[0], b[1] - a[1])
            if l >= 30.0:
                raw_segs.append((a, b, l, _unit(b[0] - a[0], b[1] - a[1])))
    if not raw_segs:
        # Fallback: lay noi 2 dau mut cua chuoi dau tien
        p0, p1 = chains[0][0], chains[0][-1]
        l = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        return [{"p0": p0, "p1": p1, "u": _unit(p1[0] - p0[0], p1[1] - p0[1]), "dai": l, "arc_len": l}] if l > 1.0 else []

    # Gom cac doan thang cung huong
    groups = []
    cur = {
        "p0": raw_segs[0][0], "p1": raw_segs[0][1],
        "u0": raw_segs[0][3], "u_prev": raw_segs[0][3],
        "ux": raw_segs[0][1][0] - raw_segs[0][0][0],
        "uy": raw_segs[0][1][1] - raw_segs[0][0][1],
        "arc_len": raw_segs[0][2],
    }
    for a, b, l, u_k in raw_segs[1:]:
        u_avg = _unit(cur["ux"], cur["uy"])
        cont = math.hypot(a[0] - cur["p1"][0], a[1] - cur["p1"][1]) <= 500.0
        if cont and _ang_diff(u_k, u_avg) <= 22.0 and _ang_diff(u_k, cur["u0"]) <= 32.0:
            cur["p1"] = b
            cur["u_prev"] = u_k
            cur["ux"] += (b[0] - a[0])
            cur["uy"] += (b[1] - a[1])
            cur["arc_len"] += l
        else:
            groups.append(cur)
            cur = {"p0": a, "p1": b, "u0": u_k, "u_prev": u_k,
                   "ux": b[0] - a[0], "uy": b[1] - a[1], "arc_len": l}
    groups.append(cur)

    # Bo cac doan nhieu qua ngan (< 150 mm) neu co it nhat 1 doan chinh >= 150 mm
    main_groups = [g for g in groups if math.hypot(g["p1"][0] - g["p0"][0], g["p1"][1] - g["p0"][1]) >= 150.0]
    if not main_groups:
        main_groups = groups

    out = []
    for g in main_groups:
        p0, p1 = g["p0"], g["p1"]
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        dai = math.hypot(dx, dy)
        if dai < 10.0:
            continue
        out.append({"p0": p0, "p1": p1, "u": _unit(dx, dy), "dai": dai, "arc_len": max(dai, g["arc_len"])})
    return out


def tu_stairs(raw_runs, raw_landings, riser=None):
    runs = []
    for rr in raw_runs:
        h = rr["z1"] - rr["z0"]
        sb = rr.get("so_bac") or (int(round(h / riser)) if riser and riser > 1 else None)
        run = run_tu_poly(rr["poly"], rr["u"], rr["z0"], rr["z1"], rr.get("rong"), rr.get("day") or 120.0, sb)
        if rr.get("cn_dau") is not None:
            run["cn_dau"] = float(rr["cn_dau"])
            run["_fix_cn_dau"] = True
        if rr.get("cn_cuoi") is not None:
            run["cn_cuoi"] = float(rr["cn_cuoi"])
            run["_fix_cn_cuoi"] = True
        for k in ("_ve_cn_dau_mb", "_ve_cn_cuoi_mb"):
            if k in rr:
                run[k] = bool(rr[k])
        for k in ("bac_cn_dau", "bac_cn_cuoi"):
            if rr.get(k):
                run[k] = int(rr[k])
        for k in ("z_san_dau", "z_san_cuoi"):
            if rr.get(k) is not None:
                run[k] = float(rr[k])
        runs.append(run)
    lds = []
    for l in raw_landings:
        ld = {"poly": [[p[0], p[1]] for p in l["poly"]], "zs": list(l["zs"]),
              "z": l["zs"][-1], "day": l.get("day", 120.0)}
        if l.get("bac"):
            ld["bac"] = int(l["bac"])
        lds.append(ld)
    return hoan_thien(runs, lds, "T1", "Stairs")


# ---------------------------------------------------------------- B: Generic Model
def _nhom(items):
    groups = []
    for it in items:
        n = it["n"]
        d = n[0] * it["pts"][0][0] + n[1] * it["pts"][0][1] + n[2] * it["pts"][0][2]
        for g in groups:
            gn = g["n"]
            if (n[0] * gn[0] + n[1] * gn[1] + n[2] * gn[2]) > 0.999 and abs(d - g["d"]) < 5.0:
                g["pts"].extend(it["pts"])
                break
        else:
            groups.append({"n": n, "d": d, "pts": list(it["pts"])})
    return groups


def _ang_diff(u1, u2):
    d = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
    return math.degrees(math.acos(d))


def _gop_mat_ngang(hor_top):
    """Gop cac manh hor_top cung cao do (<= 12mm) va gan nhau trong XY (<= 80mm) thanh tung mat bac / chieu nghi."""
    items = []
    for it in hor_top:
        pts = it["pts"]
        if len(pts) < 3:
            continue
        area = sum(abs(_area_xy(lp)) for lp in it["loops"])
        if area < 12000.0:
            continue
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        z = sum(p[2] for p in pts) / len(pts)
        items.append({
            "z": z,
            "pts": list(pts),
            "loops": list(it["loops"]),
            "area": area,
            "xmin": min(xs), "xmax": max(xs),
            "ymin": min(ys), "ymax": max(ys),
        })
    n = len(items)
    used = [False] * n
    merged = []
    for i in range(n):
        if used[i]:
            continue
        used[i] = True
        comp = [items[i]]
        q = [items[i]]
        while q:
            cur = q.pop()
            for j in range(n):
                if used[j]:
                    continue
                cand = items[j]
                if abs(cand["z"] - cur["z"]) > 15.0:
                    continue
                if (cand["xmax"] < cur["xmin"] - 80.0 or cand["xmin"] > cur["xmax"] + 80.0 or
                        cand["ymax"] < cur["ymin"] - 80.0 or cand["ymin"] > cur["ymax"] + 80.0):
                    continue
                used[j] = True
                comp.append(cand)
                q.append(cand)
        all_pts = [p for c in comp for p in c["pts"]]
        all_loops = [lp for c in comp for lp in c["loops"]]
        tot_area = sum(c["area"] for c in comp)
        xs = [p[0] for p in all_pts]
        ys = [p[1] for p in all_pts]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        z = sum(c["z"] * c["area"] for c in comp) / max(tot_area, 1.0)
        # Tinh tam theo trung binh dinh hop nhat hoac loop lon nhat
        big_lp = max(all_loops, key=lambda lp: abs(_area_xy(lp)))
        cx = sum(p[0] for p in big_lp) / len(big_lp)
        cy = sum(p[1] for p in big_lp) / len(big_lp)
        if len(comp) > 1:
            cx = (xmin + xmax) / 2.0
            cy = (ymin + ymax) / 2.0
        dx, dy = xmax - xmin, ymax - ymin
        is_landing = (tot_area >= 7.2e5 and min(dx, dy) >= 680.0)
        merged.append({
            "z": z, "pts": all_pts, "loops": all_loops, "big_loop": big_lp,
            "area": tot_area, "xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax,
            "cx": cx, "cy": cy, "is_landing": is_landing,
        })
    merged.sort(key=lambda m: m["z"])
    return merged


def _tim_huong_co_bac(A, B, vert_faces):
    """Tim vector huong di len u tu mat bac A (duoi) len mat bac B (tren) qua mat dung co bac."""
    z_lo, z_hi = A["z"], B["z"]
    # Vung giao/lan can giua A va B
    x0 = max(A["xmin"], B["xmin"]) - 220.0
    x1 = min(A["xmax"], B["xmax"]) + 220.0
    y0 = max(A["ymin"], B["ymin"]) - 220.0
    y1 = min(A["ymax"], B["ymax"]) + 220.0
    dcx, dcy = B["cx"] - A["cx"], B["cy"] - A["cy"]
    best = None
    for vf in vert_faces:
        pts = vf["pts"]
        zs = [p[2] for p in pts]
        zmin, zmax = min(zs), max(zs)
        if zmax - zmin > 360.0 or zmin > z_lo + 30.0 or zmax < z_hi - 30.0:
            continue
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        vcx, vcy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
        if not (x0 <= vcx <= x1 and y0 <= vcy <= y1):
            continue
        span = math.hypot(max(xs) - min(xs), max(ys) - min(ys))
        if span < 180.0:
            continue
        nx, ny, _ = vf["n"]
        u = _unit(-nx, -ny)
        # Kiem tra chieu tu A -> B
        dot_ab = dcx * u[0] + dcy * u[1]
        if dot_ab < -5.0:
            u = (-u[0], -u[1])
        elif abs(dot_ab) <= 5.0:
            # Dung vi tri tam B so voi tam co bac (hoac tam co bac so voi tam A)
            if (B["cx"] - vcx) * u[0] + (B["cy"] - vcy) * u[1] < 0:
                u = (-u[0], -u[1])
        if best is None or span > best[0]:
            best = (span, u, pts)
    if best is not None:
        return best[1], best[2]
    return _unit(dcx, dcy), None


def _do_day_tu_bot(p0, u, dai, rong, z0, z1, bot_faces):
    """Do be day ban vuong goc mat nghieng tu cac mat day nghieng ben duoi ve."""
    v = _normal(u)
    kk = (z1 - z0) / max(dai, 1.0)
    ca = dai / math.hypot(dai, z1 - z0) if dai > 0 else 1.0
    vals = []
    for bf in bot_faces:
        pts = bf["pts"]
        zc = sum(p[2] for p in pts) / len(pts)
        if not (z0 - 700.0 <= zc <= z1 + 150.0):
            continue
        cx = sum(p[0] for p in pts) / len(pts)
        cy = sum(p[1] for p in pts) / len(pts)
        s = (cx - p0[0]) * u[0] + (cy - p0[1]) * u[1]
        t = (cx - p0[0]) * v[0] + (cy - p0[1]) * v[1]
        if -250.0 <= s <= dai + 250.0 and abs(t) <= rong / 2.0 + 250.0:
            z_top_line = z0 + kk * max(0.0, min(dai, s))
            dv = z_top_line - zc
            day_perp = dv * ca
            if 60.0 <= day_perp <= 450.0:
                vals.append(day_perp)
    if not vals:
        return None
    vals.sort()
    return vals[len(vals) // 2]


def _nhan_dang_tu_bac(hor_top, vert_faces, bot_faces):
    """Nhan dang cac ve thang tu chuoi mat bac ngang + mat dung co bac (ho tro bac cheo winder & ve ngan)."""
    levels = _gop_mat_ngang(hor_top)
    if len(levels) < 3:
        return [], []

    # Noi cac bac tang dan lien tiep (75..260 mm) thanh danh sach buoc chuyen (transitions)
    trans = []
    for i, A in enumerate(levels):
        best_j = None
        best_score = None
        for j in range(i + 1, len(levels)):
            B = levels[j]
            dz = B["z"] - A["z"]
            if dz < 75.0:
                continue
            if dz > 260.0:
                break
            # Kiem tra giao nhau / lan can XY
            if (B["xmax"] < A["xmin"] - 220.0 or B["xmin"] > A["xmax"] + 220.0 or
                    B["ymax"] < A["ymin"] - 220.0 or B["ymin"] > A["ymax"] + 220.0):
                continue
            dist_xy = math.hypot(B["cx"] - A["cx"], B["cy"] - A["cy"])
            if best_score is None or dist_xy < best_score:
                best_score = dist_xy
                best_j = j
        if best_j is not None:
            B = levels[best_j]
            u, rpts = _tim_huong_co_bac(A, B, vert_faces)
            trans.append({"i": i, "j": best_j, "A": A, "B": B, "u": u, "rpts": rpts})

    if len(trans) < 2:
        return [], [lv for lv in levels if lv["is_landing"]]

    # Tach thanh cac chuoi lien tuc theo thu tu tang bac (ngat khi gap chieu nghi o giua)
    chains = []
    cur_chain = [trans[0]]
    for k in range(1, len(trans)):
        prev = cur_chain[-1]
        cur = trans[k]
        lien_tiep = (cur["i"] == prev["j"]) and not prev["B"]["is_landing"]
        if lien_tiep:
            cur_chain.append(cur)
        else:
            chains.append(cur_chain)
            cur_chain = [cur]
    chains.append(cur_chain)

    # Trong moi chuoi lien tuc, gom nhom cac ve thang theo huong (giu duoc ca winder 2-4 bac lan ve thang)
    flight_groups = []
    for ch in chains:
        m = len(ch)
        if m == 1:
            flight_groups.append(ch)
            continue
        # Tim cac doan thang dai (>= 3 bac lien tiep lech <= 20 do)
        is_anchor = [False] * m
        i = 0
        while i < m:
            j = i + 1
            ux, uy = ch[i]["u"]
            while j < m:
                u_ref = _unit(ux, uy)
                if _ang_diff(ch[j]["u"], u_ref) <= 20.0:
                    ux += ch[j]["u"][0]
                    uy += ch[j]["u"][1]
                    j += 1
                else:
                    break
            if j - i >= 3:
                for k in range(i, j):
                    is_anchor[k] = True
                i = j
            else:
                i += 1

        # Tach chuoi thanh cac ve
        i = 0
        while i < m:
            if is_anchor[i]:
                j = i + 1
                ux, uy = ch[i]["u"]
                while j < m and is_anchor[j]:
                    u_ref = _unit(ux, uy)
                    if _ang_diff(ch[j]["u"], u_ref) <= 22.0:
                        ux += ch[j]["u"][0]
                        uy += ch[j]["u"][1]
                        j += 1
                    else:
                        break
                flight_groups.append(ch[i:j])
                i = j
            else:
                # Doan chuyen huong / winder / ve ngan
                j = i + 1
                sweep = 0.0
                while j < m and not is_anchor[j]:
                    step_ang = _ang_diff(ch[j - 1]["u"], ch[j]["u"])
                    if step_ang > 65.0:
                        break
                    if sweep + step_ang > 115.0:
                        break
                    sweep += step_ang
                    j += 1
                flight_groups.append(ch[i:j])
                i = j

    # Tao run tu moi nhom bac
    runs = []
    for grp in flight_groups:
        ux = sum(t["u"][0] for t in grp)
        uy = sum(t["u"][1] for t in grp)
        if math.hypot(ux, uy) < 0.2:
            # Winder quay gap: lay vector tu tam bac dau den tam bac cuoi
            u = _unit(grp[-1]["B"]["cx"] - grp[0]["A"]["cx"], grp[-1]["B"]["cy"] - grp[0]["A"]["cy"])
        else:
            u = _unit(ux, uy)
        v = _normal(u)

        # Lay diem cac mat bac THUOC VE NAY (B cua moi buoc tru buoc cuoi neu B la chieu nghi, cong them cac co bac)
        # Luu y: A cua buoc dau grp[0] la san/chieu nghi hoac bac cuoi cua ve truoc -> dung co bac grp[0]["rpts"] lam mep dau!
        pts = []
        for idx_t, t in enumerate(grp):
            if idx_t > 0 and not t["A"]["is_landing"]:
                pts.extend(t["A"]["pts"])
            if t["rpts"]:
                pts.extend(t["rpts"])
            if not t["B"]["is_landing"]:
                pts.extend(t["B"]["pts"])
        if len(pts) < 3:
            pts = [p for t in grp for p in (t["A"]["pts"] + t["B"]["pts"])]

        ss = [p[0] * u[0] + p[1] * u[1] for p in pts]
        ts = [p[0] * v[0] + p[1] * v[1] for p in pts]
        smin, smax = min(ss), max(ss)
        tmin, tmax = min(ts), max(ts)
        rong = max(400.0, tmax - tmin)
        dai = max(250.0, smax - smin)
        tc = (tmin + tmax) / 2.0
        p0 = (smin * u[0] + tc * v[0], smin * u[1] + tc * v[1])
        z0 = grp[0]["A"]["z"]
        z1 = grp[-1]["B"]["z"]
        day_raw = _do_day_tu_bot(p0, u, dai, rong, z0, z1, bot_faces)
        run_obj = tao_run(p0, u, rong, dai, z0, z1, len(grp), day_raw or 120.0)
        run_obj["_day_ok"] = (day_raw is not None and day_raw >= 85.0)
        runs.append(run_obj)

    if runs:
        measured = [r for r in sorted(runs, key=lambda x: -x["dai"]) if r.get("_day_ok")]
        shared_day = measured[0]["day"] if measured else 130.0
        for r in runs:
            if not r.pop("_day_ok", False) or (r["dai"] <= 1.25 * r["rong"] and abs(r["day"] - shared_day) > 12.0):
                r["day"] = shared_day
                r["day_cn_dau"] = shared_day
                r["day_cn_cuoi"] = shared_day

    landing_levels = [lv for lv in levels if lv["is_landing"]]
    return runs, landing_levels


def tu_faces_steps_only(faces, riser=None):
    """Ham phu giup doc_stairs tach nhieu ve tu hinh hoc 3D cua Stairs khi GetStairsPath chi co 1 doan."""
    hor_top, vert_faces, bot_faces = [], [], []
    for f in faces:
        nx, ny, nz = f["n"]
        l = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        nx, ny, nz = nx / l, ny / l, nz / l
        pts = [p for lp in f["loops"] for p in lp]
        if len(pts) < 3:
            continue
        it = {"n": (nx, ny, nz), "pts": pts, "loops": f["loops"]}
        if nz > 0.99:
            hor_top.append(it)
        elif abs(nz) <= 0.15:
            vert_faces.append(it)
        elif -0.99 <= nz < -0.15:
            bot_faces.append(it)
    runs, _ = _nhan_dang_tu_bac(hor_top, vert_faces, bot_faces)
    return runs


def tu_faces(faces):
    inc_top, inc_bot, hor_top, hor_bot, vert_faces = [], [], [], [], []
    for f in faces:
        nx, ny, nz = f["n"]
        l = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        nx, ny, nz = nx / l, ny / l, nz / l
        pts = [p for lp in f["loops"] for p in lp]
        if len(pts) < 3:
            continue
        it = {"n": (nx, ny, nz), "pts": pts, "loops": f["loops"]}
        if nz > 0.99:
            hor_top.append(it)
        elif nz < -0.99:
            hor_bot.append(it)
        elif 0.15 < nz <= 0.99:
            inc_top.append(it)
        elif -0.99 <= nz < -0.15:
            inc_bot.append(it)
        else:
            vert_faces.append(it)
    notes = []
    top_g, bot_g = _nhom(inc_top), _nhom(inc_bot)

    # Uu tien nhan dang tu cac mat bac ngang + co bac dung (giai quyet thang xe bac / winder / nhieu ve)
    step_runs, step_lds = _nhan_dang_tu_bac(hor_top, vert_faces, inc_bot)
    runs = []
    if step_runs:
        runs = step_runs
        _log("  Nhận dạng theo mặt bậc 3D: tìm thấy %d vế (%s bậc)" % (
            len(runs), "-".join(str(r["so_bac"]) for r in runs)))
        notes.append("Nhận dạng theo các mặt bậc 3D: %d vế (%s bậc)" % (
            len(runs), "-".join(str(r["so_bac"]) for r in runs)))
    else:
        for g in top_g:
            nx, ny, nz = g["n"]
            u = _unit(-nx, -ny)
            v = _normal(u)
            ss = [p[0] * u[0] + p[1] * u[1] for p in g["pts"]]
            ts = [p[0] * v[0] + p[1] * v[1] for p in g["pts"]]
            zs = [p[2] for p in g["pts"]]
            nho = (max(ss) - min(ss)) < 200 or (max(ts) - min(ts)) < 250
            _log("  nghiêng TRÊN: n=(%.2f,%.2f,%.2f) dài %d rộng %d z %d->%d %s" % (
                nx, ny, nz, max(ss) - min(ss), max(ts) - min(ts), min(zs), max(zs), "-> BỎ (quá nhỏ)" if nho else "-> VẾ"))
            if nho:
                continue
            day = None
            for b in bot_g:
                bn = b["n"]
                if (bn[0] * nx + bn[1] * ny + bn[2] * nz) < -0.998:
                    dist = abs(g["d"] + b["d"])
                    if dist > 20 and (day is None or dist < day):
                        day = dist
            if day is None:
                day = 120.0
                notes.append("Không đo được bề dày bản, tạm dùng 120 mm")
            tc = (min(ts) + max(ts)) / 2.0
            p0 = (min(ss) * u[0] + tc * v[0], min(ss) * u[1] + tc * v[1])
            runs.append(tao_run(p0, u, max(ts) - min(ts), max(ss) - min(ss), min(zs), max(zs), None, day))

        for b in bot_g:
            bn = b["n"]
            khop = any((bn[0] * g["n"][0] + bn[1] * g["n"][1] + bn[2] * g["n"][2]) < -0.998 for g in top_g)
            if khop:
                continue
            nx, ny, nz = -bn[0], -bn[1], -bn[2]
            u = _unit(-nx, -ny)
            v = _normal(u)
            ss = [p[0] * u[0] + p[1] * u[1] for p in b["pts"]]
            ts = [p[0] * v[0] + p[1] * v[1] for p in b["pts"]]
            zs = [p[2] for p in b["pts"]]
            nho = (max(ss) - min(ss)) < 200 or (max(ts) - min(ts)) < 250
            if nho:
                continue
            dz = 120.0 / max(abs(nz), 0.2)
            tc = (min(ts) + max(ts)) / 2.0
            p0 = (min(ss) * u[0] + tc * v[0], min(ss) * u[1] + tc * v[1])
            runs.append(tao_run(p0, u, max(ts) - min(ts), max(ss) - min(ss), min(zs) + dz, max(zs) + dz, None, 120.0))
            notes.append("Một vế chỉ thấy mặt dưới bản: bề dày và cao độ là ước lượng (dày 120)")

    landings = []
    nguon_ld = step_lds if step_runs else [
        {"z": sum(p[2] for p in it["pts"]) / len(it["pts"]),
         "big_loop": max(it["loops"], key=lambda lp: abs(_area_xy(lp))),
         "cx": sum(p[0] for p in it["pts"]) / len(it["pts"]),
         "cy": sum(p[1] for p in it["pts"]) / len(it["pts"])}
        for it in hor_top
        if abs(_area_xy(max(it["loops"], key=lambda lp: abs(_area_xy(lp))))) >= 6.5e5
    ]
    for lv in nguon_ld:
        loop = lv["big_loop"]
        z = lv["z"]
        cx, cy = lv["cx"], lv["cy"]
        zb_best = None
        for hb in hor_bot:
            zb = sum(p[2] for p in hb["pts"]) / len(hb["pts"])
            if zb >= z - 20:
                continue
            xs = [p[0] for p in hb["pts"]]
            ys = [p[1] for p in hb["pts"]]
            if min(xs) - 1 <= cx <= max(xs) + 1 and min(ys) - 1 <= cy <= max(ys) + 1:
                if zb_best is None or zb > zb_best:
                    zb_best = zb
        landings.append({"poly": [[p[0], p[1]] for p in loop], "zs": [z], "z": z,
                         "day": (z - zb_best) if zb_best is not None else 120.0})

    # Giu nguyen tat ca cac ve (ke ca ve ngan 2-4 bac o dau/cuoi thang 3 ve, chu L, winder)
    runs = sorted(runs, key=lambda r: r["z0"])
    if len(runs) >= 2:
        r_mid = max(runs, key=lambda x: x["dai"])
        shared_day = r_mid["day"] if r_mid["day"] >= 85.0 else 130.0
        for r in runs:
            if r["day"] < 85.0 or (r["dai"] <= 1.25 * r["rong"] and abs(r["day"] - shared_day) > 12.0):
                r["day"] = shared_day
                r["day_cn_dau"] = shared_day
                r["day_cn_cuoi"] = shared_day

    notes.append("Thống kê mặt: nghiêng trên %d nhóm, nghiêng dưới %d nhóm, ngang trên %d, ngang dưới %d -> %d vế, %d chiếu nghỉ" % (
        len(top_g), len(bot_g), len(hor_top), len(hor_bot), len(runs), len(landings)))
    if not runs:
        notes.append("Không tìm thấy mặt bản thang nghiêng trong đối tượng đã chọn")
    t = hoan_thien(runs, landings, "T1", "Generic Model", notes)
    if not step_runs:
        t["ghi_chu"].append("Số bậc là gợi ý (chiều cao / 165) - hãy chỉnh theo thiết kế")
    return t


# ---------------------------------------------------------------- cote + dam thang
DAM_TEN = {"chan": "D.chân", "giua": "D.giữa", "dau": "D.đầu"}


def neo_moc(tt):
    """Chuoi 'neo_keo/neo_nen' (vd 35/25) -> (neo_keo x d, neo_nen x d, moc_cau_tao x d).
    Luu y TCVN 5574:2018: 35/25 la neo keo/nen, moc cau tao uon 90 do chi ~ 8d (bi gioi han boi hb - 2*abv).
    """
    moc = float(tt.get("moc_d", 8.0) or 8.0)
    try:
        a = str(tt.get("neo", "35/25")).replace(",", ".").split("/")
        neo_keo = float(a[0])
        neo_nen = float(a[1]) if len(a) > 1 else neo_keo * 0.7
        return max(10.0, neo_keo), max(10.0, neo_nen), max(4.0, min(moc, 15.0))
    except Exception:
        return 35.0, 25.0, 8.0


def cote_mm(thang, z):
    c = thang["tt"].get("cote_chan")
    return (c if c is not None else 0.0) + z


def fmt_cote(v):
    m = v / 1000.0
    return "±0.000" if abs(m) < 0.0005 else "%+.3f" % m


def doi_z1(thang, i, z1):
    runs = thang["runs"]
    r = runs[i]
    if z1 <= r["z0"] + 10.0:
        return False
    old = r["z1"]
    delta = z1 - old
    r["z1"] = z1
    for rr in runs[i + 1:]:
        rr["z0"] += delta
        rr["z1"] += delta
    for ld in thang["landings"]:
        if ld["z"] > old - TOL_Z:
            ld["zs"] = [z + delta for z in ld["zs"]]
            ld["z"] += delta
    for d in thang.get("dam", []):
        if d["ztop"] > old - TOL_Z:
            d["ztop"] += delta
    return True


def dam_trong_ve(r, d):
    u = r["u"]
    v = _normal(u)
    p0 = r["p0"]
    dx, dy = d["x"] - p0[0], d["y"] - p0[1]
    return dx * u[0] + dy * u[1], dx * v[0] + dy * v[1], abs(d["dx"] * u[0] + d["dy"] * u[1])


def dam_hien_o_ve(r, d):
    """Dam ngang (vuong goc ve) cat qua be rong ve va nam trong doan chieu nghi dau .. chieu nghi cuoi."""
    s, t, c = dam_trong_ve(r, d)
    z_lo = min(r["z0"], r.get("z_san_dau", r["z0"])) - 800.0
    z_hi = max(r["z1"], r.get("z_san_cuoi", r["z1"])) + 900.0
    z_ok = z_lo <= d["ztop"] <= z_hi
    return (c < 0.5 and z_ok and abs(t) <= r["rong"] / 2.0 + d["len"] / 2.0
            and -r["cn_dau"] - d["b"] <= s <= r["dai"] + r["cn_cuoi"] + d["b"])


def phan_loai_dam(thang, d):
    runs = thang["runs"]
    n = len(runs)
    for i, r in enumerate(runs):
        if not dam_hien_o_ve(r, d):
            continue
        s = dam_trong_ve(r, d)[0]
        if s < 300.0:
            return "chan" if i == 0 else "giua"
        if s > r["dai"] - 300.0:
            return "dau" if i == n - 1 else "giua"
        return "giua"
    return None


def dam_dat_s(r, d, s):
    u = r["u"]
    v = _normal(u)
    p0 = r["p0"]
    t = (d["x"] - p0[0]) * v[0] + (d["y"] - p0[1]) * v[1]
    d["x"] = p0[0] + u[0] * s + v[0] * t
    d["y"] = p0[1] + u[1] * s + v[1] * t


def dam_poly(d):
    nx, ny = -d["dy"], d["dx"]
    hl, hb = d["len"] / 2.0, d["b"] / 2.0
    return [(d["x"] + d["dx"] * a + nx * c, d["y"] + d["dy"] * a + ny * c)
            for a, c in ((-hl, -hb), (hl, -hb), (hl, hb), (-hl, hb))]


def dam_moi(thang, vi_tri, ve=0, b=220.0, h=350.0):
    """Tao dam thu cong o chan / giua / dau thang theo thuc te VN:
    - 'chan': ngay chan ve 0 (s = -b/2)
    - 'giua': tai bien ngoai chieu nghi giua tang (s = dai + cn_cuoi - b/2)
    - 'dau': tai bien ngoai chieu nghi tren (s = dai + cn_cuoi - b/2)
    """
    runs = thang["runs"]
    if not runs:
        return None
    n = len(runs)
    if vi_tri == "chan":
        r = runs[0]
        s, z = -b / 2.0, r["z0"]
    elif vi_tri == "dau":
        r = runs[-1]
        s = r["dai"] + r["cn_cuoi"] - b / 2.0
        z = r.get("z_san_cuoi", r["z1"])
        if z > r["z1"] + 10.0:
            h = max(h, (z - r["z1"]) + r["day_cn_cuoi"] + 80.0)
    elif n == 1:
        r = runs[0]
        s, z = r["dai"] / 2.0, (r["z0"] + r["z1"]) / 2.0
    else:
        r = runs[min(max(int(ve), 0), n - 2)]
        s, z = r["dai"] + r["cn_cuoi"] - b / 2.0, r["z1"]
    u = r["u"]
    v = _normal(u)
    p0 = r["p0"]
    return {"vi_tri": vi_tri, "x": p0[0] + u[0] * s, "y": p0[1] + u[1] * s,
            "dx": v[0], "dy": v[1], "len": r["rong"], "b": b, "h": h, "ztop": z, "nguon": "thủ công"}


# ---------------------------------------------------------------- Kiem tra TCVN & tinh toan thep chuan VN
def kiem_tra_tieu_chuan(thang, idx=0):
    """Kiem tra thong so hinh hoc & cau tao ban thang theo TCVN 4319:2012 & TCVN 5574:2018.
    Tra ve dict gom cac chi so va danh sach canh bao / dat chuan.
    """
    runs = thang.get("runs") or []
    tt = thang.get("tt") or {}
    if not runs or idx >= len(runs):
        return {"ok": False, "items": []}
    r = runs[idx]
    n = max(1, int(r["so_bac"]))
    L = max(float(r["dai"]), 1.0)
    H = max(float(r["z1"] - r["z0"]), 1.0)
    h = H / n
    b = L / n
    cong_thuc = 2.0 * h + b
    goc = math.degrees(math.atan2(H, L))
    dams = thang.get("dam", [])
    goi = _tim_goi_ve(r, dams)
    L0 = goi["s_cuoi"] - goi["s_dau"]
    day = float(r["day"])
    ty_le_day = L0 / max(day, 1.0)
    abv = float(tt.get("abv", 20.0))
    d1 = float(tt.get("d_chu", 12.0))
    a1 = float(tt.get("a_chu", 150.0))
    a3 = float(tt.get("a_pb", 200.0))

    items = []
    # 1. Chieu cao bac h: 150..180 mm
    ok_h = 145.0 <= h <= 185.0
    items.append({
        "ten": "Chiều cao bậc (h)", "gia_tri": "%.1f mm" % h,
        "chuan": "150 – 180 mm", "dat": ok_h,
        "ghi_chu": "Đạt" if ok_h else ("Hơi thấp" if h < 145.0 else "Quá dốc, nên tăng số bậc")
    })
    # 2. Mat bac b: 250..300 mm
    ok_b = 240.0 <= b <= 320.0
    items.append({
        "ten": "Bề rộng mặt bậc (b)", "gia_tri": "%.1f mm" % b,
        "chuan": "250 – 300 mm", "dat": ok_b,
        "ghi_chu": "Đạt" if ok_b else ("Mặt bậc hẹp" if b < 240.0 else "Mặt bậc quá rộng")
    })
    # 3. 2h + b: 600..640 mm (chap nhan 580..650)
    ok_2hb = 580.0 <= cong_thuc <= 650.0
    items.append({
        "ten": "Công thức bước chân (2h+b)", "gia_tri": "%.0f mm" % cong_thuc,
        "chuan": "600 – 640 mm", "dat": ok_2hb,
        "ghi_chu": "Tối ưu" if 595 <= cong_thuc <= 640 else ("Chấp nhận" if ok_2hb else "Cần chỉnh số bậc hoặc chiều dài vế")
    })
    # 4. Do doc thang
    ok_goc = 24.0 <= goc <= 38.0
    items.append({
        "ten": "Độ dốc vế thang (α)", "gia_tri": "%.1f°" % goc,
        "chuan": "25° – 38°", "dat": ok_goc,
        "ghi_chu": "Đạt" if ok_goc else "Ngoài dải dốc tiêu chuẩn"
    })
    # 5. Chieu day ban theo nhip tinh toan L0: L0/30 .. L0/25 (>= 100mm cho kieu Ban)
    if tt.get("kieu", "Bản") == "Bản":
        ok_day = day >= 100.0 and ty_le_day <= 32.0
        items.append({
            "ten": "Bề dày bản (L₀ / h_b)", "gia_tri": "%.0f mm (L₀/%.1f)" % (day, ty_le_day),
            "chuan": "h_b ≥ 100 mm, L₀/25÷30", "dat": ok_day,
            "ghi_chu": "Đạt" if ok_day else ("Bản mỏng, gợi ý ≥ %d mm" % goi_y_day_ban(L0))
        })
    # 6. Lop BT bao ve & buoc thep TCVN 5574:2018
    ok_abv = abv >= max(15.0, d1)
    items.append({
        "ten": "Lớp bảo vệ (a_bv)", "gia_tri": "%.0f mm" % abv,
        "chuan": "≥ max(15, Ø) mm", "dat": ok_abv,
        "ghi_chu": "Đạt" if ok_abv else "Phải ≥ 15 mm và ≥ Ø thép"
    })
    ok_a = (a1 <= 200.0) and (a3 <= 250.0)
    items.append({
        "ten": "Khoảng cách thép (a₁ / a₄)", "gia_tri": "a%d / a%d" % (round(a1), round(a3)),
        "chuan": "a₁ ≤ 200, a₄ ≤ 250 mm", "dat": ok_a,
        "ghi_chu": "Đạt" if ok_a else "Bước thép thưa hơn quy định bản sàn/thang"
    })
    return {
        "ok": all(x["dat"] for x in items),
        "h": h, "b": b, "cong_thuc": cong_thuc, "goc": goc,
        "L0": L0, "ty_le_day": ty_le_day,
        "goi": goi, "items": items,
    }


def _tim_goi_ve(r, dams):
    """Xac dinh vi tri goi dam dau ve (s <= 300 hoac trong chieu nghi dau) va goi dam cuoi ve
    (s >= L - 300 hoac trong chieu nghi cuoi).
    Phan biet:
    - Dam ngay nach chan ve (s quanh 0): 'chan_nach'
    - Dam o bien chieu nghi dau (s < -300): 'chan_bien'
    - Dam ngay nach dinh ve (s quanh L): 'dau_nach'
    - Dam o bien chieu nghi cuoi (s > L + 300): 'dau_bien'
    """
    L, Lb, Lt = r["dai"], r["cn_dau"], r["cn_cuoi"]
    dam_dau, dam_cuoi = None, None
    for d in dams:
        if not dam_hien_o_ve(r, d):
            continue
        s = dam_trong_ve(r, d)[0]
        if s < 300.0:
            if dam_dau is None or s > dam_dau[0]:
                dam_dau = (s, d)
        elif s > L - 300.0:
            if dam_cuoi is None or s < dam_cuoi[0]:
                dam_cuoi = (s, d)
    s_dau = dam_dau[0] if dam_dau else -Lb
    s_cuoi = dam_cuoi[0] if dam_cuoi else (L + Lt)
    co_dam_nach_dau = bool(dam_dau and dam_dau[0] >= -dam_dau[1]["b"] * 0.8)
    co_dam_nach_cuoi = bool(dam_cuoi and dam_cuoi[0] <= L + dam_cuoi[1]["b"] * 0.8)
    return {
        "dam_dau": dam_dau[1] if dam_dau else None,
        "s_dam_dau": dam_dau[0] if dam_dau else None,
        "dam_cuoi": dam_cuoi[1] if dam_cuoi else None,
        "s_dam_cuoi": dam_cuoi[0] if dam_cuoi else None,
        "s_dau": s_dau,
        "s_cuoi": s_cuoi,
        "co_dam_nach_dau": co_dam_nach_dau,
        "co_dam_nach_cuoi": co_dam_nach_cuoi,
    }


def tinh_thep_mc(thang, r, dams):
    """Tinh toan hinh hoc cot thep tren mat cat doc 1 ve theo TCVN 5574:2018:
    - Tach/bat cheo cot thep tai goc lom (nut gay khuc s=0 va s=L) de khong giat vo lop BT bao ve.
    - Neo du chieu dai neo chiu keo (mac dinh 35d) qua vung nen / vao dam goi.
    - Ho tro truong hop dam o bien chieu nghi (thep chay suot ban chieu nghi) va dam ngay nach.
    """
    tt = thang["tt"]
    abv = float(tt.get("abv", 20.0))
    cat = max(0.15, min(float(tt.get("cat_thep_l", 0.25)), 0.45))
    d1 = float(tt.get("d_chu", 12.0))
    d2 = float(tt.get("d_mu", 10.0))
    d3 = float(tt.get("d_pb", 8.0))
    a1 = float(tt.get("a_chu", 150.0))
    a2 = float(tt.get("a_mu", 150.0))
    a3 = float(tt.get("a_pb", 200.0))
    neo_keo, neo_nen, moc_d = neo_moc(tt)

    L, Lb, Lt = r["dai"], r["cn_dau"], r["cn_cuoi"]
    z0, z1 = r["z0"], r["z1"]
    rise = z1 - z0
    m = mc_hinh(r)
    dayv = m["dayv"]
    ca = L / math.hypot(L, rise) if (L > 0 and rise > 0) else 1.0
    kk = rise / L if L > 0 else 0.0
    av = abv / ca  # khoang cach theo phuong thang dung cho ban nghieng

    goi = _tim_goi_ve(r, dams)
    L0 = max(L, goi["s_cuoi"] - goi["s_dau"])
    c1 = min(0.45 * L, cat * L0)  # doan mu goi tinh theo nhip L0 nhung gioi han trong ve nghieng

    dll = float(r["day_cn_dau"])
    dlu = float(r["day_cn_cuoi"])
    zb0 = z0 - dayv + av          # day ban nghieng tai s=0
    zb1 = z1 - dayv + av          # day ban nghieng tai s=L
    zt0_sl = z0 - av              # mat tren ban nghieng tai s=0
    zt1_sl = z1 - av              # mat tren ban nghieng tai s=L
    zb_cn0 = z0 - dll + abv       # lop duoi chieu nghi dau
    zt_cn0 = z0 - abv             # lop tren chieu nghi dau
    zb_cn1 = z1 - dlu + abv       # lop duoi chieu nghi cuoi
    zt_cn1 = z1 - abv             # lop tren chieu nghi cuoi

    # Gioi han mep trai/phai cho phep thep vuon toi (den trong dam hoac mep chieu nghi)
    if goi["dam_dau"]:
        d_ = goi["dam_dau"]
        s_trai = max(-Lb - d_["b"] + abv, goi["s_dam_dau"] - d_["b"] / 2.0 + abv)
        hook_trai = min(moc_d * d1, max(d_["h"] - 2.0 * abv, 60.0))
    elif Lb >= 50.0:
        s_trai = -Lb + abv
        hook_trai = min(moc_d * d1, max(dll - 2.0 * abv, 40.0))
    else:
        s_trai = min(abv, L * 0.1)
        hook_trai = min(moc_d * d1, max(r["day"] - 2.0 * abv, 40.0))

    if goi["dam_cuoi"]:
        d_ = goi["dam_cuoi"]
        s_phai = min(L + Lt + d_["b"] - abv, goi["s_dam_cuoi"] + d_["b"] / 2.0 - abv)
        hook_phai = min(moc_d * d1, max(d_["h"] - 2.0 * abv, 60.0))
    elif Lt >= 50.0:
        s_phai = L + Lt - abv
        hook_phai = min(moc_d * d1, max(dlu - 2.0 * abv, 40.0))
    else:
        s_phai = max(L - abv, L * 0.9)
        hook_phai = min(moc_d * d1, max(r["day"] - 2.0 * abv, 40.0))

    # Giao diem cua duong thep duoi ban nghieng voi cao do lop tren chieu nghi tren (zt_cn1)
    # zb0 + kk * s = zt_cn1 => s_tren_cuoi
    lan1 = neo_keo * d1
    lan2 = neo_keo * d2
    tach = bool(tt.get("tach_goc_lom", True))
    suot = bool(tt.get("thep_cn_suot", True))

    bars = []  # [{"id", "nhom": "duoi"|"tren", "pts": [(s,z),...], "mota": ...}]
    dots = []  # [(s, z)] cho thep phan bo 4

    # ---- 1. THEP CHIU LUC LOP DUOI BAN NGHIENG (1)
    # Giao diem duong lop duoi ban nghieng voi lop duoi chieu nghi dau:
    s_giao_duoi0 = (zb_cn0 - zb0) / kk if kk > 1e-6 else 0.0
    s_giao_duoi0 = max(-Lb + abv, min(150.0, s_giao_duoi0))
    if Lb < 80.0 and not goi["co_dam_nach_dau"]:
        s1_start = s_trai
        zb_start = zb0 + kk * s1_start
        pts1 = [(s1_start, zb_start + hook_trai), (s1_start, zb_start)]
    elif goi["co_dam_nach_dau"] or (suot and Lb > 100.0):
        s1_start = s_trai
        s_giao_duoi0 = max(s1_start + 20.0, s_giao_duoi0)
        pts1 = [(s1_start, zb_cn0 + hook_trai), (s1_start, zb_cn0), (s_giao_duoi0, zb_cn0)]
    else:
        s1_start = max(s_trai, -lan1)
        pts1 = [(s1_start, zb0 + hook_trai), (s1_start, zb0), (0.0, zb0)]

    # Tai dinh ve (s = L) la GOC LOM MAT TREN:
    if Lt < 80.0 and not goi["co_dam_nach_cuoi"]:
        zb_end = zb0 + kk * s_phai
        pts1 += [(s_phai, zb_end), (s_phai, min(z1 - abv, zb_end + hook_phai))]
        mota_1_cuoi = "uốn móc tại đầu vế"
    elif tach and not goi["co_dam_nach_cuoi"]:
        # CHUAN TCVN: Thep 1 lop duoi ban nghieng KHONG be xuong ma keo thang len cat vao mat tren
        # chieu nghi tren, neo du lan1 (35d) hoac keo suot ra goi bien neu chieu nghi ngan!
        s_den_tren = (zt_cn1 - zb0) / kk if kk > 1e-6 else L
        s_den_tren = min(L + Lt - abv, max(L, s_den_tren))
        s1_end = min(s_phai, s_den_tren + lan1)
        if suot and s_phai - s1_end < 250.0:
            s1_end = s_phai
        pts1 += [(s_den_tren, zt_cn1), (s1_end, zt_cn1), (s1_end, zt_cn1 - hook_phai)]
        mota_1_cuoi = "kéo thẳng qua góc lõm lên lớp trên chiếu nghỉ neo %dd" % round(neo_keo)
    else:
        # Co dam ngay nach dinh ve (s ≈ L) -> neo vao dam dinh & moc len/xuong
        s1_end = min(s_phai, L + lan1)
        s_giao_duoi1 = (zb_cn1 - zb0) / kk if kk > 1e-6 else L
        pts1 += [(min(s1_end, max(L, s_giao_duoi1)), zb_cn1), (s1_end, zb_cn1), (s1_end, zb_cn1 + hook_phai)]
        mota_1_cuoi = "neo vào dầm đỉnh %dd" % round(neo_keo)

    bars.append({"id": "1", "nhom": "duoi", "pts": pts1,
                 "mota": "1  Thép chịu lực lớp dưới Ø%g a%g (%s)" % (d1, a1, mota_1_cuoi)})

    # ---- 2 & 3. THEP LOP TREN / MU GOI & CHI TIET BAT CHEO GOC LOM
    hook_mu = min(moc_d * d2, max(r["day"] - 2.0 * abv, 40.0))
    if tt.get("thep_tren", True):
        # 2: Goi duoi (tai s = 0) - GOC LOM MAT TREN
        zc_2 = z0 + kk * c1 - av
        if Lb < 80.0 and not goi["dam_dau"]:
            if c1 > s_trai + 40.0:
                zt_st = zt0_sl + kk * s_trai
                pts2 = [
                    (s_trai, max(zb0 + kk * s_trai, zt_st - hook_mu)),
                    (s_trai, zt_st),
                    (c1, zc_2),
                    (c1, max(zb0 + kk * c1, zc_2 - hook_mu)),
                ]
            else:
                pts2 = []
        elif tach and not goi["co_dam_nach_dau"] and Lb >= 220.0 and kk > 1e-6:
            # Tach goc lom o chan ve (s = 0): thanh 2 tu lop tren ban nghieng chay thang qua goc lom
            # xuong neo vao lop duoi chieu nghi duoi (khong be gap tai zt_cn0 gay bat lop BT bao ve)
            s_2_bot = (zb_cn0 - zt0_sl) / kk
            s_2_bot = min(-20.0, max(s_trai, s_2_bot))
            s_2_end = max(s_trai, s_2_bot - lan2)
            pts2 = [
                (s_2_end, min(z0 - abv, zb_cn0 + hook_trai)),
                (s_2_end, zb_cn0),
                (s_2_bot, zb_cn0),
                (c1, zc_2),
                (c1, max(zb0 + kk * c1, zc_2 - hook_mu)),
            ]
            # Thanh 2a: thep lop tren chieu nghi duoi neo thang qua s=0 vao trong than ban nghieng
            s_2a_lim = min(L - abv, max(40.0, (dayv - av - abv) / kk))
            s_2a_end = min(s_2a_lim, max(40.0, lan2 * 0.8))
            pts2a = [
                (s_trai, zt_cn0 - hook_trai),
                (s_trai, zt_cn0),
                (s_2a_end, zt_cn0),
            ]
            bars.append({"id": "2a", "nhom": "tren", "pts": pts2a,
                         "mota": "2a Thép lớp trên chiếu nghỉ dưới Ø%g a%g (tách góc lõm neo %dd)" % (d2, a2, round(neo_keo))})
        else:
            pts2 = [
                (s_trai, zt_cn0 - hook_trai),
                (s_trai, zt_cn0),
                (0.0, zt0_sl),
                (c1, zc_2),
                (c1, max(zb0 + kk * c1, zc_2 - hook_mu)),
            ]
        if pts2:
            bars.append({"id": "2", "nhom": "tren", "pts": pts2,
                         "mota": "2  Thép mũ gối dưới Ø%g a%g (tách góc lõm, dài %.2f×L₀)" % (d2, a2, cat)})

        # 3: Goi tren (tai s = L) - GOC LOM MAT TREN
        zd_3 = z1 - kk * c1 - av
        if Lt < 80.0 and not goi["dam_cuoi"]:
            if L - c1 < s_phai - 40.0:
                zt_en = zt0_sl + kk * s_phai
                pts3 = [
                    (L - c1, max(zb0 + kk * (L - c1), zd_3 - hook_mu)),
                    (L - c1, zd_3),
                    (s_phai, zt_en),
                    (s_phai, max(zb0 + kk * s_phai, zt_en - hook_mu)),
                ]
            else:
                pts3 = []
        elif tach and not goi["co_dam_nach_cuoi"]:
            s_3_end = min(s_phai, L + lan2)
            z_3_end = min(zt_cn1, zt1_sl + kk * (s_3_end - L))
            pts3 = [
                (L - c1, max(zb0 + kk * (L - c1), zd_3 - hook_mu)),
                (L - c1, zd_3),
                (L, zt1_sl),
                (s_3_end, z_3_end),
            ]
            # Thanh 3a: neo tu mat tren chieu nghi tren cheo qua goc lom vao trong ban nghieng (KHONG loi ra ngoai!)
            if Lt >= 250.0:
                s_3a_start = max(abv, L - min(lan2 * 0.8, max(m["g"], 0.4 * L)))
                z_3a_start = min(zt0_sl + kk * s_3a_start - 4.0, zb0 + kk * s_3a_start + 6.0)
                pts3a = [
                    (s_3a_start, z_3a_start),
                    (L, zt_cn1),
                    (s_phai, zt_cn1),
                    (s_phai, zt_cn1 - hook_phai),
                ]
                bars.append({"id": "3a", "nhom": "tren", "pts": pts3a,
                             "mota": "3a Thép lớp trên chiếu nghỉ Ø%g a%g (tách góc lõm neo %dd)" % (d2, a2, round(neo_keo))})
        else:
            pts3 = [
                (L - c1, max(zb0 + kk * (L - c1), zd_3 - hook_mu)),
                (L - c1, zd_3),
                (L, zt1_sl),
                (s_phai, zt_cn1),
                (s_phai, zt_cn1 - hook_phai),
            ]
        if pts3:
            bars.append({"id": "3", "nhom": "tren", "pts": pts3,
                         "mota": "3  Thép mũ gối trên Ø%g a%g (tách góc lõm, dài %.2f×L₀)" % (d2, a2, cat)})

        # Neu khong co dam nach dinh va co chieu nghi dai -> bo sung thep lop duoi chieu nghi tren (thanh 5)
        if not goi["co_dam_nach_cuoi"] and Lt >= 250.0 and suot:
            s5_lim = (dlu - abv - av) / kk if kk > 1e-6 else lan1 * 0.5
            s5_start = max(abv, L - min(lan1 * 0.5, 220.0, max(0.0, s5_lim)))
            pts5 = [
                (s5_start, zb_cn1),
                (s_phai, zb_cn1),
                (s_phai, zb_cn1 + hook_phai),
            ]
            bars.append({"id": "5", "nhom": "duoi", "pts": pts5,
                         "mota": "5  Thép lớp dưới chiếu nghỉ Ø%g a%g (neo qua nách vào dầm biên)" % (d1, a1)})

    # ---- 4. THEP PHAN BO (4) - nam ben trong thep chiu luc (tren lop duoi, duoi lop tren)
    if tt.get("thep_pb", True):
        off1 = (d1 / 2.0 + d3 / 2.0) / ca
        off1_ngang = d1 / 2.0 + d3 / 2.0
        off2 = (d2 / 2.0 + d3 / 2.0) / ca
        off2_ngang = d2 / 2.0 + d3 / 2.0
        step_sl = max(a3 * ca, 25.0)
        step_ng = max(a3, 25.0)

        # Tren thanh 1 (ban nghieng)
        n_sl = int(L / step_sl)
        for i in range(n_sl + 1):
            s_ = min(L, i * step_sl)
            dots.append((s_, zb0 + kk * s_ + off1))

        # Tren chieu nghi dau (lop duoi)
        if Lb >= 150.0:
            s_ = -step_ng
            for _i in range(60):
                if s_ < s_trai + 20.0:
                    break
                dots.append((s_, zb_cn0 + off1_ngang))
                s_ -= step_ng

        # Tren doan neo mat tren chieu nghi cuoi cua thanh 1 (hoac thanh 5)
        if Lt >= 150.0:
            s_ = L + step_ng
            for _i in range(60):
                if s_ > s_phai - 20.0:
                    break
                if tach and not goi["co_dam_nach_cuoi"]:
                    dots.append((s_, zt_cn1 - off1_ngang))
                else:
                    dots.append((s_, zb_cn1 + off1_ngang))
                s_ += step_ng

        # Duoi thanh 2 & 3 (thep mu)
        if tt.get("thep_tren", True):
            for s0, s1 in ((0.0, c1), (L - c1, L)):
                n_m = int((s1 - s0) / step_sl)
                for i in range(n_m + 1):
                    s_ = min(s1, s0 + i * step_sl)
                    dots.append((s_, zt0_sl + kk * s_ - off2))
            if Lb >= 250.0 and not goi["co_dam_nach_dau"]:
                s_ = -step_ng
                for _i in range(60):
                    if s_ < s_trai + 20.0:
                        break
                    dots.append((s_, zt_cn0 - off2_ngang))
                    s_ -= step_ng

    return {
        "bars": bars,
        "dots": dots,
        "c1": c1,
        "L0": L0,
        "goi": goi,
        "ca": ca,
        "kk": kk,
        "zb0": zb0,
        "zt0_sl": zt0_sl,
        "d1": d1, "d2": d2, "d3": d3,
        "a1": a1, "a2": a2, "a3": a3,
        "neo_keo": neo_keo, "neo_nen": neo_nen, "moc_d": moc_d,
    }


# ---------------------------------------------------------------- hinh de ve preview
def mb_hinh(thang):
    runs = []
    for r in thang["runs"]:
        u = r["u"]
        v = _normal(u)
        p = r["p0"]
        h = r["rong"] / 2.0
        L = r["dai"]
        a = (p[0] - v[0] * h, p[1] - v[1] * h)
        b = (a[0] + u[0] * L, a[1] + u[1] * L)
        c = (b[0] + v[0] * 2 * h, b[1] + v[1] * 2 * h)
        d = (a[0] + v[0] * 2 * h, a[1] + v[1] * 2 * h)
        runs.append([a, b, c, d])
    return {"runs": runs, "landings": [ld["poly"] for ld in thang["landings"]]}


def mc_hinh(r):
    """Duong bao mat cat doc ve (s, z) chuan thuc te thi cong:
    day ban nghieng giao muot voi day chieu nghi (khong giat cap dung vo ly o s=0 / s=L).
    """
    n = max(1, int(r["so_bac"]))
    L = max(r["dai"], 1.0)
    g = L / n
    h = (r["z1"] - r["z0"]) / n
    z0, z1 = r["z0"], r["z1"]
    Lb, Lt = r["cn_dau"], r["cn_cuoi"]
    dll, dlu = r["day_cn_dau"], r["day_cn_cuoi"]
    dayv = r["day"] * math.hypot(g, h) / g
    kk = (z1 - z0) / L if L > 0 else 0.0

    pts = [(-Lb, z0)] if Lb >= 20.0 else []
    for i in range(n):
        pts.append((i * g, z0 + i * h))
        pts.append((i * g, z0 + (i + 1) * h))
    pts.append((L, z1))
    if Lt >= 20.0:
        pts.append((L + Lt, z1))
        pts.append((L + Lt, z1 - dlu))
        if kk > 1e-6:
            s_bot1 = max(L * 0.5, min(L + Lt, L + (dayv - dlu) / kk))
        else:
            s_bot1 = L
        if abs(s_bot1 - L) > 1.0 and s_bot1 <= L + Lt:
            pts.append((s_bot1, z1 - dlu))
        else:
            pts.append((L, z1 - dlu))
            pts.append((L, z1 - dayv))
    else:
        pts.append((L, z1 - dayv))

    if Lb >= 20.0:
        if kk > 1e-6:
            s_bot0 = max(-Lb, min(L * 0.5, (dayv - dll) / kk))
        else:
            s_bot0 = 0.0
        if abs(s_bot0) > 1.0 and s_bot0 >= -Lb:
            pts.append((s_bot0, z0 - dll))
        else:
            pts.append((0.0, z0 - dayv))
            pts.append((0.0, z0 - dll))
        pts.append((-Lb, z0 - dll))
    else:
        pts.append((0.0, z0 - dayv))

    # Duong bao ban thang thuan tuy (khong co rang bac) de ve che do "bac dac trung"
    slab_pts = [(-Lb, z0)] if Lb >= 20.0 else []
    slab_pts.extend([(0.0, z0), (L, z1)])
    if Lt >= 20.0:
        slab_pts.append((L + Lt, z1))
        slab_pts.append((L + Lt, z1 - dlu))
        s_b1 = max(L * 0.5, min(L + Lt, L + (dayv - dlu) / kk)) if kk > 1e-6 else L
        if abs(s_b1 - L) > 1.0 and s_b1 <= L + Lt:
            slab_pts.append((s_b1, z1 - dlu))
        else:
            slab_pts.extend([(L, z1 - dlu), (L, z1 - dayv)])
    else:
        slab_pts.append((L, z1 - dayv))
    if Lb >= 20.0:
        s_b0 = max(-Lb, min(L * 0.5, (dayv - dll) / kk)) if kk > 1e-6 else 0.0
        if abs(s_b0) > 1.0 and s_b0 >= -Lb:
            slab_pts.append((s_b0, z0 - dll))
        else:
            slab_pts.extend([(0.0, z0 - dayv), (0.0, z0 - dll)])
        slab_pts.append((-Lb, z0 - dll))
    else:
        slab_pts.append((0.0, z0 - dayv))

    return {"outline": pts, "slab_outline": slab_pts, "g": g, "h": h, "dayv": dayv}

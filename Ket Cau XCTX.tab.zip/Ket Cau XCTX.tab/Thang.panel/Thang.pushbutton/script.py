# !python3
# -*- coding: utf-8 -*-
__title__ = "Vẽ cầu thang"
__doc__ = "Pick thang (Stairs / Generic Model) hoặc nhập tay -> nhận dạng vế, chiều nghỉ -> chỉnh thông số."

import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import clr
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import MessageBox
from pyrevit import revit
# pyRevit CPython co the giu module cu trong bo nho -> xoa de luon nap ban moi tren dia
for _n in ("thang_model", "thang_revit", "thang_form"):
    sys.modules.pop(_n, None)
import thang_model as M
import thang_revit as R
import thang_form as F
print("Đang dùng: " + R.__file__)


def _ds(x):
    """Dam bao la danh sach (ban cu cua thang_revit tra ve 1 doi tuong)."""
    if x is None:
        return []
    try:
        return list(x)
    except Exception:
        return [x]

doc = revit.doc
uidoc = revit.uidoc


class forms(object):
    """pyrevit.forms.alert khong chay duoc trong CPython -> dung MessageBox cua Windows."""
    @staticmethod
    def alert(msg, title=""):
        MessageBox.Show(str(msg), str(title))


def _bao_cao(tieu_de, lines, moi):
    """Hop bao cao nhan dang (da copy vao clipboard) de doi chieu / gui di khi nhan sai."""
    L = [tieu_de] + [str(x) for x in lines]
    L.append("KẾT QUẢ: %d vế, %d chiếu nghỉ, loại=%s" % (len(moi["runs"]), len(moi["landings"]), moi["loai"]))
    for i, r in enumerate(moi["runs"], 1):
        L.append("  vế %d: p0=(%d,%d) u=(%.2f,%.2f) rộng %d dài %d z %d->%d bậc %d dày %d cn_đầu %d cn_cuối %d" % (
            i, r["p0"][0], r["p0"][1], r["u"][0], r["u"][1], r["rong"], r["dai"], r["z0"], r["z1"],
            r["so_bac"], r["day"], r["cn_dau"], r["cn_cuoi"]))
    txt = "\n".join(L)
    try:
        from System.Windows.Forms import Clipboard
        Clipboard.SetText(txt)
    except Exception:
        pass
    MessageBox.Show(txt + "\n\n(Đã copy vào clipboard - dán cho Claude bằng Ctrl+V)", "Báo cáo nhận dạng thang")


def _giu_thong_so(moi, cu):
    """Pick lai thi giu thong so form (ten, abv, ty le...) cua lan truoc."""
    ten = moi["tt"]["ten"]
    tu_revit = moi.get("ten_tu_revit")
    moi["tt"] = cu["tt"]
    if tu_revit:
        moi["tt"]["ten"] = ten
    elif cu["tt"].get("ten"):
        moi["tt"]["ten"] = cu["tt"]["ten"]
    else:
        moi["tt"]["ten"] = ten
    return moi


def main():
    thang = M.tao_tay("2 vế")
    while True:
        act, extra, thang = F.hien_form(thang)
        if act == "close":
            break
        try:
            if act == "tay":
                moi = M.tao_tay(extra if extra in M.LOAI else "1 vế")
                thang = _giu_thong_so(moi, thang)
            elif act == "dam":
                ds, lines = R.quet_dam(doc, thang)
                for line in lines:
                    print(line)
                if ds is None:
                    forms.alert(lines[0], title="Quét dầm")
                else:
                    thang["dam"] = ds
                    forms.alert("\n".join(lines), title="Quét dầm")
                continue
            elif act == "stairs":
                els = _ds(R.pick_stairs(uidoc))
                if not els:
                    continue
                print("=== ĐÃ PICK %d ĐỐI TƯỢNG ===" % len(els))
                for e in els:
                    print("  " + R.mo_ta(e))
                sts = R.chi_stairs(els)
                inplaces = R.chi_inplace_stairs(els)
                if sts:
                    dl = R.chan_doan_stairs(doc, sts)
                    for line in dl:
                        print(line)
                    moi = R.doc_stairs(doc, sts)
                    _bao_cao("NGUỒN: Stairs (%d đối tượng pick)" % len(els), [R.mo_ta(e) for e in els] + dl, moi)
                elif inplaces:
                    dl = R.chan_doan_generic(inplaces)
                    for line in dl:
                        print(line)
                    del M.LOG[:]
                    moi = R.doc_generic(doc, inplaces)
                    _bao_cao("NGUỒN: Stairs In-Place (%d đối tượng pick)" % len(inplaces),
                             dl + list(M.LOG) + list(moi["ghi_chu"]), moi)
                else:
                    forms.alert("Các đối tượng bạn pick KHÔNG phải Stairs.\n"
                                "Xem cửa sổ output để biết đó là loại gì.\n"
                                "Nếu là bản thang vẽ bằng Generic Model, dùng nút 'Chọn Generic Model'.",
                                title="Vẽ cầu thang")
                    continue
                print("Kết quả: %d vế, %d chiếu nghỉ" % (len(moi["runs"]), len(moi["landings"])))
                if not moi["runs"]:
                    forms.alert("Không đọc được vế nào từ đối tượng thang này.", title="Vẽ cầu thang")
                    continue
                thang = _giu_thong_so(moi, thang)
            elif act == "generic":
                els = _ds(R.pick_generic(uidoc))
                if not els:
                    continue
                print("=== ĐÃ PICK %d ĐỐI TƯỢNG ===" % len(els))
                dl = R.chan_doan_generic(els)
                for line in dl:
                    print(line)
                del M.LOG[:]
                moi = R.doc_generic(doc, els)
                _bao_cao("NGUỒN: Generic (%d đối tượng pick)" % len(els), dl + list(M.LOG) + list(moi["ghi_chu"]), moi)
                print("Kết quả: %d vế, %d chiếu nghỉ" % (len(moi["runs"]), len(moi["landings"])))
                for n in moi["ghi_chu"]:
                    print("  - " + n)
                if not moi["runs"]:
                    forms.alert("Không nhận ra bản thang nghiêng trong đối tượng đã chọn.\n"
                                "Xem cửa sổ output để biết tool thấy gì, hoặc dùng Nhập tay.",
                                title="Vẽ cầu thang")
                    continue
                thang = _giu_thong_so(moi, thang)
        except Exception:
            err = traceback.format_exc()
            print(err)
            forms.alert("Có lỗi khi đọc thang. Chi tiết xem trong cửa sổ output của pyRevit.",
                        title="Vẽ cầu thang")


main()
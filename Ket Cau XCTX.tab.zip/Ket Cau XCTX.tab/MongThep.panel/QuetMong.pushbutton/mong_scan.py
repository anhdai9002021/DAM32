# -*- coding: utf-8 -*-
"""Quet mong tu Revit theo Level (CPython 3 / pyRevit 7 / Revit 2025). Don vi dau ra: mm."""
import math
import re
import unicodedata
import clr

clr.AddReference("RevitAPI")
from Autodesk.Revit.DB import (FilteredElementCollector, BuiltInCategory, BuiltInParameter,
                               Options, ViewDetailLevel, Level, StorageType, XYZ)

import mong_geom as G
import mong_model as M

FT = 304.8                 # feet -> mm
COL_Z_TOL = 1000.0         # cot duoc tinh la "tren mong" neu chan cot nam trong [day mong, dinh mong + 1000]
PILE_Z_TOL = 300.0         # dau coc nam trong [day dai - 300, dinh dai]
BBOX_PAD = 60.0            # mm, loc nhanh theo hop bao truoc khi lay hinh hoc
LOT_MAX = 150.0            # mm, khoi be tong mong (trong family) day <= nay, nam duoi khoi khac va to hon -> coi la BT lot, bo qua


# ------------------------------------------------------------------ tien ich
def _tname(o):
    try:
        return o.GetType().Name
    except Exception:
        return ""


def _eid(x):
    try:
        return int(x.Value)
    except Exception:
        return int(x.IntegerValue)


def _pstr(el, bip):
    try:
        p = el.get_Parameter(bip)
        if p is not None and p.HasValue:
            return p.AsString() or ""
    except Exception:
        pass
    return ""


def _mark(el):
    return _pstr(el, BuiltInParameter.ALL_MODEL_MARK)


def _fam_type(el, doc=None):
    fam, typ = "", ""
    try:
        sym = el.Symbol
        try:
            fam = sym.FamilyName
        except Exception:
            fam = sym.Family.Name
        try:
            typ = sym.Name
        except Exception:
            typ = _pstr(sym, BuiltInParameter.SYMBOL_NAME_PARAM)
    except Exception:
        pass
    if not fam and doc is not None:          # Foundation Slab (Floor): lay theo ElementType
        try:
            t = doc.GetElement(el.GetTypeId())
            typ = t.Name
            try:
                fam = t.FamilyName
            except Exception:
                fam = ""
        except Exception:
            pass
        fam = fam or u"Foundation Slab"
    return fam or "", typ or ""


def _is_slab(el):
    return _tname(el) in ("Floor",)


def _level_id(el):
    try:
        lid = el.LevelId
        if lid is not None and _eid(lid) > 0:
            return _eid(lid)
    except Exception:
        pass
    for bip in (BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM,
                BuiltInParameter.FAMILY_LEVEL_PARAM,
                BuiltInParameter.SCHEDULE_LEVEL_PARAM):
        try:
            p = el.get_Parameter(bip)
            if p is not None and p.HasValue:
                v = _eid(p.AsElementId())
                if v > 0:
                    return v
        except Exception:
            continue
    return -1


class Ctx(object):
    def __init__(self, doc, shared, zoff_mm):
        self.doc = doc
        self.tf = None
        if shared:
            try:
                self.tf = doc.ActiveProjectLocation.GetTotalTransform()
            except Exception:
                self.tf = None
        self.zoff = zoff_mm

    def xy(self, p):
        if self.tf is not None:
            p = self.tf.OfPoint(p)
        return (p.X * FT, p.Y * FT)

    def z(self, z_ft):
        return z_ft * FT - self.zoff

    def raw_pt(self, x_mm, y_mm, z_ft):
        """Diem (mm, he da dung cho dau ra) -> toa do Revit (feet) de dung voi hinh hoc goc."""
        p = XYZ(x_mm / FT, y_mm / FT, z_ft)
        if self.tf is not None:
            p = self.tf.Inverse.OfPoint(p)
        return p

    def raw_vec(self, x, y):
        v = XYZ(x, y, 0.0)
        if self.tf is not None:
            v = self.tf.Inverse.OfVector(v)
        return v.Normalize()


# ------------------------------------------------------------------ Level
def get_levels(doc):
    out = []
    for lv in FilteredElementCollector(doc).OfClass(Level):
        out.append(lv)
    out.sort(key=lambda l: l.Elevation)
    return out


def level_label(lv):
    return u"%s   (%.0f mm)" % (lv.Name, lv.ProjectElevation * FT)


# ------------------------------------------------------------------ hinh hoc Revit
def _opts():
    o = Options()
    o.DetailLevel = ViewDetailLevel.Fine
    o.ComputeReferences = False
    o.IncludeNonVisibleObjects = False
    return o


def _walk(ge, out):
    for obj in ge:
        n = _tname(obj)
        if n == "Solid":
            try:
                if obj.Volume > 1e-9 and obj.Faces.Size > 0:
                    out.append(obj)
            except Exception:
                pass
        elif n == "GeometryInstance":
            try:
                _walk(obj.GetInstanceGeometry(), out)
            except Exception:
                pass


def _solids(el):
    out = []
    try:
        ge = el.get_Geometry(_opts())
        if ge is not None:
            _walk(ge, out)
    except Exception:
        pass
    return out


def _loop_points(loop, ctx):
    pts = []
    for c in loop:
        if _tname(c) == "Line":
            pts.append(ctx.xy(c.GetEndPoint(0)))
        else:
            t = list(c.Tessellate())
            for p in t[:-1]:
                pts.append(ctx.xy(p))
    return pts


def _bottom_polygon(solids, ctx):
    """Bien dang = vong ngoai cua mat phang day thap nhat (phap tuyen huong xuong)."""
    faces = []
    for s in solids:
        try:
            for f in s.Faces:
                if _tname(f) == "PlanarFace" and f.FaceNormal.Z < -0.999:
                    faces.append((f.Origin.Z, f))
        except Exception:
            continue
    if not faces:
        return None
    zmin = min(z for z, _ in faces)
    low = [f for z, f in faces if abs(z - zmin) < 1e-3]
    low.sort(key=lambda f: -f.Area)
    face = low[0]
    best = None
    for loop in face.GetEdgesAsCurveLoops():
        pts = G.clean_polygon(_loop_points(loop, ctx))
        if len(pts) >= 3:
            a = G.area(pts)
            if best is None or a > best[0]:
                best = (a, pts)
    return best[1] if best else None


def _zrange(el, ctx):
    bb = el.get_BoundingBox(None)
    if bb is None:
        return None
    return (ctx.z(bb.Min.Z), ctx.z(bb.Max.Z))


def _bbox_poly(el, ctx):
    bb = el.get_BoundingBox(None)
    if bb is None:
        return None
    a = ctx.xy(bb.Min)
    b = ctx.xy(bb.Max)
    x0, x1 = min(a[0], b[0]), max(a[0], b[0])
    y0, y1 = min(a[1], b[1]), max(a[1], b[1])
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


def _location_xy(el, ctx):
    try:
        loc = el.Location
        if _tname(loc) == "LocationPoint":
            return ctx.xy(loc.Point)
    except Exception:
        pass
    return None


def _shape(el, ctx):
    """Tra ve dict(poly, zmin, zmax, note) hoac None."""
    z = _zrange(el, ctx)
    if z is None:
        return None
    note = ""
    poly = _bottom_polygon(_solids(el), ctx)
    if poly is None:
        poly = _bbox_poly(el, ctx)
        note = "bbox"
    if poly is None or len(poly) < 3:
        return None
    return {"poly": poly, "zmin": z[0], "zmax": z[1], "note": note}


# ------------------------------------------------------------------ hinh dang that cua mong don / dai
def _solid_z(solid, ctx):
    zs = []
    try:
        for e in solid.Edges:
            try:
                for q in e.AsCurve().Tessellate():
                    zs.append(ctx.z(q.Z))
            except Exception:
                continue
    except Exception:
        pass
    return (min(zs), max(zs)) if zs else None


def _face_poly(face, ctx):
    best = None
    for loop in face.GetEdgesAsCurveLoops():
        pts = G.clean_polygon(_loop_points(loop, ctx))
        if len(pts) >= 3:
            a = G.area(pts)
            if best is None or a > best[0]:
                best = (a, pts)
    return best[1] if best else None


def _flat_poly(solid, ctx, down=True):
    """Da giac mat phang nam ngang thap nhat (down) hoac cao nhat (not down) cua mot khoi."""
    faces = []
    try:
        for f in solid.Faces:
            if _tname(f) != "PlanarFace":
                continue
            nz = f.FaceNormal.Z
            if (down and nz < -0.999) or ((not down) and nz > 0.999):
                faces.append((f.Origin.Z, f))
    except Exception:
        return None
    if not faces:
        return None
    z = min(q[0] for q in faces) if down else max(q[0] for q in faces)
    sel = [f for zz, f in faces if abs(zz - z) < 1e-3]
    sel.sort(key=lambda f: -f.Area)
    return _face_poly(sel[0], ctx)


def _drop_lot(solids, ctx):
    """Bo khoi BT lot nam trong family mong: khoi mong (<= LOT_MAX), ngay duoi mot khoi cao hon va chua tron chan khoi do."""
    if len(solids) < 2:
        return solids
    info = [(s, _solid_z(s, ctx), _flat_poly(s, ctx, True)) for s in solids]
    keep = []
    for i, (s, zr, bp) in enumerate(info):
        lot = False
        if zr is not None and bp is not None and (zr[1] - zr[0]) <= LOT_MAX:
            for j, (t, zt, bt) in enumerate(info):
                if j == i or zt is None or bt is None:
                    continue
                if (abs(zt[0] - zr[1]) <= 3.0 and (zt[1] - zt[0]) > (zr[1] - zr[0]) + 1.0
                        and G.area(bp) >= G.area(bt) - 1.0 and G.point_in_poly(G.centroid(bt), bp, 1.0)):
                    lot = True
                    break
        if not lot:
            keep.append(s)
    return keep or solids


def _shape_foot(el, ctx):
    """Hinh dang mong don / dai: bo BT lot trong family, Z theo khoi that, ghi lai cac bac / mat vat o mat bang."""
    z = _zrange(el, ctx)
    if z is None:
        return None
    allsol = _solids(el)
    solids = _drop_lot(allsol, ctx) if allsol else []
    note = ""
    zmin, zmax = z
    if solids:
        zr = [q for q in (_solid_z(x, ctx) for x in solids) if q]
        if zr:
            zmin = min(q[0] for q in zr)
            zmax = max(q[1] for q in zr)
    poly = _bottom_polygon(solids, ctx) if solids else None
    if poly is None:
        poly = _bbox_poly(el, ctx)
        note = "bbox"
    if poly is None or len(poly) < 3:
        return None
    bac = []
    base_a = G.area(poly)
    base_c = G.centroid(poly)
    for sd in solids:
        tp = _flat_poly(sd, ctx, False)
        if tp is None or len(tp) < 3:
            continue
        c = G.centroid(tp)
        if abs(G.area(tp) - base_a) <= 0.01 * base_a and math.hypot(c[0] - base_c[0], c[1] - base_c[1]) <= 3.0:
            continue
        if any(abs(G.area(tp) - G.area(q)) <= 0.01 * base_a and abs(G.centroid(q)[0] - c[0]) <= 3.0
               and abs(G.centroid(q)[1] - c[1]) <= 3.0 for _, q in bac):
            continue
        zt = _solid_z(sd, ctx)
        bac.append((((zt[1] if zt else zmax) - zmin), tp))
    return {"poly": poly, "zmin": zmin, "zmax": zmax, "note": note, "solids": solids, "bac": bac,
            "lot": len(allsol) - len(solids)}


def _slice_faces(solids, m, d):
    """Cat tung khoi bang mot tam mong vuong goc huong d tai diem m (toa do Revit, feet). Tra ve list PlanarFace (mat cat lon nhat moi khoi)."""
    from Autodesk.Revit.DB import (CurveLoop, Line, GeometryCreationUtilities, BooleanOperationsUtils,
                                   BooleanOperationsType)
    from System.Collections.Generic import List
    up = XYZ.BasisZ
    side = d.CrossProduct(up)
    if side.GetLength() < 1e-6:
        return []
    side = side.Normalize()
    W = 100.0
    corners = []
    for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        corners.append(XYZ(m.X + side.X * W * sx + up.X * W * sz, m.Y + side.Y * W * sx + up.Y * W * sz,
                           m.Z + side.Z * W * sx + up.Z * W * sz))
    loop = CurveLoop()
    for i in range(4):
        loop.Append(Line.CreateBound(corners[i], corners[(i + 1) % 4]))
    loops = List[CurveLoop]()
    loops.Add(loop)
    box = GeometryCreationUtilities.CreateExtrusionGeometry(loops, d, 0.02)
    out = []
    for sol in solids:
        try:
            r = BooleanOperationsUtils.ExecuteBooleanOperation(sol, box, BooleanOperationsType.Intersect)
            best = None
            for f in r.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                n = f.FaceNormal
                if abs(n.X * d.X + n.Y * d.Y + n.Z * d.Z) < 0.999:
                    continue
                if best is None or f.Area > best.Area:
                    best = f
            if best is not None:
                out.append(best)
        except Exception:
            continue
    return out


def _prof_str(polys):
    if not polys:
        return ""
    if len(polys) == 1 and _is_rect_prof(polys[0]):
        return ""
    return "|".join(M.poly_to_str(p) for p in polys)


def _foot_profiles(el, sh, ctx, ang, cx, cy):
    """Mat cat THUC qua tim mong theo he truc (u theo goc `ang`, v vuong goc), z tu day mong.
    Tra ve (A-A: cat vuong goc u, ngang = v ; B-B: cat vuong goc v, ngang = u). Chuoi rong = khoi lang tru don gian (hinh chu nhat)."""
    solids = sh["solids"]
    if not solids:
        return "", ""
    zmin = sh["zmin"]
    c, sn = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    infos = []
    for sd in solids:
        bp = _flat_poly(sd, ctx, True)
        tp = _flat_poly(sd, ctx, False)
        zr = _solid_z(sd, ctx)
        if bp is None or zr is None:
            infos = None
            break
        prism = (tp is not None and abs(G.area(tp) - G.area(bp)) <= 0.01 * G.area(bp)
                 and math.hypot(G.centroid(tp)[0] - G.centroid(bp)[0], G.centroid(tp)[1] - G.centroid(bp)[1]) <= 3.0)
        infos.append((bp, zr, prism))
    if infos and all(i[2] for i in infos):
        if len(infos) == 1:
            return "", ""                                  # mong lang tru don: mat bang + H la du
        pa, pb = [], []
        for bp, zr, _ in infos:                            # cac bac lang tru: cat bang tinh toan thuan tuy
            loc = [((x - cx) * c + (y - cy) * sn, -(x - cx) * sn + (y - cy) * c) for x, y in bp]
            z0, z1 = zr[0] - zmin, zr[1] - zmin
            for a, b in G.clip_intervals(loc, "v", 0.0):
                pa.append([(a, z0), (b, z0), (b, z1), (a, z1)])
            for a, b in G.clip_intervals(loc, "u", 0.0):
                pb.append([(a, z0), (b, z0), (b, z1), (a, z1)])
        return _prof_str(pa), _prof_str(pb)
    # co khoi vat / xien: cat that bang phep giao
    bb = el.get_BoundingBox(None)
    zf = (bb.Min.Z + bb.Max.Z) / 2.0
    m = ctx.raw_pt(cx, cy, zf)
    outs = []
    for d, hax in ((ctx.raw_vec(c, sn), "v"), (ctx.raw_vec(-sn, c), "u")):
        polys = []
        for f in _slice_faces(solids, m, d):
            best = None
            for loop in f.GetEdgesAsCurveLoops():
                pts = []
                for q in _loop_pts3(loop):
                    x, y = ctx.xy(q)
                    dx, dy = x - cx, y - cy
                    u = dx * c + dy * sn
                    v = -dx * sn + dy * c
                    pts.append(((v if hax == "v" else u), ctx.z(q.Z) - zmin))
                pts = G.clean_polygon(pts)
                if len(pts) >= 3:
                    a = G.area(pts)
                    if best is None or a > best[0]:
                        best = (a, pts)
            if best:
                polys.append(best[1])
        outs.append(_prof_str(polys))
    return outs[0], outs[1]


# ------------------------------------------------------------------ mat cat thuc cua dam / mong bang
def _loop_pts3(loop):
    pts = []
    for c in loop:
        if _tname(c) == "Line":
            pts.append(c.GetEndPoint(0))
        else:
            pts.extend(list(c.Tessellate())[:-1])
    return pts


def _is_rect_prof(poly):
    if len(poly) != 4:
        return False
    vs = sorted(set(round(p[0], 0) for p in poly))
    zs = sorted(set(round(p[1], 0) for p in poly))
    return len(vs) == 2 and len(zs) == 2


def _slice_face(solids, a, b, d):
    """Cat vat the bang mot tam mong vuong goc tim tai giua doan, tra ve mat cat (PlanarFace) lon nhat."""
    from Autodesk.Revit.DB import (CurveLoop, Line, GeometryCreationUtilities, BooleanOperationsUtils,
                                   BooleanOperationsType, XYZ)
    from System.Collections.Generic import List
    up = XYZ.BasisZ
    side = d.CrossProduct(up)
    if side.GetLength() < 1e-6:
        return None
    side = side.Normalize()
    mx, my, mz = (a.X + b.X) / 2.0, (a.Y + b.Y) / 2.0, (a.Z + b.Z) / 2.0
    W = 100.0
    corners = []
    for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        corners.append(XYZ(mx + side.X * W * sx + up.X * W * sz, my + side.Y * W * sx + up.Y * W * sz,
                           mz + side.Z * W * sx + up.Z * W * sz))
    loop = CurveLoop()
    for i in range(4):
        loop.Append(Line.CreateBound(corners[i], corners[(i + 1) % 4]))
    loops = List[CurveLoop]()
    loops.Add(loop)
    box = GeometryCreationUtilities.CreateExtrusionGeometry(loops, d, 0.02)
    best = None
    for sol in solids:
        try:
            r = BooleanOperationsUtils.ExecuteBooleanOperation(sol, box, BooleanOperationsType.Intersect)
            for f in r.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                n = f.FaceNormal
                if abs(n.X * d.X + n.Y * d.Y + n.Z * d.Z) < 0.999:
                    continue
                if best is None or f.Area > best.Area:
                    best = f
        except Exception:
            continue
    return best


def _profile(el, crv, p0, p1, zmin, ctx):
    """Mat cat ngang THUC cua dam / mong bang (chu T nguoc, bac thang, vat...) -> da giac (v, z) mm:
    v = lech khoi tim (+ ben trai), z = tu day. Tra ve None neu la hinh chu nhat (hoac khong doc duoc)."""
    try:
        if _tname(crv) != "Line":
            return None
        a, b = crv.GetEndPoint(0), crv.GetEndPoint(1)
        d = b.Subtract(a)
        if d.GetLength() < 1e-9:
            return None
        d = d.Normalize()
        L = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        if L < 1e-6:
            return None
        nx, ny = -(p1[1] - p0[1]) / L, (p1[0] - p0[0]) / L
        solids = _solids(el)
        face = None
        for sol in solids:                       # 1) mat dau day (vuong goc tim) cua vat the keo
            for f in sol.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                n = f.FaceNormal
                if abs(n.X * d.X + n.Y * d.Y + n.Z * d.Z) < 0.999:
                    continue
                if face is None or f.Area > face.Area:
                    face = f
        if face is None:                         # 2) dau dam bi cat vat -> cat bang mat phang giua doan
            try:
                face = _slice_face(solids, a, b, d)
            except Exception:
                face = None
        if face is None:
            return None
        best = None
        for loop in face.GetEdgesAsCurveLoops():
            pts = []
            for q in _loop_pts3(loop):
                x, y = ctx.xy(q)
                pts.append(((x - p0[0]) * nx + (y - p0[1]) * ny, ctx.z(q.Z) - zmin))
            pts = G.clean_polygon(pts)
            if len(pts) >= 3:
                ar = G.area(pts)
                if best is None or ar > best[0]:
                    best = (ar, pts)
        if best is None:
            return None
        return best[1], _is_rect_prof(best[1])
    except Exception:
        return None


# ------------------------------------------------------------------ family
def _cat_list():
    return [(BuiltInCategory.OST_GenericModel, u"Generic Models"),
            (BuiltInCategory.OST_StructuralFoundation, u"Structural Foundation"),
            (BuiltInCategory.OST_StructuralColumns, u"Structural Columns")]


def list_families(doc):
    """{ten family: [so luong, phan tu mau, ten category]} cua Generic Models / Structural Foundation / Structural Columns."""
    fams = {}
    for bic, lab in _cat_list():
        col = FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType()
        for el in col:
            if _tname(el) != "FamilyInstance":
                continue
            fam, _ = _fam_type(el)
            if fam in fams:
                fams[fam][0] += 1
            else:
                fams[fam] = [1, el, lab]
    return fams


list_generic_families = list_families


def list_foundation_families(doc):
    """[(ten family, so luong)] cua Structural Foundation (de chon family la dai coc)."""
    cnt = {}
    col = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFoundation).WhereElementIsNotElementType()
    for el in col:
        if _tname(el) != "FamilyInstance" and not _is_slab(el):
            continue
        fam, _ = _fam_type(el, doc)
        cnt[fam] = cnt.get(fam, 0) + 1
    return sorted(cnt.items(), key=lambda t: t[0].lower())


def _plain(s):
    s = unicodedata.normalize("NFD", u"%s" % (s or u""))
    s = u"".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.replace(u"đ", u"d").replace(u"Đ", u"D").lower()


def guess_dai(name):
    p = _plain(name)
    for h in ("dai coc", "dai mong", "daicoc", "daimong", "pile cap", "pilecap", "pile_cap", "pile-cap"):
        if h in p:
            return True
    return p == "dai" or p.startswith("dai ") or p.startswith("dai_") or p.startswith("dai-")


def list_numeric_params(el):
    names = []
    seen = set()
    sources = [el]
    try:
        sources.append(el.Symbol)
    except Exception:
        pass
    for src in sources:
        try:
            for p in src.Parameters:
                try:
                    if p.StorageType == StorageType.Double:
                        nm = p.Definition.Name
                        if nm not in seen:
                            seen.add(nm)
                            names.append(nm)
                except Exception:
                    continue
        except Exception:
            continue
    names.sort(key=lambda s: s.lower())
    return names


def _param_mm(el, name):
    if not name:
        return None
    for src in (el, getattr(el, "Symbol", None)):
        if src is None:
            continue
        try:
            p = src.LookupParameter(name)
            if p is not None and p.StorageType == StorageType.Double and p.HasValue:
                return p.AsDouble() * FT
        except Exception:
            continue
    return None


def _pile_info(el, cfg, ctx):
    bb = el.get_BoundingBox(None)
    if bb is None:
        return None
    pos = _location_xy(el, ctx)
    a = ctx.xy(bb.Min)
    b = ctx.xy(bb.Max)
    ex = abs(b[0] - a[0])
    ey = abs(b[1] - a[1])
    if pos is None:
        pos = ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
    d = _param_mm(el, cfg.get("d_param"))
    if not d:
        d = max(ex, ey)
    dai = _param_mm(el, cfg.get("l_param"))
    if not dai:
        dai = (bb.Max.Z - bb.Min.Z) * FT
    fam, typ = _fam_type(el)
    return {"id": _eid(el.Id), "fam": fam, "type": typ, "x": pos[0], "y": pos[1], "d": d,
            "dai": dai, "ztop": ctx.z(bb.Max.Z), "zbot": ctx.z(bb.Min.Z),
            "shape": cfg.get("shape") or u"Tròn"}


def _samples(p0, p1, step=100.0):
    L = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
    n = max(int(L / step), 1)
    pts = [(p0[0] + (p1[0] - p0[0]) * i / float(n), p0[1] + (p1[1] - p0[1]) * i / float(n)) for i in range(n + 1)]
    return pts


def _proj_t(pt, p0, p1):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    l2 = dx * dx + dy * dy
    if l2 < 1e-9:
        return 0.0
    return max(0.0, min(1.0, ((pt[0] - p0[0]) * dx + (pt[1] - p0[1]) * dy) / l2))


# ------------------------------------------------------------------ quet chinh
def scan(doc, levels, pile_cfg, shared, bang_b=800.0):
    """levels: list Level da chon. pile_cfg: dict(families, d_param, l_param, shape, dai_fams).
    So hieu = Mark trong Revit (cung Mark = cung loai, nhap thep mot lan)."""
    notes = []
    lv_ids = set(_eid(l.Id) for l in levels)
    lv_names = dict((_eid(l.Id), l.Name) for l in levels)
    zoff = (levels[0].Elevation - levels[0].ProjectElevation) * FT
    ctx = Ctx(doc, shared, zoff)
    fam_set = set(pile_cfg.get("families") or [])
    dai_set = set(pile_cfg.get("dai_fams") or [])

    # ---- mong dang family (mong don / dai)
    foots = []
    skipped = 0
    fcount = {}
    segs = []
    dams = []
    lvl_z = [(_eid(l.Id), l.Elevation) for l in levels]

    def lid_of(el):
        lid = _level_id(el)
        if lid > 0:
            return lid
        try:                        # Wall Foundation khong co Level: lay Level chon nam trong khoang cao do cua mong
            bb = el.get_BoundingBox(None)
            for i, z in lvl_z:
                if bb.Min.Z - 1.0 <= z <= bb.Max.Z + 1.0:
                    return i
        except Exception:
            pass
        return -1

    def curve_loc(el):
        try:
            return _tname(el.Location) == "LocationCurve"
        except Exception:
            return False

    hdiff = []
    lot_n = [0]            # so mong co khoi BT lot nam trong family (da bo qua)
    shaped = [0]           # so mong co bac / vat (mat cat ve theo hinh that)

    def make_strip(el, lid):
        sh = _shape(el, ctx)
        if sh is None:
            return None
        crv = el.Location.Curve
        p0 = ctx.xy(crv.GetEndPoint(0))
        p1 = ctx.xy(crv.GetEndPoint(1))
        sp = G.strip_params(sh["poly"], p0, p1)
        if sp is None:
            return None
        fam, typ = _fam_type(el, doc)
        zmin, zmax = sh["zmin"], sh["zmax"]
        prof = None
        pr = _profile(el, crv, p0, p1, zmin, ctx)
        if pr is not None:
            # B, lech tam, Z day / Z dinh theo MAT CAT THUC (khong theo hop bao: hop bao co the cao hon hinh khoi that)
            pts, is_rect = pr
            vs = [q[0] for q in pts]
            zs = [q[1] for q in pts]
            if max(vs) - min(vs) > 1.0 and max(zs) - min(zs) > 1.0:
                sp["b"] = max(vs) - min(vs)
                sp["offset"] = (max(vs) + min(vs)) / 2.0
                zlo = min(zs)
                zhi = max(zs)
                if abs((zhi - zlo) - (zmax - zmin)) > 1.0:
                    hdiff.append((_eid(el.Id), zmax - zmin, zhi - zlo))
                zmax = zmin + zhi
                zmin = zmin + zlo
                if not is_rect:
                    prof = [(q[0], q[1] - zlo) for q in pts]
        return {"id": _eid(el.Id), "level": lv_names.get(lid, ""), "mark": _mark(el).strip(), "type": typ or fam,
                "poly": sh["poly"], "zmin": zmin, "zmax": zmax, "p0": p0, "p1": p1,
                "sp": sp, "cong": 0 if _tname(crv) == "Line" else 1, "cots": [],
                "reach": sp["b"] / 2.0 + abs(sp["offset"]),
                "prof": prof}

    col = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFoundation).WhereElementIsNotElementType()
    for el in col:
        tn = _tname(el)
        if tn not in ("FamilyInstance", "WallFoundation") and not _is_slab(el):
            skipped += 1
            continue
        lid = lid_of(el)
        if lid not in lv_ids:
            continue
        fam, typ = _fam_type(el, doc)
        if fam in fam_set:          # family nay da duoc chon la coc
            continue
        if tn in ("FamilyInstance", "WallFoundation") and curve_loc(el):
            # Wall Foundation / family mong dang duong (theo tim) -> mong bang, lay hinh dang that tu model
            fcount[tn + u" (theo đường)"] = fcount.get(tn + u" (theo đường)", 0) + 1
            it = make_strip(el, lid)
            if it is None:
                notes.append(u"Bỏ qua móng băng Id %d (không đọc được hình học)" % _eid(el.Id))
            else:
                it["forced"] = True
                segs.append(it)
            continue
        fcount[tn + (u" (điểm)" if tn == "FamilyInstance" else u"")] = fcount.get(tn + (u" (điểm)" if tn == "FamilyInstance" else u""), 0) + 1
        sh = _shape_foot(el, ctx)
        if sh is None:
            notes.append(u"Bỏ qua móng Id %d (không đọc được hình học)" % _eid(el.Id))
            continue
        ang, eu, ev, cx, cy = G.min_area_rect(sh["poly"])
        dat = _location_xy(el, ctx) or (cx, cy)
        try:
            mcA, mcB = _foot_profiles(el, sh, ctx, ang, cx, cy)
        except Exception:
            mcA, mcB = "", ""
        if sh["lot"]:
            lot_n[0] += 1
        if mcA or mcB or sh["bac"]:
            shaped[0] += 1
        foots.append({"el": el, "id": _eid(el.Id), "level": lv_names.get(lid, ""), "mark": _mark(el).strip(),
                      "fam": fam, "type": typ, "poly": sh["poly"], "zmin": sh["zmin"], "zmax": sh["zmax"],
                      "ang": ang, "B": eu, "L": ev, "cx": cx, "cy": cy, "dat": dat,
                      "bbox": G.bbox(sh["poly"]), "note": sh["note"], "piles": [], "cots": [],
                      "bac": sh["bac"], "mcA": mcA, "mcB": mcB})
        if sh["note"] == "bbox":
            notes.append(u"Móng Id %d: không có mặt đáy phẳng, dùng hộp bao" % _eid(el.Id))
    if skipped:
        notes.append(u"Bỏ qua %d đối tượng Structural Foundation loại khác (chỉ đọc Family, Wall Foundation và Foundation Slab)" % skipped)
    if fcount:
        notes.append(u"Structural Foundation trong Level đã chọn: " + u", ".join(
            u"%s %d" % (k, v) for k, v in sorted(fcount.items())) + u".  Móng băng nhận theo: Wall Foundation / family móng theo đường, và dầm Structural Framing có B > ngưỡng.")

    # ---- coc (Generic Models + Structural Foundation + Structural Columns)
    piles = []
    if fam_set:
        for bic, _lab in _cat_list():
            col = FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType()
            for el in col:
                if _tname(el) != "FamilyInstance":
                    continue
                fam, _ = _fam_type(el)
                if fam not in fam_set:
                    continue
                info = _pile_info(el, pile_cfg, ctx)
                if info:
                    piles.append(info)

    for p in piles:
        p["owner"] = None
        cands = []
        for f in foots:
            x0, y0, x1, y1 = f["bbox"]
            if not (x0 - BBOX_PAD <= p["x"] <= x1 + BBOX_PAD and y0 - BBOX_PAD <= p["y"] <= y1 + BBOX_PAD):
                continue
            if p["ztop"] < f["zmin"] - PILE_Z_TOL or p["zbot"] > f["zmax"] + PILE_Z_TOL:
                continue
            if G.point_in_poly((p["x"], p["y"]), f["poly"], 50.0):
                cands.append(f)
        if cands:
            f = min(cands, key=lambda q: G.area(q["poly"]))
            f["piles"].append(p)
            p["owner"] = f

    def is_dai(f):
        return bool(f["piles"]) or f["fam"] in dai_set

    n_dai_coc = len([f for f in foots if f["piles"]])
    n_dai_fam = len([f for f in foots if not f["piles"] and f["fam"] in dai_set])
    notes.insert(0, u"Móng đọc được: %d  (móng đơn %d, đài cọc %d: nhận theo cọc %d + theo Family đài %d)" % (
        len(foots), len(foots) - n_dai_coc - n_dai_fam, n_dai_coc + n_dai_fam, n_dai_coc, n_dai_fam))
    if not fam_set and not dai_set:
        notes.insert(1, u"Chưa chọn family cọc (mục 2) hay family đài (mục 2b) nên mọi móng được coi là móng đơn.")
    elif fam_set and not piles:
        notes.insert(1, u"Không tìm thấy cọc nào thuộc family đã chọn ở mục 2 (đã tìm trong Generic Models, Structural Foundation, Structural Columns).")
    elif piles:
        orphan = [p for p in piles if p["owner"] is None]
        msg = u"Cọc: tìm thấy %d, thuộc đài %d, chưa thuộc đài nào %d" % (len(piles), len(piles) - len(orphan), len(orphan))
        if orphan:
            msg += u"  (Id: %s%s) - tim cọc phải nằm trong biên móng, cao độ cọc chạm khoảng đài (±%d mm)" % (
                u", ".join(u"%d" % p["id"] for p in orphan[:8]), u" ..." if len(orphan) > 8 else u"", PILE_Z_TOL)
        notes.insert(1, msg)

    # ---- dam / mong bang (Structural Framing)
    col = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType()
    for el in col:
        if _tname(el) != "FamilyInstance":
            continue
        lid = _level_id(el)
        if lid not in lv_ids:
            continue
        if not curve_loc(el):
            continue
        item = make_strip(el, lid)
        if item is None:
            continue
        if item["sp"]["b"] > bang_b:
            segs.append(item)
        else:
            dams.append(item)

    if lot_n[0]:
        notes.insert(1, u"Móng đơn/đài: %d móng có khối bê tông lót nằm trong family - đã bỏ qua khi lấy hình dạng và chiều cao" % lot_n[0])
    if shaped[0]:
        notes.insert(1, u"Móng đơn/đài: %d móng có bậc / vát - mặt bằng vẽ nét đứt các bậc, mặt cắt vẽ theo hình thật" % shaped[0])
    if hdiff:
        ex = hdiff[0]
        notes.insert(1, u"Móng băng/dầm móng: %d cấu kiện có chiều cao theo MẶT CẮT THỰC khác hộp bao (vd Id %d: hộp bao %.0f, mặt cắt thực %.0f) - đã lấy theo mặt cắt thực" % (
            len(hdiff), ex[0], ex[1], ex[2]))

    # ---- dat so hieu theo Mark (khong co Mark -> ten tam, co canh bao)
    all_marks = set([f["mark"] for f in foots if f["mark"]] + [s["mark"] for s in segs if s["mark"]]
                    + [d["mark"] for d in dams if d["mark"]])
    counters = {}

    def auto(prefix):
        n = counters.get(prefix, 0)
        while True:
            n += 1
            nm = u"%s%d" % (prefix, n)
            if nm not in all_marks:
                break
        counters[prefix] = n
        return nm

    def order_key(f):
        return (round(f["zmin"] / 50.0), round(f["cx"] / 10.0), round(f["cy"] / 10.0))

    dai_list = sorted([f for f in foots if is_dai(f)], key=order_key)
    don_list = sorted([f for f in foots if not is_dai(f)], key=order_key)
    for f in don_list:
        f["ten"] = f["mark"] or auto(u"MĐ?")
        f["loai"] = "MongDon"
    for f in dai_list:
        f["ten"] = f["mark"] or auto(u"ĐM?")
        f["loai"] = "DaiMong"

    unm = [s for s in segs if not s["mark"]]
    gid = G.group_segments(unm) if unm else []
    for s, g in zip(unm, gid):
        s["g"] = g
    gorder = {}
    for s in sorted(unm, key=lambda s: (round(s["p0"][0] / 10.0), round(s["p0"][1] / 10.0))):
        if s["g"] not in gorder:
            gorder[s["g"]] = auto(u"MB?")
    for s in segs:
        s["nhom"] = s["mark"] if s["mark"] else gorder[s["g"]]

    for d in sorted(dams, key=lambda d: (round(d["zmin"] / 50.0), round(d["p0"][0] / 10.0), round(d["p0"][1] / 10.0))):
        d["ten"] = d["mark"] or auto(u"DAM?")

    nomark = len([f for f in foots if not f["mark"]]) + len(unm) + len([d for d in dams if not d["mark"]])
    if nomark:
        notes.insert(2, u"%d cấu kiện chưa có Mark trong Revit (tên tạm có dấu ?, nên điền Mark rồi quét lại)" % nomark)

    # ---- goi cua dam mong: cac dai / mong (dung theo tim dam) + cot cay tren dam
    for d in dams:
        pts = _samples(d["p0"], d["p1"])
        dx0, dy0, dx1, dy1 = G.bbox(d["poly"])
        sup = []
        for f in foots:
            x0, y0, x1, y1 = f["bbox"]
            if x1 < dx0 - 150 or x0 > dx1 + 150 or y1 < dy0 - 150 or y0 > dy1 + 150:
                continue
            hit = None
            for i, pt in enumerate(pts):
                eps = 150.0 if i in (0, len(pts) - 1) else 0.0
                if G.point_in_poly(pt, f["poly"], eps):
                    hit = i
                    break
            if hit is not None:
                sup.append((hit / float(max(len(pts) - 1, 1)), f["ten"], f["id"]))
        for end_i, t_end in ((0, 0.0), (len(pts) - 1, 1.0)):
            pt = pts[end_i]
            if any(G.point_in_poly(pt, f["poly"], 150.0) for f in foots
                   if f["bbox"][0] - 150 <= pt[0] <= f["bbox"][2] + 150 and f["bbox"][1] - 150 <= pt[1] <= f["bbox"][3] + 150):
                continue
            for s in segs:
                if G.point_in_poly(pt, s["poly"], 150.0) and not any(x[1] == s["nhom"] for x in sup):
                    sup.append((t_end, s["nhom"], s["id"]))
                    break
        sup.sort(key=lambda x: x[0])
        d["goi"] = sup

    # ---- cot tren mong / dam
    cols_out = []
    col = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType()
    areas = [(f["bbox"], f) for f in foots]
    seg_boxes = [(G.bbox(s["poly"]), s) for s in segs]
    dam_boxes = [(G.bbox(d["poly"]), d) for d in dams]

    def near_list(boxes, mx, my, zmin, zmax):
        return [o for bx, o in boxes if bx[0] - BBOX_PAD <= mx <= bx[2] + BBOX_PAD and bx[1] - BBOX_PAD <= my <= bx[3] + BBOX_PAD
                and zmax >= o["zmin"] and zmin <= o["zmax"] + COL_Z_TOL]

    for el in col:
        if _tname(el) != "FamilyInstance":
            continue
        if fam_set and _fam_type(el)[0] in fam_set:
            continue
        bb = el.get_BoundingBox(None)
        if bb is None:
            continue
        a = ctx.xy(bb.Min)
        b = ctx.xy(bb.Max)
        mx, my = (a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0
        zmin, zmax = ctx.z(bb.Min.Z), ctx.z(bb.Max.Z)
        near = near_list(areas, mx, my, zmin, zmax)
        near_s = near_list(seg_boxes, mx, my, zmin, zmax)
        near_d = near_list(dam_boxes, mx, my, zmin, zmax)
        if not near and not near_s and not near_d:
            continue
        sh = _shape(el, ctx)
        if sh is None:
            continue
        ang, eu, ev, cx, cy = G.min_area_rect(sh["poly"])
        owner, dam_owner, loai, ten, tid = None, None, "", "", 0
        for f in near:
            if G.point_in_poly((cx, cy), f["poly"], 5.0):
                owner, loai, ten, tid = f, f["loai"], f["ten"], f["id"]
                break
        if owner is None:
            for s in near_s:
                if G.point_in_poly((cx, cy), s["poly"], 5.0):
                    loai, ten, tid = "MongBang", s["nhom"], s["id"]
                    break
        if not ten:
            for d in near_d:
                if G.point_in_poly((cx, cy), d["poly"], 5.0):
                    dam_owner, loai, ten, tid = d, "DamMong", d["ten"], d["id"]
                    break
        if not ten:
            continue
        fam, typ = _fam_type(el)
        rec = {"id": _eid(el.Id), "mark": _mark(el).strip(), "type": typ or fam, "level": lv_names.get(_level_id(el), ""),
               "x": cx, "y": cy, "ang": ang, "b": eu, "h": ev, "poly": sh["poly"], "loai": loai, "ten": ten, "tid": tid}
        cols_out.append(rec)
        if owner is not None:
            owner["cots"].append(rec)
        if dam_owner is not None:
            dam_owner["cots"].append((_proj_t((cx, cy), dam_owner["p0"], dam_owner["p1"]), rec))

    # ---- dong goi du lieu
    data = dict((k, []) for k in M.ORDER)
    for f in sorted(don_list + dai_list, key=lambda f: (f["loai"] != "MongDon", M.nat_key(f["ten"]), f["id"])):
        r = M.new_record(f["loai"])
        r.update({"Ten": f["ten"], "Level": f["level"], "ElementId": u"%d" % f["id"], "Mark": f["mark"],
                  "Family": f["fam"], "Type": f["type"], "TamX": f["cx"], "TamY": f["cy"],
                  "DatX": f["dat"][0], "DatY": f["dat"][1], "Goc": f["ang"], "B": f["B"], "L": f["L"],
                  "H": f["zmax"] - f["zmin"], "ZDay": f["zmin"], "ZDinh": f["zmax"],
                  "SoCot": len(f["cots"]), "BienDang": M.poly_to_str(f["poly"]),
                  "Bac": M.bac_to_str(f["bac"]), "MatCatA": f["mcA"], "MatCatB": f["mcB"]})
        if f["loai"] == "DaiMong":
            r["SoCoc"] = len(f["piles"])
        data[f["loai"]].append(r)
    for p in sorted(piles, key=lambda p: ((M.nat_key(p["owner"]["ten"]) if p["owner"] else [u"~"]), p["x"], p["y"])):
        r = M.new_record("Coc")
        r.update({"ElementId": u"%d" % p["id"], "Family": p["fam"], "Type": p["type"], "X": p["x"], "Y": p["y"],
                  "D": p["d"], "Dai": p["dai"], "ZDinh": p["ztop"], "ZMui": p["zbot"], "HinhDang": p["shape"],
                  "ThuocDai": p["owner"]["ten"] if p["owner"] else "",
                  "ThuocId": (u"%d" % p["owner"]["id"]) if p["owner"] else ""})
        data["Coc"].append(r)
    for s in sorted(segs, key=lambda s: (M.nat_key(s["nhom"]), s["p0"][0], s["p0"][1])):
        r = M.new_record("MongBang")
        r.update({"Nhom": s["nhom"], "Level": s["level"], "ElementId": u"%d" % s["id"], "Mark": s["mark"],
                  "Type": s["type"], "X1": s["p0"][0], "Y1": s["p0"][1], "X2": s["p1"][0], "Y2": s["p1"][1],
                  "Dai": s["sp"]["len"], "B": s["sp"]["b"], "H": s["zmax"] - s["zmin"],
                  "LechTam": s["sp"]["offset"], "ZDay": s["zmin"], "ZDinh": s["zmax"], "Cong": s["cong"],
                  "BienDang": M.poly_to_str(s["poly"]), "MatCat": M.poly_to_str(s["prof"]) if s.get("prof") else ""})
        data["MongBang"].append(r)
    for d in sorted(dams, key=lambda d: (M.nat_key(d["ten"]), d["p0"][0], d["p0"][1])):
        cots_sorted = sorted(d["cots"], key=lambda x: x[0])
        r = M.new_record("DamMong")
        r.update({"Ten": d["ten"], "Level": d["level"], "ElementId": u"%d" % d["id"], "Mark": d["mark"],
                  "Type": d["type"], "X1": d["p0"][0], "Y1": d["p0"][1], "X2": d["p1"][0], "Y2": d["p1"][1],
                  "Dai": d["sp"]["len"], "B": d["sp"]["b"], "H": d["zmax"] - d["zmin"],
                  "LechTam": d["sp"]["offset"], "ZDay": d["zmin"], "ZDinh": d["zmax"], "Cong": d["cong"],
                  "NoiDai": u" - ".join(x[1] for x in d["goi"]), "SoGoi": len(d["goi"]),
                  "GoiId": u";".join(u"%d" % x[2] for x in d["goi"]),
                  "SoCot": len(cots_sorted),
                  "GoiCot": u", ".join((c["mark"] or (u"Id%d" % c["id"])) for _, c in cots_sorted),
                  "BienDang": M.poly_to_str(d["poly"]), "MatCat": M.poly_to_str(d["prof"]) if d.get("prof") else ""})
        data["DamMong"].append(r)
    for c in sorted(cols_out, key=lambda c: (c["loai"], M.nat_key(c["ten"]), c["x"], c["y"])):
        r = M.new_record("Cot")
        r.update({"ElementId": u"%d" % c["id"], "Mark": c["mark"], "Type": c["type"], "Level": c["level"],
                  "X": c["x"], "Y": c["y"], "Goc": c["ang"], "B": c["b"], "H": c["h"],
                  "BienDang": M.poly_to_str(c["poly"]), "LoaiMong": c["loai"], "ThuocMong": c["ten"],
                  "ThuocId": u"%d" % c["tid"]})
        data["Cot"].append(r)

    info = {u"Công cụ": u"XCTX - Quét Móng (bước 1)",
            u"Model": doc.Title,
            u"Level quét": u"; ".join(l.Name for l in levels),
            u"Gốc toạ độ": u"Shared Coordinates" if shared else u"Internal Origin",
            u"Z chuẩn": u"theo Project Base Point (mm)",
            u"Số hiệu": u"theo Mark trong Revit (cùng Mark = cùng loại, nhập thép một lần)",
            u"B dầm > (móng băng)": bang_b,
            u"Đơn vị": u"mm",
            u"Family cọc": u"; ".join(sorted(fam_set)),
            u"Family đài cọc": u"; ".join(sorted(dai_set)),
            u"Tham số đường kính": pile_cfg.get("d_param") or u"(hộp bao)",
            u"Tham số chiều dài": pile_cfg.get("l_param") or u"(hộp bao)"}
    return data, info, notes

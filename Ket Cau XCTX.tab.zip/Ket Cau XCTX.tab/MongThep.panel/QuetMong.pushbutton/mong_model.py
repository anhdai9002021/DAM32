# -*- coding: utf-8 -*-
"""Mo hinh du lieu mong: cot Excel, ma hoa bien dang, luu/doc Excel, kiem tra loi."""
import math
import re
import mong_geom as G
import xlsxio

# (ten cot, kieu) kieu: s = chuoi, n = so, b = tick (1/0)
SPEC = {
    "MongDon": [("Chon", "b"), ("Ten", "s"), ("Level", "s"), ("ElementId", "s"), ("Mark", "s"),
                ("Family", "s"), ("Type", "s"), ("TamX", "n"), ("TamY", "n"), ("DatX", "n"),
                ("DatY", "n"), ("Goc", "n"), ("B", "n"), ("L", "n"), ("H", "n"), ("ZDay", "n"),
                ("ZDinh", "n"), ("SoCot", "n"), ("BienDang", "s"), ("Bac", "s"), ("MatCatA", "s"),
                ("MatCatB", "s"), ("CanhBao", "s")],
    "DaiMong": [("Chon", "b"), ("Ten", "s"), ("Level", "s"), ("ElementId", "s"), ("Mark", "s"),
                ("Family", "s"), ("Type", "s"), ("TamX", "n"), ("TamY", "n"), ("DatX", "n"),
                ("DatY", "n"), ("Goc", "n"), ("B", "n"), ("L", "n"), ("H", "n"), ("ZDay", "n"),
                ("ZDinh", "n"), ("SoCot", "n"), ("SoCoc", "n"), ("BienDang", "s"), ("Bac", "s"), ("MatCatA", "s"),
                ("MatCatB", "s"), ("CanhBao", "s")],
    "Coc": [("Chon", "b"), ("ElementId", "s"), ("Family", "s"), ("Type", "s"), ("X", "n"), ("Y", "n"),
            ("D", "n"), ("Dai", "n"), ("ZDinh", "n"), ("ZMui", "n"), ("HinhDang", "s"),
            ("ThuocDai", "s"), ("ThuocId", "s"), ("CanhBao", "s")],
    "MongBang": [("Chon", "b"), ("Nhom", "s"), ("Level", "s"), ("ElementId", "s"), ("Mark", "s"),
                 ("Type", "s"), ("X1", "n"), ("Y1", "n"), ("X2", "n"), ("Y2", "n"), ("Dai", "n"),
                 ("B", "n"), ("H", "n"), ("LechTam", "n"), ("ZDay", "n"), ("ZDinh", "n"),
                 ("Cong", "n"), ("BienDang", "s"), ("MatCat", "s"), ("CanhBao", "s")],
    "DamMong": [("Chon", "b"), ("Ten", "s"), ("Level", "s"), ("ElementId", "s"), ("Mark", "s"),
                ("Type", "s"), ("X1", "n"), ("Y1", "n"), ("X2", "n"), ("Y2", "n"), ("Dai", "n"),
                ("B", "n"), ("H", "n"), ("LechTam", "n"), ("ZDay", "n"), ("ZDinh", "n"),
                ("Cong", "n"), ("NoiDai", "s"), ("SoGoi", "n"), ("GoiCot", "s"), ("SoCot", "n"),
                ("GoiId", "s"), ("BienDang", "s"), ("MatCat", "s"), ("CanhBao", "s")],
    "Cot": [("Chon", "b"), ("ElementId", "s"), ("Mark", "s"), ("Type", "s"), ("Level", "s"),
            ("X", "n"), ("Y", "n"), ("Goc", "n"), ("B", "n"), ("H", "n"), ("BienDang", "s"),
            ("LoaiMong", "s"), ("ThuocMong", "s"), ("ThuocId", "s"), ("CanhBao", "s")],
}
SPEC["Thep"] = [("Ten", "s"), ("Loai", "s"), ("STT", "n"), ("ViTri", "s"), ("D", "n"), ("A", "n"),
                ("SoThanh", "n"), ("LopBV", "n"), ("GhiChu", "s")]
ORDER = ["MongDon", "DaiMong", "Coc", "MongBang", "DamMong", "Cot"]
SAVE_ORDER = ORDER + ["Thep"]

TITLES = {"MongDon": u"Móng đơn", "DaiMong": u"Đài cọc", "Coc": u"Cọc",
          "MongBang": u"Móng băng", "DamMong": u"Dầm móng", "Cot": u"Cột"}

LABELS = {
    "Chon": u"Chọn", "Ten": u"Tên", "Level": "Level", "Mark": "Mark", "Family": "Family",
    "Type": "Type", "TamX": u"Tâm X", "TamY": u"Tâm Y", "DatX": u"Đặt X", "DatY": u"Đặt Y",
    "Goc": u"Góc°", "B": "B", "L": "L", "H": "H", "ZDay": u"Z đáy", "ZDinh": u"Z đỉnh",
    "SoCot": u"Số cột", "SoCoc": u"Số cọc", "BienDang": u"Biên dạng", "CanhBao": u"Cảnh báo",
    "X": "X", "Y": "Y", "D": u"Đ.kính/cạnh", "Dai": u"Dài", "ZMui": u"Z mũi",
    "HinhDang": u"Hình dạng", "ThuocDai": u"Thuộc đài", "Nhom": u"Nhóm",
    "X1": "X1", "Y1": "Y1", "X2": "X2", "Y2": "Y2", "LechTam": u"Lệch tâm",
    "Cong": u"Cong", "NoiDai": u"Gối đài/móng", "SoGoi": u"Số gối", "GoiCot": u"Cột trên dầm", "GoiId": u"Id gối", "ThuocId": u"Id móng", "LoaiMong": u"Loại móng", "ThuocMong": u"Thuộc móng",
    "ElementId": "ElementId", "MatCat": u"Mặt cắt thực", "Bac": u"Bậc / vát (mặt bằng)",
    "MatCatA": u"Mặt cắt A-A thực", "MatCatB": u"Mặt cắt B-B thực",
}

EDITABLE = {
    "MongDon": ("Chon",),
    "DaiMong": ("Chon",),
    "Coc": ("Chon", "D", "Dai"),
    "MongBang": ("Chon",),
    "DamMong": ("Chon",),
    "Cot": ("Chon",),
}

HIDDEN = ("BienDang", "MatCat", "Bac", "MatCatA", "MatCatB", "DatX", "DatY", "ThuocId", "GoiId")


def nat_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", u"%s" % (s if s is not None else u""))]


def fsig(sh, r):
    t = (r.get("Family"), r.get("Type"), int(round(to_float(r.get("B")))), int(round(to_float(r.get("L")))),
         int(round(to_float(r.get("H")))))
    return t + ((int(to_float(r.get("SoCoc"))),) if sh == "DaiMong" else ())


def ssig(r):
    return (r.get("Type"), int(round(to_float(r.get("B")))), int(round(to_float(r.get("H")))))


def mark_summary(data):
    """Bang tong hop theo Mark: loai, Mark, so cau kien, type, kich thuoc, thep."""
    rows = [[u"Loại", u"Mark / Nhóm", u"Số cấu kiện", u"Family / Type", u"Kích thước (mm)", u"Số cọc / cột", u"Thép"]]
    have = set((t.get("Loai"), t.get("Ten")) for t in data.get("Thep", []))
    for sh in ("MongDon", "DaiMong", "MongBang", "DamMong"):
        key = "Nhom" if sh == "MongBang" else "Ten"
        groups, order = {}, []
        for r in data.get(sh, []):
            k = r.get(key)
            if k not in groups:
                groups[k] = []
                order.append(k)
            groups[k].append(r)
        for k in sorted(order, key=nat_key):
            lst = groups[k]
            r = lst[0]
            if sh in ("MongDon", "DaiMong"):
                ft = u"%s / %s" % (r.get("Family"), r.get("Type"))
                sz = u"%d x %d x %d" % (round(to_float(r.get("B"))), round(to_float(r.get("L"))), round(to_float(r.get("H"))))
                if len(set(fsig(sh, x) for x in lst)) > 1:
                    sz += u"  (nhiều kích thước)"
                extra = u"%d cột" % sum(int(to_float(x.get("SoCot"))) for x in lst)
                if sh == "DaiMong":
                    extra += u", %d cọc" % sum(int(to_float(x.get("SoCoc"))) for x in lst)
            else:
                ft = u"%s" % r.get("Type")
                sz = u"B %d x H %d" % (round(to_float(r.get("B"))), round(to_float(r.get("H"))))
                extra = u"dài tổng %.1f m" % (sum(to_float(x.get("Dai")) for x in lst) / 1000.0)
                if sh == "DamMong":
                    extra += u", %d cột" % sum(int(to_float(x.get("SoCot"))) for x in lst)
            rows.append([TITLES[sh], u"%s" % k, len(lst), ft, sz, extra, u"có" if (sh, k) in have else u"chưa"])
    return rows


def cols(sheet):
    return [c for c, _ in SPEC[sheet]]


def ctype(sheet, col):
    for c, t in SPEC[sheet]:
        if c == col:
            return t
    return "s"


def new_record(sheet):
    rec = {}
    for c, t in SPEC[sheet]:
        rec[c] = 0 if t == "n" else (1 if c == "Chon" else "")
    if "Chon" in rec:
        rec["Chon"] = 1
    return rec


def poly_to_str(poly):
    return ";".join("%.1f,%.1f" % (p[0], p[1]) for p in poly)


def str_to_poly(s):
    out = []
    if not s:
        return out
    for part in str(s).split(";"):
        try:
            x, y = part.split(",")
            out.append((float(x), float(y)))
        except Exception:
            continue
    return out


def bac_to_str(bac):
    """[(z_tu_day, da_giac)] -> 'z@x,y;x,y|z@...' (cac bac / mat vat cua mong don, dai)."""
    return "|".join("%.0f@%s" % (z, poly_to_str(p)) for z, p in bac)


def str_to_bac(s):
    out = []
    if not s:
        return out
    for part in str(s).split("|"):
        try:
            z, ps = part.split("@", 1)
            poly = str_to_poly(ps)
            if poly:
                out.append((float(z), poly))
        except Exception:
            continue
    return out


def to_float(v, default=0.0):
    try:
        if v is None or v == "":
            return default
        return float(v)
    except Exception:
        return default


def to_flag(v):
    if isinstance(v, bool):
        return 1 if v else 0
    if v is None or v == "":
        return 0
    s = str(v).strip().lower()
    if s in ("1", "1.0", "true", "x", "yes", "co", u"có"):
        return 1
    return 0


# ---------------------------------------------------------------- Excel
def _rows(sheet, recs):
    head = cols(sheet)
    rows = [head]
    for r in recs:
        row = []
        for c, t in SPEC[sheet]:
            v = r.get(c)
            if t == "n":
                v = round(to_float(v), 2)
                if v == int(v):
                    v = int(v)
            elif t == "b":
                v = to_flag(v)
            else:
                v = u"" if v is None else u"%s" % v
            row.append(v)
        rows.append(row)
    return rows


def save_model(path, data, info):
    sheets = [("Info", [[u"Mục", u"Giá trị"]] + [[k, v] for k, v in info.items()])]
    sheets.append((u"TongHopMark", mark_summary(data)))
    for sh in SAVE_ORDER:
        sheets.append((sh, _rows(sh, data.get(sh, []))))
    xlsxio.write_xlsx(path, sheets)


def load_model(path):
    book = dict(xlsxio.read_xlsx(path))
    info = {}
    for row in book.get("Info", [])[1:]:
        if row and row[0] is not None:
            info[u"%s" % row[0]] = row[1] if len(row) > 1 else ""
    data = {}
    for sh in SAVE_ORDER:
        rows = book.get(sh, [])
        recs = []
        if rows:
            head = [u"%s" % h if h is not None else "" for h in rows[0]]
            for r in rows[1:]:
                if not any(v not in (None, "") for v in r):
                    continue
                rec = new_record(sh)
                for j, h in enumerate(head):
                    if h in rec and j < len(r):
                        v = r[j]
                        t = ctype(sh, h)
                        if t == "n":
                            rec[h] = to_float(v)
                        elif t == "b":
                            rec[h] = to_flag(v)
                        else:
                            rec[h] = u"" if v is None else (u"%d" % v if isinstance(v, int) else u"%s" % v)
                recs.append(rec)
        data[sh] = recs
    backfill_ids(data)
    return data, info


def backfill_ids(data):
    """File Excel cu chua co ThuocId: suy ra tu ten (lay cau kien dau tien cung ten)."""
    first = {}
    for sh in ("MongDon", "DaiMong"):
        for r in data.get(sh, []):
            first.setdefault((sh, r.get("Ten")), r.get("ElementId"))
    for r in data.get("MongBang", []):
        first.setdefault(("MongBang", r.get("Nhom")), r.get("ElementId"))
    for r in data.get("DamMong", []):
        first.setdefault(("DamMong", r.get("Ten")), r.get("ElementId"))
    for c in data.get("Coc", []):
        if not c.get("ThuocId") and c.get("ThuocDai"):
            c["ThuocId"] = first.get(("DaiMong", c.get("ThuocDai")), "") or ""
    for c in data.get("Cot", []):
        if not c.get("ThuocId") and c.get("ThuocMong"):
            c["ThuocId"] = first.get((c.get("LoaiMong"), c.get("ThuocMong")), "") or ""


# ---------------------------------------------------------------- kiem tra
def run_checks(data):
    """Tinh lai cot CanhBao. Tra ve list[(sheet, idx, nhan, noi_dung)]."""
    warn = {}

    def add(sheet, i, msg):
        warn.setdefault((sheet, i), []).append(msg)

    footings = []
    for sh in ("MongDon", "DaiMong"):
        for i, r in enumerate(data.get(sh, [])):
            footings.append((sh, i, r, str_to_poly(r.get("BienDang"))))

    # ---- Mark: cung Mark phai cung loai; thieu Mark
    by_name, sh_of = {}, {}
    for sh, i, r, poly in footings:
        by_name.setdefault((sh, r.get("Ten")), []).append((i, r))
        sh_of.setdefault(r.get("Ten"), set()).add(sh)
    for (sh, nm), lst in by_name.items():
        if len(set(fsig(sh, r) for _, r in lst)) > 1:
            for i, _ in lst:
                add(sh, i, u"Mark %s dùng cho các móng khác nhau (khác Type / kích thước / số cọc)" % nm)
    for sh, i, r, poly in footings:
        if not r.get("Mark"):
            add(sh, i, u"Chưa có Mark trong Revit")
        if len(sh_of.get(r.get("Ten"), ())) > 1:
            add(sh, i, u"Mark %s trùng giữa móng đơn và đài cọc" % r.get("Ten"))

    cot_by = {}
    for j, c in enumerate(data.get("Cot", [])):
        cot_by.setdefault((c.get("LoaiMong"), c.get("ThuocId")), []).append((j, c))
    coc_by = {}
    for j, c in enumerate(data.get("Coc", [])):
        coc_by.setdefault(c.get("ThuocId"), []).append((j, c))

    for sh, i, r, poly in footings:
        if len(poly) < 3 or G.area(poly) < 1000.0:
            add(sh, i, u"Biên dạng không hợp lệ")
        if min(to_float(r.get("B")), to_float(r.get("L")), to_float(r.get("H"))) <= 0:
            add(sh, i, u"Thiếu kích thước B/L/H")
        cots = cot_by.get((sh, r.get("ElementId")), [])
        if not cots:
            add(sh, i, u"Không tìm thấy cột trên móng")
        for j, c in cots:
            cp = str_to_poly(c.get("BienDang"))
            if cp and poly and any(not G.point_in_poly(p, poly, 5.0) for p in cp):
                add(sh, i, u"Cột %s chờm ra ngoài biên móng" % (c.get("Mark") or c.get("ElementId")))
        if sh == "DaiMong":
            piles = coc_by.get(r.get("ElementId"), [])
            if not piles:
                add(sh, i, u"Đài không có cọc")
            else:
                dmax = max([to_float(c.get("D")) for _, c in piles] + [0.0])
                best = None
                for a in range(len(piles)):
                    for b in range(a + 1, len(piles)):
                        pa, pb = piles[a][1], piles[b][1]
                        d = math.hypot(to_float(pa.get("X")) - to_float(pb.get("X")),
                                       to_float(pa.get("Y")) - to_float(pb.get("Y")))
                        if best is None or d < best:
                            best = d
                if best is not None and dmax > 0 and best < 3.0 * dmax - 1.0:
                    add(sh, i, u"Tim cọc gần nhất %.0f < 3D (%.0f)" % (best, 3.0 * dmax))

    for j, c in enumerate(data.get("Coc", [])):
        if to_float(c.get("D")) <= 0:
            add("Coc", j, u"Thiếu đường kính/cạnh cọc")
        if to_float(c.get("Dai")) <= 0:
            add("Coc", j, u"Thiếu chiều dài cọc")
        if not c.get("ThuocDai"):
            add("Coc", j, u"Cọc không nằm trong đài nào")

    strips = {}
    for j, s in enumerate(data.get("MongBang", [])):
        if to_float(s.get("B")) <= 0 or to_float(s.get("H")) <= 0:
            add("MongBang", j, u"Thiếu bề rộng/chiều cao băng")
        if to_float(s.get("Dai")) <= 0:
            add("MongBang", j, u"Đoạn băng dài 0")
        if to_flag(s.get("Cong")):
            add("MongBang", j, u"Đoạn cong: B và lệch tâm chỉ gần đúng")
        if not s.get("Mark"):
            add("MongBang", j, u"Chưa có Mark trong Revit (nhóm tự đặt %s)" % s.get("Nhom"))
        else:
            strips.setdefault(s.get("Nhom"), []).append((j, s))
    for nm, lst in strips.items():
        if len(set(ssig(s) for _, s in lst)) > 1:
            for j, _ in lst:
                add("MongBang", j, u"Mark %s dùng cho các đoạn khác Type / B / H" % nm)

    dn = {}
    for j, s in enumerate(data.get("DamMong", [])):
        if to_float(s.get("B")) <= 0 or to_float(s.get("H")) <= 0:
            add("DamMong", j, u"Thiếu bề rộng/chiều cao dầm")
        if to_float(s.get("Dai")) <= 0:
            add("DamMong", j, u"Dầm dài 0")
        if to_flag(s.get("Cong")):
            add("DamMong", j, u"Dầm cong: B và lệch tâm chỉ gần đúng")
        if not s.get("Mark"):
            add("DamMong", j, u"Chưa có Mark trong Revit")
        sg, sc = int(to_float(s.get("SoGoi"))), int(to_float(s.get("SoCot")))
        if sg == 0:
            add("DamMong", j, u"Dầm không gối vào đài/móng nào")
        elif sg == 1 and sc == 0:
            add("DamMong", j, u"Dầm chỉ gối vào 1 đài/móng, chưa có gối thứ hai")
        dn.setdefault(s.get("Ten"), []).append((j, s))
    for nm, lst in dn.items():
        if len(set(ssig(s) for _, s in lst)) > 1:
            for j, _ in lst:
                add("DamMong", j, u"Mark %s dùng cho các dầm khác Type / B / H" % nm)

    allpolys = [(sh, i, r, p) for sh, i, r, p in footings]
    for j, c in enumerate(data.get("Cot", [])):
        cp = str_to_poly(c.get("BienDang"))
        if not cp:
            continue
        ctr = G.centroid(cp)
        n = 0
        for sh, i, r, p in allpolys:
            if len(p) >= 3 and G.point_in_poly(ctr, p, 1.0):
                n += 1
        for s in data.get("MongBang", []):
            sp = str_to_poly(s.get("BienDang"))
            if len(sp) >= 3 and G.point_in_poly(ctr, sp, 1.0):
                n += 1
                break
        if n > 1:
            add("Cot", j, u"Cột nằm trong %d móng chồng nhau" % n)
        if not c.get("ThuocMong"):
            add("Cot", j, u"Cột chưa gán móng")

    issues = []
    for sh in ORDER:
        for i, r in enumerate(data.get(sh, [])):
            msgs = warn.get((sh, i), [])
            r["CanhBao"] = u"; ".join(msgs)
            if msgs:
                label = r.get("Ten") or r.get("Nhom") or r.get("Mark") or r.get("ElementId") or ""
                for m in msgs:
                    issues.append((sh, i, u"%s" % label, m))
    return issues

# -*- coding: utf-8 -*-
"""Form xem - kiem tra - nhap thep: luoi du lieu, mat bang / mat cat co kich thuoc, bang thep, canh bao."""
import os
import math
import clr

clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
import System
from System import Array, Object
from System.Drawing import Color, Font, FontStyle, Point, PointF, Size, Pen, SolidBrush
from System.Drawing.Drawing2D import SmoothingMode, DashStyle
from System.Reflection import BindingFlags
from System.Windows.Forms import (
    Form, Panel, Label, Button, TextBox, CheckBox, TabControl, TabPage, DataGridView,
    DataGridViewTextBoxColumn, DataGridViewCheckBoxColumn, DataGridViewComboBoxColumn,
    DataGridViewColumnSortMode, DataGridViewSelectionMode, DataGridViewAutoSizeColumnsMode,
    DataGridViewDataErrorContexts, DockStyle, FormStartPosition, SplitContainer, Orientation, ListBox, BorderStyle,
    MessageBoxIcon, TreeView, TreeNode, ScrollBars)

import mong_model as M
import mong_geom as G
import mong_rebar as R
from mong_ui import (DARK, LIGHT, FONT, apply_theme, msg, ask_yes_no, _button, _label,
                     QuickRebarDialog, BeamReinforceDialog)


def _color(t):
    return Color.FromArgb(int(t[0]), int(t[1]), int(t[2]))


def _dbl(panel):
    try:
        prop = panel.GetType().GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic)
        prop.SetValue(panel, True, None)
    except Exception:
        pass


class Canvas(object):
    """Doi toa do the gioi (x, y huong len) -> man hinh, vua khung. ky>1: gian theo phuong dung."""

    def __init__(self, W, H, bounds, ml=80, mr=80, mt=46, mb=100, ky=1.0):
        x0, y0, x1, y1 = bounds
        w = max(x1 - x0, 1.0)
        h = max(y1 - y0, 1.0) * ky
        aw = max(W - ml - mr, 40.0)
        ah = max(H - mt - mb, 40.0)
        self.k = max(min(aw / w, ah / h), 1e-6)
        self.ky = ky
        self.x0 = x0
        self.y1 = y1
        self.ox = ml + (aw - w * self.k) / 2.0
        self.top = mt + (ah - h * self.k) / 2.0

    def T(self, p):
        return PointF(float(self.ox + (p[0] - self.x0) * self.k),
                      float(self.top + (self.y1 - p[1]) * self.k * self.ky))


def draw_dim(g, a, b, interior, off, text, th, font):
    dx, dy = b.X - a.X, b.Y - a.Y
    L = math.hypot(dx, dy)
    if L < 2.0:
        return
    nx, ny = -dy / L, dx / L
    mx, my = (a.X + b.X) / 2.0, (a.Y + b.Y) / 2.0
    if (mx - interior[0]) * nx + (my - interior[1]) * ny < 0:
        nx, ny = -nx, -ny
    ax, ay = a.X + nx * off, a.Y + ny * off
    bx, by = b.X + nx * off, b.Y + ny * off
    pen = Pen(th["dim"], 1.0)
    g.DrawLine(pen, float(a.X + nx * 3), float(a.Y + ny * 3), float(ax + nx * 4), float(ay + ny * 4))
    g.DrawLine(pen, float(b.X + nx * 3), float(b.Y + ny * 3), float(bx + nx * 4), float(by + ny * 4))
    g.DrawLine(pen, float(ax), float(ay), float(bx), float(by))
    ux, uy = dx / L, dy / L
    for px, py in ((ax, ay), (bx, by)):
        g.DrawLine(pen, float(px - (ux - nx) * 3), float(py - (uy - ny) * 3),
                   float(px + (ux - nx) * 3), float(py + (uy - ny) * 3))
    sz = g.MeasureString(text, font)
    cx, cy = (ax + bx) / 2.0, (ay + by) / 2.0
    tx = cx - sz.Width / 2.0 + nx * (sz.Height / 2.0 + 1)
    ty = cy - sz.Height / 2.0 + ny * (sz.Height / 2.0 + 1)
    g.DrawString(text, font, SolidBrush(th["fg"]), float(tx), float(ty))


class ReviewForm(object):
    def __init__(self, data, info, path, dark=True):
        self.data = data
        self.data.setdefault("Thep", [])
        self.info = info
        self.path = path
        self.th = DARK if dark else LIGHT
        self.rules = dict(R.RULES_DEFAULT)
        self.quick_cfg = dict(R.QUICK_DEFAULT)
        self._load_rules()
        self.grids = {}
        self.loading = False
        self.tloading = False
        self.issues = []
        self.issue_refs = []
        self.cur_key = None
        self.cur_rec = None
        self.cur_sheet = None
        self.hl = None

        f = Form()
        f.Text = u"XCTX - Móng: xem, nhập thép, kiểm tra"
        f.Size = Size(1500, 880)
        f.StartPosition = FormStartPosition.CenterScreen
        f.Font = Font(FONT, 9.0)
        self.f = f

        top = Panel()
        top.Dock = DockStyle.Top
        top.Height = 48
        self.btn_save = _button(u"Lưu Excel", 10, 8, 100)
        self.btn_check = _button(u"Kiểm tra lại", 118, 8, 110)
        self.btn_open = _button(u"Mở Excel", 236, 8, 100)
        self.btn_reload = _button(u"Nạp lại từ Excel", 344, 8, 140)
        self.chk_dark = CheckBox()
        self.chk_dark.Text = u"Giao diện tối"
        self.chk_dark.Location = Point(500, 12)
        self.chk_dark.Size = Size(130, 24)
        self.chk_dark.Checked = dark
        self.lbl_path = Label()
        self.lbl_path.Location = Point(640, 14)
        self.lbl_path.Size = Size(800, 22)
        self.lbl_path.Text = path
        for c in (self.btn_save, self.btn_check, self.btn_open, self.btn_reload, self.chk_dark, self.lbl_path):
            top.Controls.Add(c)
        self.btn_save.Click += self._on_save
        self.btn_check.Click += self._on_check
        self.btn_open.Click += self._on_open
        self.btn_reload.Click += self._on_reload
        self.chk_dark.CheckedChanged += self._on_theme

        bottom = Panel()
        bottom.Dock = DockStyle.Bottom
        bottom.Height = 160
        self.lst = ListBox()
        self.lst.Dock = DockStyle.Fill
        self.lst.Font = Font(FONT, 9.0)
        self.lst.HorizontalScrollbar = True
        self.lst.SelectedIndexChanged += self._on_issue
        self.lbl_sum = Label()
        self.lbl_sum.Dock = DockStyle.Top
        self.lbl_sum.Height = 24
        self.lbl_sum.Font = Font(FONT, 9.0, FontStyle.Bold)
        bottom.Controls.Add(self.lst)
        bottom.Controls.Add(self.lbl_sum)

        self.split = SplitContainer()
        self.split.Dock = DockStyle.Fill
        self.split2 = SplitContainer()
        self.split2.Dock = DockStyle.Fill
        self.split2.Orientation = Orientation.Horizontal
        self.split.Panel2.Controls.Add(self.split2)

        # ---- tab du lieu (trai)
        self.tabs = TabControl()
        self.tabs.Dock = DockStyle.Fill
        self.tabs.Font = Font(FONT, 9.0)
        tong = TabPage()
        tong.Text = u"Tổng hợp"
        tong.Name = "Tong"
        self.tree = TreeView()
        self.tree.Dock = DockStyle.Fill
        self.tree.Font = Font(FONT, 9.5)
        self.tree.HideSelection = False
        self.tree.AfterSelect += self._on_tree
        self.detail = TextBox()
        self.detail.Multiline = True
        self.detail.ReadOnly = True
        self.detail.ScrollBars = ScrollBars.Vertical
        self.detail.Dock = DockStyle.Bottom
        self.detail.Height = 260
        self.detail.Font = Font(FONT, 9.0)
        self.lbl_tot = Label()
        self.lbl_tot.Dock = DockStyle.Top
        self.lbl_tot.Height = 58
        self.lbl_tot.Font = Font(FONT, 9.0, FontStyle.Bold)
        tong.Controls.Add(self.tree)
        tong.Controls.Add(self.detail)
        tong.Controls.Add(self.lbl_tot)
        self.tabs.TabPages.Add(tong)
        self.leaf_nodes = []
        self.groups = {}
        for sh in M.ORDER:
            page = TabPage()
            page.Text = M.TITLES[sh]
            page.Name = sh
            g = DataGridView()
            g.Dock = DockStyle.Fill
            g.AllowUserToAddRows = False
            g.AllowUserToDeleteRows = False
            g.RowHeadersVisible = False
            g.MultiSelect = False
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect
            g.AutoSizeColumnsMode = getattr(DataGridViewAutoSizeColumnsMode, "None")
            g.BorderStyle = getattr(BorderStyle, "None")
            g.SelectionChanged += self._on_sel
            page.Controls.Add(g)
            self.tabs.TabPages.Add(page)
            self.grids[sh] = g
        self.tabs.SelectedIndexChanged += self._on_tab
        self.split.Panel1.Controls.Add(self.tabs)

        # ---- khung xem (phai tren)
        self.views = TabControl()
        self.views.Dock = DockStyle.Fill
        self.views.Font = Font(FONT, 9.0)
        self.pv = {}
        self.view_pages = {}
        for key, title in (("plan", u"Mặt bằng"), ("A", u"Mặt cắt A-A"), ("B", u"Mặt cắt B-B")):
            page = TabPage()
            page.Text = title
            pn = Panel()
            pn.Dock = DockStyle.Fill
            _dbl(pn)
            pn.Paint += (lambda k: (lambda s, e: self._paint(k, s, e)))(key)
            pn.Resize += (lambda s, e: s.Invalidate())
            page.Controls.Add(pn)
            self.views.TabPages.Add(page)
            self.pv[key] = pn
            self.view_pages[key] = page
        self._view_order = ["plan", "A", "B"]
        self.views.SelectedIndexChanged += lambda s, e: self._invalidate_views()
        self.split2.Panel1.Controls.Add(self.views)

        # ---- bang thep (phai duoi)
        ed = self.split2.Panel2
        self.tg = DataGridView()
        self.tg.Dock = DockStyle.Fill
        self.tg.AllowUserToAddRows = False
        self.tg.AllowUserToDeleteRows = False
        self.tg.RowHeadersVisible = False
        self.tg.MultiSelect = False
        self.tg.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        self.tg.AutoSizeColumnsMode = getattr(DataGridViewAutoSizeColumnsMode, "Fill")
        self.tg.BorderStyle = getattr(BorderStyle, "None")
        for name, head, kind, w in (("STT", u"STT", "t", 40), ("ViTri", u"Vị trí", "c", 170), ("D", u"Ø", "t", 50),
                                    ("A", u"a (mm)", "t", 60), ("SoThanh", u"Số thanh", "t", 70),
                                    ("LopBV", u"Lớp BV (0=mặc định)", "t", 110), ("GhiChu", u"Ghi chú", "t", 160)):
            col = DataGridViewComboBoxColumn() if kind == "c" else DataGridViewTextBoxColumn()
            col.Name = name
            col.HeaderText = head
            col.FillWeight = float(w)
            col.SortMode = DataGridViewColumnSortMode.NotSortable
            self.tg.Columns.Add(col)
        self.tg.CellValueChanged += self._on_tcell
        self.tg.CurrentCellDirtyStateChanged += self._on_tdirty
        self.tg.DataError += self._on_tdataerror
        self.tg.SelectionChanged += lambda s, e: self._invalidate_views()

        self.rules_panel = Panel()
        self.rules_panel.Dock = DockStyle.Bottom
        self.rules_panel.Height = 62
        self.rule_boxes = {}
        for n_, (key, lab) in enumerate(R.RULE_LABELS):
            x = 6 + (n_ % 4) * 150
            y = 5 + (n_ // 4) * 28
            self.rules_panel.Controls.Add(_label(lab, x, y + 3, 84, 20))
            tb = TextBox()
            tb.Location = Point(x + 84, y)
            tb.Size = Size(52, 24)
            tb.Text = u"%g" % self.rules[key]
            tb.TextChanged += self._on_rule
            self.rules_panel.Controls.Add(tb)
            self.rule_boxes[key] = tb

        btnrow = Panel()
        btnrow.Dock = DockStyle.Top
        btnrow.Height = 38
        self.btn_add = _button(u"Thêm thép", 6, 4, 88)
        self.btn_del = _button(u"Xóa dòng", 98, 4, 78)
        self.btn_def = _button(u"Mẫu mặc định", 180, 4, 102)
        self.btn_apply = _button(u"Áp dụng cùng loại", 286, 4, 134)
        self.btn_quick = _button(u"Tạo thép nhanh", 424, 4, 118)
        self.btn_beam_tc = _button(u"Chọn dầm (TC)", 546, 4, 112)
        for b in (self.btn_add, self.btn_del, self.btn_def, self.btn_apply, self.btn_quick, self.btn_beam_tc):
            btnrow.Controls.Add(b)
        self.btn_add.Click += self._on_add
        self.btn_del.Click += self._on_del
        self.btn_def.Click += self._on_default
        self.btn_apply.Click += self._on_apply
        self.btn_quick.Click += self._on_quick
        self.btn_beam_tc.Click += self._on_beam_tc

        self.lbl_stat = Label()
        self.lbl_stat.Dock = DockStyle.Top
        self.lbl_stat.Height = 92
        self.lbl_stat.Font = Font(FONT, 9.0)

        ed.Controls.Add(self.tg)
        ed.Controls.Add(self.rules_panel)
        ed.Controls.Add(btnrow)
        ed.Controls.Add(self.lbl_stat)

        f.Controls.Add(self.split)
        f.Controls.Add(bottom)
        f.Controls.Add(top)
        f.Load += self._on_load
        self._fill_all()
        self._apply_theme()
        self._select()

    # ---------------------------------------------------------------- quy dinh
    def _load_rules(self):
        for k in self.rules:
            v = self.info.get(u"QD " + k)
            if v not in (None, ""):
                self.rules[k] = M.to_float(v, self.rules[k])

    def _on_rule(self, s, e):
        for k, tb in self.rule_boxes.items():
            self.rules[k] = M.to_float(tb.Text, self.rules[k])
            self.info[u"QD " + k] = self.rules[k]
        if self.tloading or self.loading:
            return
        self._refresh_issues()
        self._update_stats()
        self._invalidate_views()

    # ---------------------------------------------------------------- tien ich chung
    def _on_load(self, s, e):
        try:
            self.split.SplitterDistance = int(self.f.ClientSize.Width * 0.38)
            self.split2.SplitterDistance = int(self.split2.Height * 0.66)
        except Exception:
            pass
        self._select_first()

    def _apply_theme(self):
        self.th = DARK if self.chk_dark.Checked else LIGHT
        apply_theme(self.f, self.th)
        self._color_rows()
        for pn in self.pv.values():
            pn.BackColor = self.th["pv_bg"]
        self._invalidate_views()

    def _on_theme(self, s, e):
        self._apply_theme()

    def _invalidate_views(self):
        for pn in self.pv.values():
            pn.Invalidate()

    def _cur_sheet(self):
        # Truoc khi form hien, TabControl chua co tab duoc chon (SelectedTab = None)
        t = self.tabs.SelectedTab
        if t is None:
            return "Tong"
        return t.Name

    def _find(self, sh, key, val):
        for r in self.data.get(sh, []):
            if r.get(key) == val:
                return r
        return None

    # ---------------------------------------------------------------- luoi du lieu chinh
    def _fill_all(self):
        self.loading = True
        for sh in M.ORDER:
            self._fill(sh)
        self.loading = False
        self._refresh_issues()
        self._build_tree()

    def _fill(self, sh):
        g = self.grids[sh]
        g.Columns.Clear()
        for c in M.cols(sh):
            t = M.ctype(sh, c)
            if t == "b":
                col = DataGridViewCheckBoxColumn()
                col.Width = 48
            else:
                col = DataGridViewTextBoxColumn()
                col.Width = 70 if t == "n" else 90
            col.Name = c
            col.HeaderText = M.LABELS.get(c, c)
            col.SortMode = DataGridViewColumnSortMode.NotSortable
            col.ReadOnly = c not in M.EDITABLE[sh]
            if c in ("Ten", "Nhom", "Type", "Family"):
                col.Width = 110
            if c == "CanhBao":
                col.Width = 300
            if c in M.HIDDEN:
                col.Visible = False
            g.Columns.Add(col)
        for r in self.data.get(sh, []):
            vals = []
            for c in M.cols(sh):
                t = M.ctype(sh, c)
                v = r.get(c)
                if t == "b":
                    vals.append(bool(M.to_flag(v)))
                elif t == "n":
                    vals.append(round(M.to_float(v), 1))
                else:
                    vals.append(u"" if v is None else u"%s" % v)
            g.Rows.Add(Array[Object](vals))

    def _collect(self):
        renames = {}
        for sh in M.ORDER:
            g = self.grids[sh]
            g.EndEdit()
            for i, r in enumerate(self.data.get(sh, [])):
                if i >= g.Rows.Count:
                    break
                row = g.Rows[i]
                for c in M.EDITABLE[sh]:
                    v = row.Cells[c].Value
                    t = M.ctype(sh, c)
                    if t == "b":
                        r[c] = 1 if (v is True or M.to_flag(v)) else 0
                    elif t == "n":
                        r[c] = M.to_float(v)
                    else:
                        nv = u"" if v is None else u"%s" % v
                        if c == "Ten" and nv != r.get(c):
                            renames[(sh, r.get(c))] = nv
                        r[c] = nv
        if renames:
            for c in self.data.get("Cot", []):
                k = (c.get("LoaiMong"), c.get("ThuocMong"))
                if k in renames:
                    c["ThuocMong"] = renames[k]
            for c in self.data.get("Coc", []):
                k = ("DaiMong", c.get("ThuocDai"))
                if k in renames:
                    c["ThuocDai"] = renames[k]
            for t in self.data.get("Thep", []):
                k = (t.get("Loai"), t.get("Ten"))
                if k in renames:
                    t["Ten"] = renames[k]
            if self.cur_key in renames:
                self.cur_key = (self.cur_key[0], renames[self.cur_key])

    def _refresh_issues(self):
        self.issues = M.run_checks(self.data) + R.check_all(self.data, self.rules)
        self.lst.Items.Clear()
        self.issue_refs = []
        for sh, i, label, m in self.issues:
            self.lst.Items.Add(u"[%s]  %s  -  %s" % (M.TITLES[sh], label, m))
            self.issue_refs.append((sh, i))
        counts = u"   |   ".join(u"%s: %d" % (M.TITLES[sh], len(self.data.get(sh, []))) for sh in M.ORDER)
        self.lbl_sum.Text = u"  %s      Cảnh báo: %d" % (counts, len(self.issues))
        was = self.loading
        self.loading = True
        for sh in M.ORDER:
            g = self.grids[sh]
            for i, r in enumerate(self.data.get(sh, [])):
                if i < g.Rows.Count:
                    g.Rows[i].Cells["CanhBao"].Value = r.get("CanhBao", u"")
        self.loading = was
        self._color_rows()

    def _color_rows(self):
        warn_rows = set((sh, i) for sh, i, _, _ in self.issues)
        for sh in M.ORDER:
            g = self.grids[sh]
            for i in range(min(len(self.data.get(sh, [])), g.Rows.Count)):
                st = g.Rows[i].DefaultCellStyle
                if (sh, i) in warn_rows:
                    st.BackColor = self.th["warn"]
                else:
                    st.BackColor = Color.Empty

    # ---------------------------------------------------------------- su kien chinh
    def _on_tab(self, s, e):
        if self._cur_sheet() != "Tong":
            self._select()

    def _on_sel(self, s, e):
        if self.loading:
            return
        try:
            sh = s.Parent.Name
        except Exception:
            sh = None
        if sh == self._cur_sheet():
            self._select()

    def _on_issue(self, s, e):
        k = self.lst.SelectedIndex
        if k < 0 or k >= len(self.issue_refs):
            return
        sh, i = self.issue_refs[k]
        for ti in range(self.tabs.TabPages.Count):
            if self.tabs.TabPages[ti].Name == sh:
                self.tabs.SelectedIndex = ti
        g = self.grids[sh]
        if i < g.Rows.Count:
            g.ClearSelection()
            g.Rows[i].Selected = True
            try:
                g.CurrentCell = g.Rows[i].Cells["Chon"]
            except Exception:
                pass

    def _on_check(self, s, e):
        self._collect()
        self._refresh_issues()
        self._update_stats()
        self._invalidate_views()

    def _on_save(self, s, e):
        self._collect()
        self._thep_commit()
        self._refresh_issues()
        try:
            M.save_model(self.path, self.data, self.info)
            msg(u"Đã lưu: %s" % self.path)
        except Exception as ex:
            msg(u"Không lưu được file (đang mở trong Excel?)\n%s" % ex, icon=MessageBoxIcon.Error)

    def _on_open(self, s, e):
        if os.path.exists(self.path):
            os.startfile(self.path)
        else:
            msg(u"Chưa có file, hãy bấm Lưu Excel trước.", icon=MessageBoxIcon.Warning)

    def _on_reload(self, s, e):
        if not os.path.exists(self.path):
            msg(u"Không thấy file: %s" % self.path, icon=MessageBoxIcon.Warning)
            return
        try:
            self.data, self.info = M.load_model(self.path)
        except Exception as ex:
            msg(u"Không đọc được file Excel:\n%s" % ex, icon=MessageBoxIcon.Error)
            return
        self.data.setdefault("Thep", [])
        self._load_rules()
        for k, tb in self.rule_boxes.items():
            tb.Text = u"%g" % self.rules[k]
        self.cur_key = None
        self._fill_all()
        self._apply_theme()
        self._select_first()

    # ---------------------------------------------------------------- chon mong dang xem
    def _find_id(self, sh, eid, name_key=None, name=None):
        for r in self.data.get(sh, []):
            if eid and r.get("ElementId") == eid:
                return r
        if name_key:
            return self._find(sh, name_key, name)
        return None

    def _resolve(self, sh, r):
        rec, key, hl = None, None, None
        if sh in ("MongDon", "DaiMong"):
            rec, key = r, (sh, r.get("Ten"))
        elif sh == "MongBang":
            rec, key, hl = r, ("MongBang", r.get("Nhom")), r
        elif sh == "DamMong":
            rec, key, hl = r, ("DamMong", r.get("Ten")), r
        elif sh == "Coc":
            dai = self._find_id("DaiMong", r.get("ThuocId"), "Ten", r.get("ThuocDai"))
            if dai is not None:
                rec, key, hl = dai, ("DaiMong", dai.get("Ten")), r
        elif sh == "Cot":
            loai, ten = r.get("LoaiMong"), r.get("ThuocMong")
            if loai in ("MongDon", "DaiMong"):
                rec = self._find_id(loai, r.get("ThuocId"), "Ten", ten)
                key = (loai, rec.get("Ten")) if rec is not None else None
            elif loai == "MongBang":
                rec = self._find_id("MongBang", r.get("ThuocId"), "Nhom", ten)
                key = ("MongBang", rec.get("Nhom")) if rec is not None else None
            elif loai == "DamMong":
                rec = self._find_id("DamMong", r.get("ThuocId"), "Ten", ten)
                key = ("DamMong", rec.get("Ten")) if rec is not None else None
            hl = r
        return rec, key, hl

    def _cols_of(self, loai, rec):
        """Cot thuoc dung cau kien dang xem (mong don / dai / dam: theo Id; mong bang: theo nhom Mark)."""
        out = []
        for c in self.data.get("Cot", []):
            if c.get("LoaiMong") != loai:
                continue
            if loai == "MongBang":
                if c.get("ThuocMong") == rec.get("Nhom"):
                    out.append(c)
            elif c.get("ThuocId"):
                if c.get("ThuocId") == rec.get("ElementId"):
                    out.append(c)
            elif c.get("ThuocMong") == rec.get("Ten"):
                out.append(c)
        return out

    def _piles_of(self, rec):
        out = []
        for p in self.data.get("Coc", []):
            if p.get("ThuocId"):
                if p.get("ThuocId") == rec.get("ElementId"):
                    out.append(p)
            elif p.get("ThuocDai") == rec.get("Ten"):
                out.append(p)
        return out

    def _select(self):
        sh = self._cur_sheet()
        if sh not in self.grids:
            return
        g = self.grids[sh]
        idx = g.CurrentRow.Index if g.CurrentRow is not None else -1
        recs = self.data.get(sh, [])
        rec = key = hl = None
        if 0 <= idx < len(recs):
            rec, key, hl = self._resolve(sh, recs[idx])
        self._set_current(sh, rec, key, hl)

    def _set_current(self, sh, rec, key, hl):
        self.cur_sheet, self.cur_rec, self.hl = sh, rec, hl
        if key != self.cur_key:
            self.cur_key = key
            self._load_thep()
        self._update_view_titles()
        self._update_stats()
        self._invalidate_views()

    def _update_view_titles(self):
        pages = getattr(self, "view_pages", None)
        if not pages:
            return
        loai = self.cur_key[0] if self.cur_key else "MongDon"
        if self._is_strip(loai):          # mong bang / dam mong: khong co mat bang, trinh bay nhu ban ve trien khai dam
            order = ["B", "A"]
            t = {"B": u"Mặt cắt dọc", "A": u"Các mặt cắt ngang"}
        else:
            order = ["plan", "A", "B"]
            t = {"plan": u"Mặt bằng", "A": u"Mặt cắt A-A", "B": u"Mặt cắt B-B"}
        for k in order:
            if pages[k].Text != t[k]:
                pages[k].Text = t[k]
        if getattr(self, "_view_order", None) != order:
            self.views.TabPages.Clear()
            for k in order:
                self.views.TabPages.Add(pages[k])
            self._view_order = order

    def _is_strip(self, loai):
        return loai in R.STRIP_LOAI

    def _chain_of(self, rec):
        """Dam mong: gop cac doan cung Mark noi tiep nhau thanh 1 dam. Tra ve (chain, diem dau, diem cuoi)."""
        return R.chain_segments(self._segments("DamMong", rec.get("Ten")), rec)

    def _goi_ids(self, chain):
        ids = []
        for s_ in chain:
            for x in (u"%s" % (s_.get("GoiId") or u"")).split(";"):
                if x and x not in ids:
                    ids.append(x)
        return ids

    def _support_footings(self, chain):
        out = []
        for gid in self._goi_ids(chain):
            f = None
            for shn in ("MongDon", "DaiMong"):
                f = f or self._find_id(shn, gid)
            if f is not None and all(f is not o for o in out):
                out.append(f)
        return out

    def _beams_of(self, rec):
        """Cac dam mong gac vao dai / mong don dang xem."""
        eid = rec.get("ElementId")
        return [b for b in self.data.get("DamMong", []) if eid and eid in (u"%s" % (b.get("GoiId") or u"")).split(";")]

    def _cols_all(self, loai, rec, segs=None):
        if loai == "DamMong" and segs:
            out = []
            for s_ in segs:
                out.extend(self._cols_of(loai, s_))
            return out
        return self._cols_of(loai, rec)

    def _foot_cut_pos(self, loai, rec, fr, ci):
        """Vi tri mat cat mong don / dai theo truc ci (0: u, 1: v): qua hang coc dau, hoac tam cot dau, hoac tam mong."""
        if loai == "DaiMong":
            vals = sorted(R.to_local(fr, (M.to_float(p.get("X")), M.to_float(p.get("Y"))))[ci] for p in self._piles_of(rec))
            if vals:
                return vals[0], u"qua hàng cọc"
        for c in self._cols_of(loai, rec):
            cp = self._poly(c)
            if cp:
                q = [R.to_local(fr, p) for p in cp]
                return (min(p[ci] for p in q) + max(p[ci] for p in q)) / 2.0, u"qua tâm cột"
        return 0.0, u"qua tâm móng"

    def _draw_cut(self, g, cv, fr, a, b, dloc, label):
        """Net cat mat cat tren mat bang: gach cham, chu o hai dau, mui ten chi huong nhin (dloc: huong nhin trong he u,v)."""
        th = self.th
        pa, pb = cv.T(R.to_global(fr, a)), cv.T(R.to_global(fr, b))
        pen = Pen(th["hl"], 1.6)
        pen.DashStyle = DashStyle.DashDot
        g.DrawLine(pen, pa, pb)
        solid = Pen(th["hl"], 2.4)
        bold = Font(FONT, 10.0, FontStyle.Bold)
        brush = SolidBrush(th["hl"])
        for loc, P_, Q_ in ((a, pa, pb), (b, pb, pa)):
            ox, oy = P_.X - Q_.X, P_.Y - Q_.Y
            ol = math.hypot(ox, oy) or 1.0
            ox, oy = ox / ol, oy / ol
            tip = cv.T(R.to_global(fr, (loc[0] + dloc[0] * 100.0, loc[1] + dloc[1] * 100.0)))
            sx, sy = tip.X - P_.X, tip.Y - P_.Y
            sl = math.hypot(sx, sy) or 1.0
            sx, sy = sx / sl, sy / sl
            ex, ey = P_.X + sx * 20.0, P_.Y + sy * 20.0
            g.DrawLine(solid, float(P_.X), float(P_.Y), float(ex), float(ey))
            g.DrawLine(solid, float(ex), float(ey), float(ex - sx * 7 + sy * 4), float(ey - sy * 7 - sx * 4))
            g.DrawLine(solid, float(ex), float(ey), float(ex - sx * 7 - sy * 4), float(ey - sy * 7 + sx * 4))
            g.DrawString(label, bold, brush, float(P_.X + ox * 16 - 6), float(P_.Y + oy * 16 - 9))

    def _rect(self, g, cv, x0, z0, x1, z1, fill=None, pen=None):
        p0, p1 = cv.T((x0, z1)), cv.T((x1, z0))
        if fill is not None:
            g.FillRectangle(SolidBrush(fill), float(p0.X), float(p0.Y), float(p1.X - p0.X), float(p1.Y - p0.Y))
        if pen is not None:
            g.DrawRectangle(pen, float(p0.X), float(p0.Y), float(p1.X - p0.X), float(p1.Y - p0.Y))

    def _lean(self):
        return max(self.rules.get("lot_t", 100.0), 0.0), max(self.rules.get("lot_o", 100.0), 0.0)

    def _segments(self, loai, ten):
        if loai == "MongBang":
            return [x for x in self.data.get("MongBang", []) if x.get("Nhom") == ten]
        return [x for x in self.data.get("DamMong", []) if x.get("Ten") == ten]

    # ---------------------------------------------------------------- cay tong hop
    SECTIONS = [("MongDon", u"Móng đơn"), ("DaiMong", u"Đài cọc"), ("MongBang", u"Móng băng"),
                ("DamMong", u"Dầm móng"), ("Coc", u"Cọc")]

    def _thep_key(self, sh, r):
        return r.get("Nhom") if sh == "MongBang" else r.get("Ten")

    def _flag(self, sh, r):
        return u"có thép" if R.rows_for(self.data, sh, self._thep_key(sh, r)) else u"chưa có thép"

    def _gkey(self, sh, r):
        if sh in ("MongDon", "DaiMong", "DamMong"):
            return (r.get("Ten"),)
        if sh == "MongBang":
            return (r.get("Nhom"),)
        n = lambda k: int(round(M.to_float(r.get(k))))
        return (r.get("Family"), r.get("Type"), n("D"), n("Dai"), r.get("HinhDang"))

    def _gtext(self, sh, k, idxs):
        recs = self.data.get(sh, [])
        n = len(idxs)
        sub = [recs[i] for i in idxs]
        r0 = sub[0]
        if sh in ("MongDon", "DaiMong"):
            sizes = set(M.fsig(sh, x) for x in sub)
            sz = u"%.0f×%.0f×%.0f" % (M.to_float(r0.get("B")), M.to_float(r0.get("L")), M.to_float(r0.get("H")))
            if len(sizes) > 1:
                sz += u" (nhiều kích thước!)"
            extra = (u"   %d cọc" % M.to_float(r0.get("SoCoc"))) if sh == "DaiMong" else u""
            has = u"có thép" if R.rows_for(self.data, sh, k[0]) else u"chưa có thép"
            return u"%s   —   %d cấu kiện   %s%s   [%s / %s]   ·  %s" % (k[0], n, sz, extra, r0.get("Family"), r0.get("Type"), has)
        if sh == "MongBang":
            tot = sum(M.to_float(x.get("Dai")) for x in sub) / 1000.0
            has = u"có thép" if R.rows_for(self.data, sh, k[0]) else u"chưa có thép"
            return u"%s   —   %d đoạn   dài %.1f m   B %.0f   ·  %s" % (k[0], n, tot, M.to_float(r0.get("B")), has)
        if sh == "DamMong":
            tot = sum(M.to_float(x.get("Dai")) for x in sub) / 1000.0
            has = u"có thép" if R.rows_for(self.data, sh, k[0]) else u"chưa có thép"
            return u"%s   —   %d dầm   B %.0f  H %.0f   dài %.1f m   ·  %s" % (k[0], n, M.to_float(r0.get("B")), M.to_float(r0.get("H")), tot, has)
        return u"%s / %s   Ø/cạnh %d   dài %d   %s   —   %d cọc" % (k[0], k[1], k[2], k[3], k[4], n)

    def _leaf_text(self, sh, r):
        if sh in ("MongDon", "DaiMong"):
            extra = u"   %d cột" % M.to_float(r.get("SoCot"))
            if sh == "DaiMong":
                extra += u"   %d cọc" % M.to_float(r.get("SoCoc"))
            return u"Id %s   [%s]%s" % (r.get("ElementId"), r.get("Level"), extra)
        if sh == "MongBang":
            return u"đoạn Id %s   dài %.0f   B %.0f   H %.0f" % (r.get("ElementId"), M.to_float(r.get("Dai")),
                                                           M.to_float(r.get("B")), M.to_float(r.get("H")))
        gc = (u"   cột: %s" % r.get("GoiCot")) if r.get("GoiCot") else u""
        return u"Id %s   gối: %s%s   dài %.0f" % (r.get("ElementId"), r.get("NoiDai") or u"(chưa có)", gc, M.to_float(r.get("Dai")))

    def _build_tree(self):
        self.tree.BeginUpdate()
        self.tree.Nodes.Clear()
        self.leaf_nodes = []
        self.groups = {}
        self.gorder = {}
        for sh, title in self.SECTIONS:
            recs = self.data.get(sh, [])
            order, grp = [], {}
            for i, r in enumerate(recs):
                k = self._gkey(sh, r)
                if k not in grp:
                    grp[k] = []
                    order.append(k)
                grp[k].append(i)
            if sh != "Coc":
                order.sort(key=lambda k: M.nat_key(k[0]))
            self.gorder[sh] = order
            if sh == "Coc":
                head = u"%s  (%d)" % (title, len(recs))
            elif sh == "MongBang":
                head = u"%s  (%d Mark/nhóm, %d đoạn)" % (title, len(order), len(recs))
            else:
                head = u"%s  (%d cấu kiện, %d Mark)" % (title, len(recs), len(order))
            root = TreeNode(head)
            root.Tag = u"R|" + sh
            for gi, k in enumerate(order):
                idxs = grp[k]
                self.groups[(sh, gi)] = idxs
                gn = TreeNode(self._gtext(sh, k, idxs))
                gn.Tag = u"G|%s|%d" % (sh, gi)
                if sh != "Coc":
                    for i in idxs:
                        ln = TreeNode(self._leaf_text(sh, recs[i]))
                        ln.Tag = u"L|%s|%d" % (sh, i)
                        gn.Nodes.Add(ln)
                        self.leaf_nodes.append((ln, sh, i))
                root.Nodes.Add(gn)
            self.tree.Nodes.Add(root)
            root.Expand()
        self.tree.EndUpdate()
        self._update_totals()

    def _refresh_leaf_texts(self):
        for node, sh, i in self.leaf_nodes:
            recs = self.data.get(sh, [])
            if i < len(recs):
                t = self._leaf_text(sh, recs[i])
                if node.Text != t:
                    node.Text = t
                p = node.Parent
                if p is not None and p.Tag:
                    parts = u"%s" % p.Tag
                    parts = parts.split("|")
                    if len(parts) == 3 and parts[0] == "G":
                        idxs = self.groups.get((sh, int(parts[2])), [])
                        if idxs:
                            gt = self._gtext(sh, self._gkey(sh, recs[idxs[0]]), idxs)
                            if p.Text != gt:
                                p.Text = gt

    def _update_totals(self):
        d = self.data
        names = lambda sh, key: set(r.get(key) for r in d.get(sh, []))
        line1 = (u"  Móng đơn: %d (%d Mark)   |   Đài cọc: %d (%d Mark)   |   Cọc: %d   |   Móng băng: %d đoạn (%d Mark/nhóm)"
                 u"   |   Dầm móng: %d (%d Mark)   |   Cột: %d") % (
            len(d.get("MongDon", [])), len(names("MongDon", "Ten")), len(d.get("DaiMong", [])), len(names("DaiMong", "Ten")),
            len(d.get("Coc", [])), len(d.get("MongBang", [])), len(names("MongBang", "Nhom")),
            len(d.get("DamMong", [])), len(names("DamMong", "Ten")), len(d.get("Cot", [])))
        kg = 0.0
        missing = set()
        for sh in ("MongDon", "DaiMong"):
            for r in d.get(sh, []):
                rows = R.rows_for(d, sh, r.get("Ten"))
                if not rows:
                    missing.add((sh, r.get("Ten")))
                    continue
                kg += R.footing_stats(R.frame_footing(r), rows, self.rules, M.to_float(r.get("H")))[1]
        for r in d.get("MongBang", []):
            rows = R.rows_for(d, "MongBang", r.get("Nhom"))
            if not rows:
                missing.add(("MongBang", r.get("Nhom")))
                continue
            kg += R.strip_stats(r, rows, self.rules)[1]
        for r in d.get("DamMong", []):
            rows = R.rows_for(d, "DamMong", r.get("Ten"))
            if not rows:
                missing.add(("DamMong", r.get("Ten")))
                continue
            kg += R.strip_stats(r, rows, self.rules)[1]
        self.lbl_tot.Text = line1 + u"\n  Thép đã nhập (tính cho mọi cấu kiện): %.1f kg   |   Mark chưa nhập thép: %d" % (kg, len(missing))

    def _select_first(self):
        try:
            if self.leaf_nodes:
                node = self.leaf_nodes[0][0]
                node.Parent.Expand()
                self.tree.SelectedNode = node
                node.EnsureVisible()
            elif self.tree.Nodes.Count:
                self.tree.SelectedNode = self.tree.Nodes[0]
        except Exception:
            pass

    def _on_tree(self, s, e):
        node = e.Node
        tag = u"%s" % (node.Tag or u"")
        parts = tag.split("|")
        if len(parts) < 2:
            return
        kind, sh = parts[0], parts[1]
        recs = self.data.get(sh, [])
        i = None
        if kind == "L":
            i = int(parts[2])
        elif kind == "G":
            idxs = self.groups.get((sh, int(parts[2])), [])
            i = idxs[0] if idxs else None
        if i is not None and i < len(recs):
            rec, key, hl = self._resolve(sh, recs[i])
            self._set_current(sh, rec, key, hl)
            g = self.grids.get(sh)
            if g is not None and i < g.Rows.Count:
                was = self.loading
                self.loading = True
                try:
                    g.ClearSelection()
                    g.Rows[i].Selected = True
                    g.CurrentCell = g.Rows[i].Cells["Chon"]
                except Exception:
                    pass
                self.loading = was
        if kind == "L":
            self.detail.Text = self._detail_leaf(sh, recs[i])
        elif kind == "G":
            self.detail.Text = self._detail_group(sh, int(parts[2]))
        else:
            self.detail.Text = self._detail_root(sh)

    def _detail_root(self, sh):
        title = dict(self.SECTIONS)[sh]
        recs = self.data.get(sh, [])
        lines = [u"%s: %d cấu kiện" % (title, len(recs))]
        if not recs:
            if sh == "DaiMong":
                lines += [u"", u"Chưa có đài cọc nào. Đài được nhận khi:",
                          u"  - có cọc nằm trong biên móng (chọn đúng family cọc ở mục 2 khi quét), hoặc",
                          u"  - móng thuộc family được tick ở mục 2b (Family là ĐÀI CỌC).",
                          u"Quét lại và kiểm tra 2 mục này; xem 'Lưu ý khi quét' để biết đã tìm thấy bao nhiêu cọc."]
            return u"\r\n".join(lines)
        order = self.gorder.get(sh, [])
        lines.append(u"Số Mark / loại: %d" % len(order))
        lines.append(u"")
        for gi, k in enumerate(order):
            idxs = self.groups.get((sh, gi), [])
            if idxs:
                lines.append(u"  - " + self._gtext(sh, k, idxs))
        return u"\r\n".join(lines)

    def _detail_group(self, sh, gi):
        idxs = self.groups.get((sh, gi), [])
        recs = self.data.get(sh, [])
        lines = []
        if idxs:
            lines.append(self._gtext(sh, self._gkey(sh, recs[idxs[0]]), idxs))
        names = []
        for i in idxs:
            r = recs[i]
            names.append(u"Id %s" % r.get("ElementId"))
        lines.append(u"")
        lines.append(u"Danh sách (%d): " % len(names) + u", ".join(names[:80]) + (u" ..." if len(names) > 80 else u""))
        return u"\r\n".join(lines)

    def _detail_leaf(self, sh, r):
        f = lambda k: M.to_float(r.get(k))
        L = []
        if sh in ("MongDon", "DaiMong"):
            ten = r.get("Ten")
            L.append(u"Mark %s  -  %s     (cấu kiện này Id %s; cùng Mark: %d cấu kiện)" % (
                ten, M.TITLES[sh], r.get("ElementId"), len([x for x in self.data.get(sh, []) if x.get("Ten") == ten])))
            L.append(u"Level: %s     Family / Type: %s / %s     Mark: %s     ElementId: %s" % (
                r.get("Level"), r.get("Family"), r.get("Type"), r.get("Mark") or u"-", r.get("ElementId")))
            L.append(u"Kích thước: B %.0f  x  L %.0f  x  H %.0f mm     góc %.1f°" % (f("B"), f("L"), f("H"), f("Goc")))
            L.append(u"Cao độ: đáy %.0f   đỉnh %.0f   (theo Project Base Point)     tâm (%.0f, %.0f)" % (
                f("ZDay"), f("ZDinh"), f("TamX"), f("TamY")))
            cots = self._cols_of(sh, r)
            L.append(u"Cột (%d): " % len(cots) + u";  ".join(u"%s %.0fx%.0f" % (c.get("Mark") or c.get("ElementId"),
                     M.to_float(c.get("B")), M.to_float(c.get("H"))) for c in cots))
            if sh == "DaiMong":
                piles = self._piles_of(r)
                if piles:
                    best = None
                    for a in range(len(piles)):
                        for b in range(a + 1, len(piles)):
                            dd = math.hypot(M.to_float(piles[a].get("X")) - M.to_float(piles[b].get("X")),
                                            M.to_float(piles[a].get("Y")) - M.to_float(piles[b].get("Y")))
                            best = dd if best is None or dd < best else best
                    L.append(u"Cọc (%d): %s Ø/cạnh %.0f, dài %.0f     tim cọc gần nhất %s" % (
                        len(piles), piles[0].get("HinhDang"), M.to_float(piles[0].get("D")),
                        M.to_float(piles[0].get("Dai")), (u"%.0f" % best) if best is not None else u"-"))
            rows = R.rows_for(self.data, sh, ten)
            if rows:
                st, tot = R.footing_stats(R.frame_footing(r), rows, self.rules, M.to_float(r.get("H")))
                L.append(u"Thép (tổng %.1f kg):" % tot)
                for lab, n, ln, kg in st:
                    L.append(u"     %s   %d thanh   %.1f m   %.1f kg" % (lab, n, ln, kg))
            else:
                L.append(u"Thép: chưa nhập")
        else:
            seg_name = r.get("Nhom") if sh == "MongBang" else r.get("Ten")
            L.append(u"%s  -  %s" % (seg_name, M.TITLES[sh]))
            L.append(u"Level: %s     Type: %s     Mark: %s     ElementId: %s" % (
                r.get("Level"), r.get("Type"), r.get("Mark") or u"-", r.get("ElementId")))
            L.append(u"Kích thước: dài %.0f   B %.0f   H %.0f mm     lệch tâm %.0f" % (f("Dai"), f("B"), f("H"), (0.0 if abs(f("LechTam")) < 0.5 else f("LechTam"))))
            L.append(u"Cao độ: đáy %.0f   đỉnh %.0f     (%.0f, %.0f) -> (%.0f, %.0f)" % (
                f("ZDay"), f("ZDinh"), f("X1"), f("Y1"), f("X2"), f("Y2")))
            if sh == "DamMong":
                L.append(u"Gối đài/móng (%d): %s" % (M.to_float(r.get("SoGoi")), r.get("NoiDai") or u"-"))
                L.append(u"Cột cấy trên dầm (%d): %s" % (M.to_float(r.get("SoCot")), r.get("GoiCot") or u"-"))
            else:
                L.append(u"Nhóm %s gồm %d đoạn" % (r.get("Nhom"), len(self._segments(sh, r.get("Nhom")))))
            rows = R.rows_for(self.data, sh, seg_name)
            if rows:
                st, tot = R.strip_stats(r, rows, self.rules)
                L.append(u"Thép đoạn này (tổng %.1f kg):" % tot)
                for lab, n, ln, kg in st:
                    L.append(u"     %s   %d   %.1f m   %.1f kg" % (lab, n, ln, kg))
            else:
                L.append(u"Thép: chưa nhập")
        if r.get("CanhBao"):
            L.append(u"")
            L.append(u"Cảnh báo: %s" % r.get("CanhBao"))
        return u"\r\n".join(L)

    # ---------------------------------------------------------------- bang thep
    def _load_thep(self):
        self.tloading = True
        g = self.tg
        g.Rows.Clear()
        col = g.Columns["ViTri"]
        col.Items.Clear()
        loai = self.cur_key[0] if self.cur_key else "MongDon"
        for c, l in R.vitri_list(loai):
            col.Items.Add(l)
        if self.cur_key:
            for r in sorted(R.rows_for(self.data, *self.cur_key), key=lambda r: M.to_float(r.get("STT"))):
                g.Rows.Add(Array[Object]([u"%g" % M.to_float(r.get("STT")), R.label_of(r.get("ViTri")),
                                          u"%g" % M.to_float(r.get("D")), u"%g" % M.to_float(r.get("A")),
                                          u"%g" % M.to_float(r.get("SoThanh")), u"%g" % M.to_float(r.get("LopBV")),
                                          r.get("GhiChu") or u""]))
        self.tloading = False

    def _on_tdataerror(self, s, e):
        e.ThrowException = False

    def _on_tdirty(self, s, e):
        try:
            if self.tg.IsCurrentCellDirty:
                self.tg.CommitEdit(DataGridViewDataErrorContexts.Commit)
        except Exception:
            pass

    def _on_tcell(self, s, e):
        if not self.tloading:
            self._thep_commit()
            self._refresh_issues()
            self._update_stats()
            self._refresh_leaf_texts()
            self._update_totals()
            self._invalidate_views()

    def _thep_rows(self):
        out = []
        loai = self.cur_key[0]
        ten = self.cur_key[1]
        for row in self.tg.Rows:
            def val(n):
                v = row.Cells[n].Value
                return v
            vt = val("ViTri")
            out.append(R.new_row(loai, ten, R.code_of(u"%s" % vt) if vt else "", M.to_float(val("D")),
                                 M.to_float(val("A")), M.to_float(val("SoThanh")), M.to_float(val("LopBV")),
                                 M.to_float(val("STT")), u"" if val("GhiChu") is None else u"%s" % val("GhiChu")))
        return out

    def _thep_commit(self):
        if not self.cur_key:
            return
        try:
            self.tg.EndEdit()
        except Exception:
            pass
        R.set_rows(self.data, self.cur_key[0], self.cur_key[1], self._thep_rows())

    def _on_add(self, s, e):
        if not self.cur_key:
            return
        self._thep_commit()
        rows = R.rows_for(self.data, *self.cur_key)
        used = set(r.get("ViTri") for r in rows)
        choices = [c for c, _ in R.vitri_list(self.cur_key[0])]
        vt = next((c for c in choices if c not in used), choices[0])
        stt = int(max([M.to_float(r.get("STT")) for r in rows] + [0])) + 1
        strip = self._is_strip(self.cur_key[0])
        rows.append(R.new_row(self.cur_key[0], self.cur_key[1], vt, 16 if strip else 14,
                              200 if (vt == "BangDai" or not strip) else 0, 3 if (strip and vt != "BangDai") else 0, stt=stt))
        R.set_rows(self.data, self.cur_key[0], self.cur_key[1], rows)
        self._load_thep()
        self._after_thep()

    def _on_del(self, s, e):
        if not self.cur_key or self.tg.CurrentRow is None:
            return
        self._thep_commit()
        i = self.tg.CurrentRow.Index
        rows = sorted(R.rows_for(self.data, *self.cur_key), key=lambda r: M.to_float(r.get("STT")))
        if 0 <= i < len(rows):
            rows.pop(i)
            R.set_rows(self.data, self.cur_key[0], self.cur_key[1], rows)
            self._load_thep()
            self._after_thep()

    def _on_default(self, s, e):
        if not self.cur_key:
            return
        if R.rows_for(self.data, *self.cur_key) and not ask_yes_no(u"Thay toàn bộ thép hiện có bằng mẫu mặc định?"):
            return
        R.set_rows(self.data, self.cur_key[0], self.cur_key[1], R.default_rows(*self.cur_key))
        self._load_thep()
        self._after_thep()

    def _on_quick(self, s, e):
        self._thep_commit()
        dlg = QuickRebarDialog(self.quick_cfg, dark=self.dark)
        res = dlg.show()
        if not res:
            return
        self.quick_cfg = res["cfg"]
        scope = res["scope"]
        filters = {
            0: (True, None),
            1: (False, None),
            2: (True, ("MongDon",)),
            3: (True, ("DaiMong",)),
            4: (True, ("MongBang",)),
            5: (True, ("DamMong",)),
        }
        overwrite, loai_filter = filters.get(scope, (True, None))
        n = R.apply_quick_all(self.data, self.quick_cfg, overwrite=overwrite, loai_filter=loai_filter)
        self._load_thep()
        self._after_thep()
        msg(u"Đã tạo thép nhanh cho %d Mark cấu kiện." % n)

    def _on_beam_tc(self, s, e):
        self._thep_commit()
        items = []
        for sh in ("MongBang", "DamMong"):
            key = "Nhom" if sh == "MongBang" else "Ten"
            seen = {}
            for r in self.data.get(sh, []):
                nm = r.get(key)
                if nm not in seen:
                    seen[nm] = r
            for nm in sorted(seen.keys(), key=M.nat_key):
                r = seen[nm]
                desc = u"[%s]  %s   (B %.0f × H %.0f mm)" % (M.TITLES[sh], nm, M.to_float(r.get("B")), M.to_float(r.get("H")))
                items.append((sh, nm, desc))
        if not items:
            msg(u"Chưa có Móng băng hoặc Dầm móng nào.", icon=MessageBoxIcon.Information)
            return
        dlg = BeamReinforceDialog(items, R.REINFORCE_MODES, self.quick_cfg, dark=self.dark)
        res = dlg.show()
        if not res:
            return
        self.quick_cfg = res["cfg"]
        n = R.apply_beams_mode(self.data, res["items"], self.quick_cfg, mode=res["mode"])
        self._load_thep()
        self._after_thep()
        msg(u"Đã áp dụng chế độ tăng cường cho %d dầm / móng băng." % n)

    def _after_thep(self):
        self._refresh_issues()
        self._update_stats()
        self._refresh_leaf_texts()
        self._update_totals()
        self._invalidate_views()

    def _signature(self, loai, rec):
        if self._is_strip(loai):
            return M.ssig(rec)
        return M.fsig(loai, rec)

    def _on_apply(self, s, e):
        if not self.cur_key or self.cur_rec is None:
            return
        self._thep_commit()
        loai, ten = self.cur_key
        rows = R.rows_for(self.data, loai, ten)
        if not rows:
            msg(u"Móng này chưa có thép để áp dụng.", icon=MessageBoxIcon.Warning)
            return
        sig = self._signature(loai, self.cur_rec)
        targets = []
        if loai == "MongBang":
            groups = {}
            for sgm in self.data.get("MongBang", []):
                groups.setdefault(sgm.get("Nhom"), set()).add(self._signature(loai, sgm))
            targets = [g for g, sset in groups.items() if g != ten and sset == set([sig])]
        elif loai == "DamMong":
            targets = sorted(set(r.get("Ten") for r in self.data.get("DamMong", [])
                                 if r.get("Ten") != ten and self._signature(loai, r) == sig), key=M.nat_key)
        else:
            targets = sorted(set(r.get("Ten") for r in self.data.get(loai, [])
                                 if r.get("Ten") != ten and self._signature(loai, r) == sig), key=M.nat_key)
        if not targets:
            msg(u"Không có móng nào cùng loại (cùng Family/Type và kích thước).")
            return
        if not ask_yes_no(u"Chép thép sang %d Mark cùng loại (ghi đè thép của chúng)?" % len(targets)):
            return
        for t in targets:
            cp = [R.new_row(loai, t, r.get("ViTri"), r.get("D"), r.get("A"), r.get("SoThanh"),
                            r.get("LopBV"), r.get("STT"), r.get("GhiChu")) for r in rows]
            R.set_rows(self.data, loai, t, cp)
        self._after_thep()
        msg(u"Đã chép thép sang %d Mark." % len(targets))

    # ---------------------------------------------------------------- thong ke
    def _update_stats(self):
        if not self.cur_key or self.cur_rec is None:
            self.lbl_stat.Text = u"  Chọn một móng (hoặc cột / cọc của móng) trong bảng bên trái."
            return
        loai, ten = self.cur_key
        rec = self.cur_rec
        rows = R.rows_for(self.data, loai, ten)
        lines = []
        if self._is_strip(loai):
            st, tot = R.strip_stats(rec, rows, self.rules)
            gtot = 0.0
            for sgm in self._segments(loai, ten):
                gtot += R.strip_stats(sgm, rows, self.rules)[1]
            head = u"  %s   đoạn: dài %.0f  B %.0f  H %.0f  lệch tâm %.0f   |   thép đoạn này %.1f kg   cả nhóm %.1f kg" % (
                ten, M.to_float(rec.get("Dai")), M.to_float(rec.get("B")), M.to_float(rec.get("H")),
                (0.0 if abs(M.to_float(rec.get("LechTam"))) < 0.5 else M.to_float(rec.get("LechTam"))), tot, gtot)
        else:
            fr = R.frame_footing(rec)
            st, tot = R.footing_stats(fr, rows, self.rules, M.to_float(rec.get("H")))
            head = u"  %s   %.0f x %.0f x %.0f   |   Z đáy %.0f   Z đỉnh %.0f   góc %.1f°   |   tổng thép %.1f kg" % (
                ten, M.to_float(rec.get("B")), M.to_float(rec.get("L")), M.to_float(rec.get("H")),
                M.to_float(rec.get("ZDay")), M.to_float(rec.get("ZDinh")), M.to_float(rec.get("Goc")), tot)
        lines.append(head)
        for lab, n, L, kg in st:
            lines.append(u"      %s   %d thanh   %.1f m   %.1f kg" % (lab, n, L, kg))
        if not st:
            lines.append(u"      (chưa có thép)")
        self.lbl_stat.Text = u"\n".join(lines[:6])

    # ---------------------------------------------------------------- ve
    def _paint(self, key, panel, e):
        g = e.Graphics
        th = self.th
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.Clear(th["pv_bg"])
        font = Font(FONT, 9.0, FontStyle.Bold)
        try:
            if self.cur_rec is None or not self.cur_key:
                g.DrawString(u"Chọn một móng trong bảng bên trái", font, SolidBrush(th["dim"]), 14.0, 12.0)
                return
            loai = self.cur_key[0]
            if key == "plan":
                self._draw_plan(g, panel, loai)
            elif self._is_strip(loai):
                if key == "A":
                    self._draw_strip_sections(g, panel)
                else:
                    self._draw_strip_long(g, panel)
            else:
                self._draw_foot_section(g, panel, key)
        except Exception as ex:
            g.DrawString(u"Lỗi vẽ: %s" % ex, font, SolidBrush(th["col"]), 14.0, 12.0)

    def _poly(self, r):
        return M.str_to_poly(r.get("BienDang"))

    def _pen(self, color, w=1.5, dash=False):
        p = Pen(color, float(w))
        if dash:
            p.DashStyle = DashStyle.Dash
        return p

    def _poly_arr(self, cv, pts):
        return Array[PointF]([cv.T(p) for p in pts])

    def _draw_plan(self, g, panel, loai):
        th = self.th
        W, H = panel.ClientSize.Width, panel.ClientSize.Height
        font = Font(FONT, 8.5)
        title = Font(FONT, 9.5, FontStyle.Bold)
        rec = self.cur_rec
        ten = self.cur_key[1]
        rows = R.rows_for(self.data, loai, ten)
        shapes, pts = [], []   # (poly, style)
        goi_labels = []
        piles = []
        lean_poly = None
        stubs = []
        if self._is_strip(loai):
            if loai == "DamMong":
                chain, cs, ce = self._chain_of(rec)
                fr = R.frame_chain(chain, cs, ce)
                segs_draw = chain
            else:
                chain = None
                fr = R.frame_strip(rec)
                segs_draw = self._segments(loai, ten)
            for s in segs_draw:
                p = self._poly(s)
                if p:
                    shapes.append((p, "hl" if s is rec else "main"))
                    pts.extend(p)
            if loai == "DamMong":
                for gid in self._goi_ids(chain):
                    f = None
                    for shn in ("MongDon", "DaiMong"):
                        f = f or self._find_id(shn, gid)
                    if f is None:
                        f = self._find_id("MongBang", gid)
                    if f is not None:
                        gp = self._poly(f)
                        if len(gp) >= 3:
                            shapes.append((gp, "goi"))
                            pts.extend(gp)
                            goi_labels.append((gp, u"%s" % (f.get("Ten") or f.get("Nhom"))))
            for c in self._cols_all(loai, rec, chain):
                if c is not None:
                    p = self._poly(c)
                    if p:
                        shapes.append((p, "hl" if c is self.hl else "col"))
        else:
            fr = R.frame_footing(rec)
            p = self._poly(rec)
            shapes.append((p, "main"))
            pts.extend(p)
            for _z, bp in M.str_to_bac(rec.get("Bac")):       # bac / mat vat phia tren (net dut)
                if len(bp) >= 3:
                    shapes.append((bp, "bac"))
                    pts.extend(bp)
            if len(p) >= 3:
                lt_, lo_ = self._lean()
                if lo_ > 0 and lt_ > 0:
                    lean_poly = G.offset_polygon(p, lo_)
                    pts.extend(lean_poly)
                for bm in self._beams_of(rec):
                    for pc in R.stub_pieces(p, bm, 600.0):
                        stubs.append((pc, bm))
                        pts.extend(R.piece_polygon(pc, 0.0))
            for c in self._cols_of(loai, rec):
                if c is not None:
                    cp = self._poly(c)
                    if cp:
                        shapes.append((cp, "hl" if c is self.hl else "col"))
            if loai == "DaiMong":
                for pl in self._piles_of(rec):
                    if pl is not None:
                        piles.append(pl)
                        d = M.to_float(pl.get("D")) / 2.0
                        x, y = M.to_float(pl.get("X")), M.to_float(pl.get("Y"))
                        pts.extend([(x - d, y - d), (x + d, y + d)])
        # vi tri mat cat A-A, B-B (hien tren mat bang)
        cuts = []
        mg = 350.0
        if self._is_strip(loai):
            fr_r = R.frame_strip(rec)
            cuts.append((fr_r, (0.0, fr_r["vmin"] - mg), (0.0, fr_r["vmax"] + mg), (-1.0, 0.0), u"A"))
            cuts.append((fr, (fr["umin"] - mg, 0.0), (fr["umax"] + mg, 0.0), (0.0, 1.0), u"B"))
        else:
            pa_, _h1 = self._foot_cut_pos(loai, rec, fr, 0)
            pb_, _h2 = self._foot_cut_pos(loai, rec, fr, 1)
            cuts.append((fr, (pa_, fr["vmin"] - mg), (pa_, fr["vmax"] + mg), (-1.0, 0.0), u"A"))
            cuts.append((fr, (fr["umin"] - mg, pb_), (fr["umax"] + mg, pb_), (0.0, 1.0), u"B"))
        for c_ in cuts:
            pts.extend([R.to_global(c_[0], c_[1]), R.to_global(c_[0], c_[2])])
        if not pts:
            return
        cv = Canvas(W, H, (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts)),
                    ml=90, mr=90, mt=46, mb=110)
        # be tong lot (net dut, nam duoi mong, chia ra xung quanh)
        if lean_poly is not None and len(lean_poly) >= 3:
            g.DrawPolygon(self._pen(th["dim"], 1.2, True), self._poly_arr(cv, lean_poly))
        # hinh
        for poly, st in shapes:
            if len(poly) < 3:
                continue
            arr = self._poly_arr(cv, poly)
            if st == "main":
                g.FillPolygon(SolidBrush(th["main_fill"]), arr)
                g.DrawPolygon(self._pen(th["main"], 1.8), arr)
            elif st == "hl":
                g.DrawPolygon(self._pen(th["hl"], 2.4), arr)
            elif st == "bac":
                g.DrawPolygon(self._pen(th["main"], 1.3, True), arr)
            elif st == "goi":
                g.FillPolygon(SolidBrush(th["main_fill"]), arr)
                g.DrawPolygon(self._pen(th["pile"], 1.6, True), arr)
            else:
                g.DrawPolygon(self._pen(th["col"], 1.6), arr)
        for gp, gname in goi_labels:
            cc = G.centroid(gp)
            q = cv.T(cc)
            g.DrawString(gname, font, SolidBrush(th["pile"]), float(q.X - 10), float(q.Y - 7))
        # dam mong gac vao mong: chi ve doan nho ra, cat zic zac neu dam con keo dai
        amp = 4.0 / max(cv.k, 1e-6)
        for pc, bm in stubs:
            gp = R.piece_polygon(pc, amp)
            arr = self._poly_arr(cv, gp)
            g.FillPolygon(SolidBrush(th["main_fill"]), arr)
            g.DrawPolygon(self._pen(th["main"], 1.6), arr)
            cc = cv.T(G.centroid(gp))
            g.DrawString(u"%s" % bm.get("Ten"), font, SolidBrush(th["main"]), float(cc.X - 10), float(cc.Y - 7))
        # coc
        for pl in piles:
            x, y, d = M.to_float(pl.get("X")), M.to_float(pl.get("Y")), M.to_float(pl.get("D"))
            c = cv.T((x, y))
            rr = float(max(d * cv.k / 2.0, 3.0))
            pen = self._pen(th["hl"] if pl is self.hl else th["pile"], 2.0 if pl is self.hl else 1.5)
            if pl.get("HinhDang") == u"Vuông":
                g.DrawRectangle(pen, c.X - rr, c.Y - rr, 2 * rr, 2 * rr)
            else:
                g.DrawEllipse(pen, c.X - rr, c.Y - rr, 2 * rr, 2 * rr)
            g.DrawLine(pen, c.X - 3.0, c.Y, c.X + 3.0, c.Y)
            g.DrawLine(pen, c.X, c.Y - 3.0, c.X, c.Y + 3.0)
        # thep tren mat bang
        if self._is_strip(loai):
            self._plan_strip_bars(g, cv, fr, rec, rows)
        else:
            for r in rows:
                bl = R.bar_layout(fr, r, self.rules)
                if not bl:
                    continue
                col = _color(R.COLORS.get(r.get("ViTri"), (200, 200, 200)))
                pen = Pen(col, float(min(max(M.to_float(r.get("D")) * cv.k, 1.0), 3.0)))
                for run, p, t0, t1 in bl["lines"]:
                    a, b = ((t0, p), (t1, p)) if run == "u" else ((p, t0), (p, t1))
                    g.DrawLine(pen, cv.T(R.to_global(fr, a)), cv.T(R.to_global(fr, b)))
        # kich thuoc
        corners = [(fr["umin"], fr["vmin"]), (fr["umax"], fr["vmin"]), (fr["umax"], fr["vmax"]), (fr["umin"], fr["vmax"])]
        sc = [cv.T(R.to_global(fr, c)) for c in corners]
        inter = (sum(p.X for p in sc) / 4.0, sum(p.Y for p in sc) / 4.0)
        eu = fr["umax"] - fr["umin"]
        ev = fr["vmax"] - fr["vmin"]
        draw_dim(g, sc[0], sc[1], inter, 26.0, u"%.0f" % eu, th, font)
        draw_dim(g, sc[1], sc[2], inter, 26.0, u"%.0f" % ev, th, font)
        if not self._is_strip(loai):
            cols_l = []
            for c in self._cols_of(loai, rec):
                if c is not None:
                    cp = self._poly(c)
                    if cp:
                        cols_l.append([R.to_local(fr, q) for q in cp])
            if 0 < len(cols_l) <= 4:
                self._chain(g, cv, fr, inter, font, "u", self._merge([(min(q[0] for q in c), max(q[0] for q in c)) for c in cols_l], fr["umin"], fr["umax"]), 50.0)
                self._chain(g, cv, fr, inter, font, "v", self._merge([(min(q[1] for q in c), max(q[1] for q in c)) for c in cols_l], fr["vmin"], fr["vmax"]), 50.0)
            if piles:
                lp = [R.to_local(fr, (M.to_float(p.get("X")), M.to_float(p.get("Y")))) for p in piles]
                self._chain(g, cv, fr, inter, font, "u", self._points([q[0] for q in lp], fr["umin"], fr["umax"]), 74.0)
                self._chain(g, cv, fr, inter, font, "v", self._points([q[1] for q in lp], fr["vmin"], fr["vmax"]), 74.0)
        for c_ in cuts:
            self._draw_cut(g, cv, c_[0], c_[1], c_[2], c_[3], c_[4])
        # chu thich thep
        y = 34.0
        extra = u""
        if piles:
            extra = u"   |   %d cọc %s %.0f, dài %.0f" % (len(piles), piles[0].get("HinhDang") or u"",
                                                       M.to_float(piles[0].get("D")), M.to_float(piles[0].get("Dai")))
        if lean_poly is not None:
            extra += u"   |   BT lót dày %.0f, chìa %.0f (nét đứt)" % (self._lean()[0], self._lean()[1])
        if stubs:
            extra += u"   |   dầm: %s" % u", ".join(sorted(set(u"%s" % b.get("Ten") for _, b in stubs), key=M.nat_key))
        if loai == "DamMong" and rec.get("NoiDai"):
            extra += u"   |   gối: %s" % rec.get("NoiDai")
            if rec.get("GoiCot"):
                extra += u"   cột: %s" % rec.get("GoiCot")
        g.DrawString(u"Mark %s  -  mặt bằng (mm)%s   |   A-A, B-B: vị trí mặt cắt" % (ten, extra), title, SolidBrush(th["fg"]), 12.0, 10.0)
        for r in sorted(rows, key=lambda r: M.to_float(r.get("STT"))):
            col = _color(R.COLORS.get(r.get("ViTri"), (200, 200, 200)))
            g.FillRectangle(SolidBrush(col), 14.0, y + 4.0, 14.0, 4.0)
            g.DrawString(u"T%d  %s  Ø%.0f %s" % (M.to_float(r.get("STT")), R.label_of(r.get("ViTri")), M.to_float(r.get("D")),
                         (u"a%.0f" % M.to_float(r.get("A"))) if M.to_float(r.get("A")) > 0 else (u"%d thanh" % M.to_float(r.get("SoThanh")))),
                         font, SolidBrush(th["fg"]), 34.0, y)
            y += 16.0

    def _merge(self, ivs, lo, hi):
        ivs = sorted(ivs)
        merged = []
        for a, b in ivs:
            if merged and a <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        bp = [lo]
        for a, b in merged:
            bp.extend([a, b])
        bp.append(hi)
        return bp

    def _points(self, vals, lo, hi):
        bp = [lo] + sorted(set(round(v, 1) for v in vals)) + [hi]
        return bp

    def _chain(self, g, cv, fr, inter, font, axis, bp, off):
        bp = sorted(bp)
        for i in range(len(bp) - 1):
            a, b = bp[i], bp[i + 1]
            if b - a < 1.0:
                continue
            if axis == "u":
                p0, p1 = (a, fr["vmin"]), (b, fr["vmin"])
            else:
                p0, p1 = (fr["umax"], a), (fr["umax"], b)
            draw_dim(g, cv.T(R.to_global(fr, p0)), cv.T(R.to_global(fr, p1)), inter, off, u"%.0f" % (b - a), self.th, font)

    def _plan_strip_bars(self, g, cv, fr, rec, rows):
        b = fr["vmax"] - fr["vmin"]
        dai = [r for r in rows if r.get("ViTri") == "BangDai"]
        dd = M.to_float(dai[0].get("D")) if dai else 0.0
        for r in rows:
            vt = r.get("ViTri")
            if vt not in ("BangDuoi", "BangTren"):
                continue
            d, n = M.to_float(r.get("D")), int(M.to_float(r.get("SoThanh")))
            cov = R.row_cover(r, self.rules)
            if d <= 0 or n <= 0:
                continue
            x0 = fr["vmin"] + cov + dd + d / 2.0
            x1 = fr["vmax"] - cov - dd - d / 2.0
            pen = Pen(_color(R.COLORS[vt]), float(min(max(d * cv.k, 1.0), 3.0)))
            if vt == "BangTren":
                pen.DashStyle = DashStyle.Dash
            for i in range(n):
                v = (x0 + x1) / 2.0 if n == 1 else x0 + (x1 - x0) * i / (n - 1.0)
                g.DrawLine(pen, cv.T(R.to_global(fr, (fr["umin"] + cov, v))), cv.T(R.to_global(fr, (fr["umax"] - cov, v))))

    # ---- mat cat mong don / dai
    def _zigzag(self, g, pen, x0, x1, y):
        w = x1 - x0
        pts = [PointF(float(x0), float(y)), PointF(float(x0 + w * 0.25), float(y - 4)),
               PointF(float(x0 + w * 0.5), float(y + 4)), PointF(float(x0 + w * 0.75), float(y - 4)),
               PointF(float(x1), float(y))]
        g.DrawLines(pen, Array[PointF](pts))

    def _draw_foot_section(self, g, panel, key):
        th = self.th
        W, Hh = panel.ClientSize.Width, panel.ClientSize.Height
        font = Font(FONT, 8.5)
        title = Font(FONT, 9.5, FontStyle.Bold)
        loai, ten = self.cur_key
        rec = self.cur_rec
        rows = R.rows_for(self.data, loai, ten)
        fr = R.frame_footing(rec)
        H = M.to_float(rec.get("H"))
        lt, lo = self._lean()
        cut = "u" if key == "A" else "v"
        horiz = "v" if cut == "u" else "u"
        ci = 0 if cut == "u" else 1        # chi so toa do doc theo vet cat
        hi = 1 - ci                        # chi so toa do nam ngang tren ban ve
        cols_l = []
        for c in self._cols_of(loai, rec):
            if c is not None:
                cp = self._poly(c)
                if cp:
                    cols_l.append([R.to_local(fr, q) for q in cp])
        piles = []
        if loai == "DaiMong":
            for pl in self._piles_of(rec):
                if pl is not None:
                    piles.append((R.to_local(fr, (M.to_float(pl.get("X")), M.to_float(pl.get("Y")))), pl))
        # vi tri cat: dai coc -> qua hang coc dau tien; con lai -> qua tam cot dau tien
        pos, how = self._foot_cut_pos(loai, rec, fr, ci)
        sec = R.section_footing(fr, rows, H, self.rules, cut, pos)
        name = u"A-A" if key == "A" else u"B-B"
        sub = u"cắt vuông góc phương X, bề rộng theo Y" if key == "A" else u"cắt vuông góc phương Y, bề rộng theo X"
        g.DrawString(u"%s  -  mặt cắt %s  (%s; %s)" % (ten, name, sub, how), title, SolidBrush(th["fg"]), 12.0, 10.0)
        if not sec["intervals"]:
            g.DrawString(u"Mặt cắt nằm ngoài biên móng", font, SolidBrush(th["dim"]), 14.0, 36.0)
            return
        profs = [q for q in self._foot_profs(rec, key) if len(q) >= 3]
        fx0 = min(a for a, b in sec["intervals"])
        fx1 = max(b for a, b in sec["intervals"])
        if profs:
            fx0 = min(min(pt[0] for pt in q) for q in profs)
            fx1 = max(max(pt[0] for pt in q) for q in profs)
        xs = [fx0 - lo, fx1 + lo]
        for q in cols_l:
            xs.extend([min(p[hi] for p in q), max(p[hi] for p in q)])
        for pq, pl in piles:
            d = M.to_float(pl.get("D"))
            xs.extend([pq[hi] - d / 2.0, pq[hi] + d / 2.0])
        xmin, xmax = min(xs), max(xs)
        stub = 0.6 * H
        zlow = -(lt + (stub if piles else 0.0))
        cv = Canvas(W, Hh, (xmin, zlow - 0.4 * H, xmax, 1.6 * H), ml=70, mr=150, mt=46, mb=80)
        # be tong lot
        if lt > 0:
            for a, b in sec["intervals"]:
                self._rect(g, cv, a - lo, -lt, b + lo, 0.0, th["line"], self._pen(th["dim"], 1.2))
        # mat cat mong (hinh that neu mong co bac / vat, khong thi chu nhat)
        if profs:
            for q in profs:
                arr = Array[PointF]([cv.T(pt) for pt in q])
                g.FillPolygon(SolidBrush(th["main_fill"]), arr)
                g.DrawPolygon(self._pen(th["main"], 1.8), arr)
        else:
            for a, b in sec["intervals"]:
                self._rect(g, cv, a, 0.0, b, H, th["main_fill"], self._pen(th["main"], 1.8))
        # coc: net lien = bi cat, net dut = nam sau mat cat; doan ngam trong dai ve net dut
        any_cut = any(abs(pq[ci] - pos) <= M.to_float(pl.get("D")) / 2.0 + 1e-6 for pq, pl in piles)
        labelled = False
        for pq, pl in piles:
            d = M.to_float(pl.get("D"))
            cutp = abs(pq[ci] - pos) <= d / 2.0 + 1e-6
            emb = R.pile_embed(pl, rec)
            pen = self._pen(th["pile"], 1.8 if cutp else 1.3, not cutp)
            dpen = self._pen(th["pile"], 1.3, True)
            xl = float(cv.T((pq[hi] - d / 2.0, 0)).X)
            xr = float(cv.T((pq[hi] + d / 2.0, 0)).X)
            ytop = float(cv.T((pq[hi], emb)).Y)
            y0 = float(cv.T((pq[hi], 0)).Y)
            ybot = float(cv.T((pq[hi], zlow)).Y)
            if emb > 1.0:
                for x in (xl, xr):
                    g.DrawLine(dpen, x, ytop, x, y0)
                g.DrawLine(dpen, xl, ytop, xr, ytop)
                ys = y0
            else:
                ys = ytop
                g.DrawLine(pen, xl, ytop, xr, ytop)
            for x in (xl, xr):
                g.DrawLine(pen, x, ys, x, ybot)
            self._zigzag(g, self._pen(th["pile"], 1.3), xl, xr, ybot)
            if not labelled and (cutp or not any_cut):
                labelled = True
                if emb > 1.0:
                    en = u"ngàm vào đài %.0f" % emb
                    a_, b_ = cv.T((pq[hi] + d / 2.0, 0)), cv.T((pq[hi] + d / 2.0, emb))
                    draw_dim(g, a_, b_, (float(cv.T((pq[hi], 0)).X), (a_.Y + b_.Y) / 2.0), 16.0, u"%.0f" % emb, th, font)
                elif emb < -1.0:
                    en = u"đầu cọc thấp hơn đáy đài %.0f" % (-emb)
                else:
                    en = u"đầu cọc ngang đáy đài"
                g.DrawString(u"Cọc %s %.0f  dài %.0f  (%s)" % (pl.get("HinhDang") or u"", d, M.to_float(pl.get("Dai")), en),
                             font, SolidBrush(th["pile"]), float(xl - 10), float(ybot + 8))
        # cot (net lien = bi cat, net dut = nam sau mat cat)
        for q in cols_l:
            hs = [p[hi] for p in q]
            cutc = bool(R.clip_intervals(q, horiz, pos))
            p0, p1 = cv.T((min(hs), H)), cv.T((max(hs), 1.55 * H))
            g.DrawRectangle(self._pen(th["col"], 1.6, not cutc), p0.X, p1.Y, p1.X - p0.X, p0.Y - p1.Y)
        self._section_bars(g, cv, sec, rows, font)
        # kich thuoc
        a = cv.T((fx0, zlow))
        b = cv.T((fx1, zlow))
        inter = ((a.X + b.X) / 2.0, cv.T((0, H / 2.0)).Y)
        draw_dim(g, a, b, inter, 30.0, u"%.0f" % (fx1 - fx0), th, font)
        draw_dim(g, cv.T((fx0, 0)), cv.T((fx0, H)), inter, 30.0, u"%.0f" % H, th, font)
        if lt > 0:
            draw_dim(g, cv.T((fx1 + lo, 0)), cv.T((fx1 + lo, -lt)), inter, 30.0, u"%.0f" % lt, th, font)
            q = cv.T((fx0 - lo, -lt))
            g.DrawString(u"BT lót dày %.0f, chìa %.0f" % (lt, lo), font, SolidBrush(th["dim"]), float(q.X), float(q.Y + 3))
        if profs:
            items = sorted(profs, key=lambda q: (min(pt[1] for pt in q), -(max(pt[0] for pt in q) - min(pt[0] for pt in q))))
            for q in items[1:]:                              # kich thuoc ngang tung bac, dat tren dinh bac
                h0, h1 = min(pt[0] for pt in q), max(pt[0] for pt in q)
                z1 = max(pt[1] for pt in q)
                if h1 - h0 > 1.0 and abs((h1 - h0) - (fx1 - fx0)) > 1.0:
                    draw_dim(g, cv.T((h0, z1)), cv.T((h1, z1)), inter, 16.0, u"%.0f" % (h1 - h0), th, font)
            if len(items) > 1:
                desc = u";  ".join(u"%.0f×%.0f" % (max(pt[0] for pt in q) - min(pt[0] for pt in q),
                                                      max(pt[1] for pt in q) - min(pt[1] for pt in q)) for q in items)
                g.DrawString(u"Mặt cắt thật qua tâm móng - các bậc (rộng × cao, từ dưới lên): %s" % desc, font,
                             SolidBrush(th["dim"]), 14.0, 28.0)
            else:
                g.DrawString(u"Mặt cắt thật qua tâm móng (móng vát / không chữ nhật)", font, SolidBrush(th["dim"]), 14.0, 28.0)

    def _foot_profs(self, rec, key):
        s = rec.get("MatCatA" if key == "A" else "MatCatB")
        out = []
        for part in (s or u"").split("|"):
            if part:
                out.append(M.str_to_poly(part))
        return out

    def _section_bars(self, g, cv, sec, rows, font, labels_on=True):
        th = self.th
        rowmap = dict((r.get("ViTri"), r) for r in rows)
        labels = {}
        for h, z, d, vt in sec["dots"]:
            c = cv.T((h, z))
            rr = float(max(d * cv.k / 2.0, 2.5))
            g.FillEllipse(SolidBrush(_color(R.COLORS[vt])), c.X - rr, c.Y - rr, 2 * rr, 2 * rr)
            labels[vt] = (c.X, c.Y)
        for h0, h1, z, d, vt, r in sec["hlines"]:
            a, b = cv.T((h0, z)), cv.T((h1, z))
            pen_h = Pen(_color(R.COLORS[vt]), float(max(d * cv.k, 1.5)))
            g.DrawLine(pen_h, a, b)
            # Moc be vuong 90 do theo TCVN (Day: be len, Tren: be xuong)
            hk = 12.0
            dir_y = -hk if vt in ("DayX", "DayY") else hk
            g.DrawLine(pen_h, a.X, a.Y, a.X, a.Y + dir_y)
            g.DrawLine(pen_h, b.X, b.Y, b.X, b.Y + dir_y)
            labels[vt] = (b.X, b.Y)
        if not labels_on:
            return
        items = []
        for vt, (x, y) in labels.items():
            r = rowmap.get(vt)
            if r is None:
                continue
            txt = u"T%d Ø%.0f%s" % (M.to_float(r.get("STT")), M.to_float(r.get("D")),
                                    (u" a%.0f" % M.to_float(r.get("A"))) if M.to_float(r.get("A")) > 0 else u"")
            items.append([y - 8.0, x + 10.0, txt, vt])
        items.sort(key=lambda t: t[0])
        for i in range(1, len(items)):
            if items[i][0] < items[i - 1][0] + 13.0:
                items[i][0] = items[i - 1][0] + 13.0
        for yy, xx, txt, vt in items:
            g.DrawString(txt, font, SolidBrush(_color(R.COLORS[vt])), float(xx), float(yy))

    # ---- mat cat mong bang / dam mong: trinh bay nhu ban ve trien khai dam
    #      (mat cat doc theo tim co cot, dai, goi + cac mat cat ngang 1-1, 2-2, 3-3)
    def _chain_foots(self, loai, chain, fr, z0):
        """Cac dai / mong don ma dam gac vao: (sheet, rec, u_a, u_b, z_day, z_dinh) theo he truc dam (z tu day dam)."""
        out = []
        if loai != "DamMong":
            return out
        for f in self._support_footings(chain):
            ivs = R.centre_intervals(fr, self._poly(f))
            if not ivs:
                continue
            sh = "MongDon" if any(f is x for x in self.data.get("MongDon", [])) else "DaiMong"
            out.append((sh, f, min(x[0] for x in ivs), max(x[1] for x in ivs),
                        M.to_float(f.get("ZDay")) - z0, M.to_float(f.get("ZDinh")) - z0))
        return out

    def _cut_positions(self, foots, u0, u1):
        """Vi tri 3 mat cat ngang: gan goi trai, giua nhip, gan goi phai (trong khoang giua hai mat goi)."""
        mid = (u0 + u1) / 2.0
        left = [min(x[3], u1) for x in foots if (x[2] + x[3]) / 2.0 <= mid]
        right = [max(x[2], u0) for x in foots if (x[2] + x[3]) / 2.0 > mid]
        a = max([u0] + left)
        b = min([u1] + right)
        if b - a < 100.0:
            a, b = u0, u1
        span = b - a
        return [(u"1-1", a + 0.12 * span), (u"2-2", (a + b) / 2.0), (u"3-3", b - 0.12 * span)], a, b

    def _seg_at(self, chain, fr, u, default):
        for s_ in chain:
            poly = self._poly(s_)
            if not poly:
                continue
            e = R.local_extent(fr, poly)
            if e[0] - 1.0 <= u <= e[1] + 1.0:
                return s_
        return default

    def _legend_line(self, g, rows, x, y, font):
        th = self.th
        for r in sorted(rows, key=lambda r: M.to_float(r.get("STT"))):
            vt = r.get("ViTri")
            if vt not in R.COLORS:
                continue
            d = M.to_float(r.get("D"))
            if vt in ("BangDai", "BangDaiNhip", "BangDaiTC", "BangCanh"):
                txt = u"T%d  %s Ø%.0f a%.0f" % (M.to_float(r.get("STT")), R.label_of(vt), d, M.to_float(r.get("A")))
            else:
                txt = u"T%d  %s %dØ%.0f" % (M.to_float(r.get("STT")), R.label_of(vt), int(M.to_float(r.get("SoThanh"))), d)
            g.FillRectangle(SolidBrush(_color(R.COLORS[vt])), float(x), float(y + 5), 14.0, 4.0)
            g.DrawString(txt, font, SolidBrush(th["fg"]), float(x + 18), float(y))
            x += 18 + g.MeasureString(txt, font).Width + 14

    def _draw_col_elev(self, g, cv, fr, c, base, colh, u_lo, u_hi, font):
        cp = self._poly(c)
        if not cp:
            return False
        q = [R.to_local(fr, p) for p in cp]
        qu = [p[0] for p in q]
        if max(qu) < u_lo or min(qu) > u_hi:
            return False
        th = self.th
        col = th["col"]
        c0, c1 = cv.T((min(qu), base)), cv.T((max(qu), base + colh))
        w, h = c1.X - c0.X, c0.Y - c1.Y
        g.FillRectangle(SolidBrush(Color.FromArgb(70, int(col.R), int(col.G), int(col.B))), c0.X, c1.Y, w, h)
        pen = self._pen(col, 1.6)
        g.DrawLine(pen, c0.X, c0.Y, c0.X, c1.Y)
        g.DrawLine(pen, c1.X, c0.Y, c1.X, c1.Y)
        self._zigzag(g, pen, c0.X, c1.X, c1.Y)
        lab = c.get("Mark") or (u"Id%s" % c.get("ElementId"))
        g.DrawString(u"%s  %.0f×%.0f" % (lab, M.to_float(c.get("B")), M.to_float(c.get("H"))), font,
                     SolidBrush(col), float(c0.X), float(c1.Y - 17))
        return True

    def _draw_strip_xsec(self, g, W, Hh, rec, rows, title):
        """Mot mat cat ngang (khung rong W x Hh): hinh that, BT lot, dai, thep, kich thuoc."""
        th = self.th
        font = Font(FONT, 8.0)
        sec = R.strip_section(rec, rows, self.rules)
        H = sec["H"]
        lt, lo = self._lean()
        g.DrawString(title, Font(FONT, 9.0, FontStyle.Bold), SolidBrush(th["fg"]), 6.0, 46.0)
        if H <= 0 or sec["b"] <= 0:
            return
        prof = M.str_to_poly(rec.get("MatCat"))
        if len(prof) < 3:
            prof = None
        pv = [p[0] for p in prof] if prof else []
        pz = [p[1] for p in prof] if prof else []
        xmin = min([sec["vmin"]] + pv) - lo
        xmax = max([sec["vmax"]] + pv) + lo
        ymin = -lt
        ymax = max([H] + pz)
        cv = Canvas(W, Hh, (xmin, ymin, xmax, ymax), ml=56, mr=24, mt=74, mb=104)
        if lt > 0:
            self._rect(g, cv, sec["vmin"] - lo, -lt, sec["vmax"] + lo, 0.0, th["line"], self._pen(th["dim"], 1.2))
        p0, p1 = cv.T((sec["vmin"], H)), cv.T((sec["vmax"], 0))
        if prof:
            arr = Array[PointF]([cv.T(p) for p in prof])
            g.FillPolygon(SolidBrush(th["main_fill"]), arr)
            g.DrawPolygon(self._pen(th["main"], 1.8), arr)
        else:
            g.FillRectangle(SolidBrush(th["main_fill"]), p0.X, p0.Y, p1.X - p0.X, p1.Y - p0.Y)
            g.DrawRectangle(self._pen(th["main"], 1.8), p0.X, p0.Y, p1.X - p0.X, p1.Y - p0.Y)
        if sec["stirrup"]:
            x0, z0_, x1, z1_, dd = sec["stirrup"]
            s0, s1 = cv.T((x0, z1_)), cv.T((x1, z0_))
            g.DrawRectangle(Pen(_color(R.COLORS["BangDai"]), float(max(dd * cv.k, 1.5))), s0.X, s0.Y, s1.X - s0.X, s1.Y - s0.Y)
        if sec.get("wing_bar"):
            wx0, wz, wx1, wd = sec["wing_bar"]
            pw = Pen(_color(R.COLORS["BangCanh"]), float(max(wd * cv.k, 2.0)))
            wa, wb = cv.T((wx0, wz)), cv.T((wx1, wz))
            g.DrawLine(pw, wa, wb)
            g.DrawLine(pw, wa.X, wa.Y, wa.X, wa.Y - 10.0)
            g.DrawLine(pw, wb.X, wb.Y, wb.X, wb.Y - 10.0)
        self._section_bars(g, cv, {"dots": sec["dots"], "hlines": []}, rows, font, labels_on=False)
        a, b = cv.T((sec["vmin"], -lt)), cv.T((sec["vmax"], -lt))
        inter = ((a.X + b.X) / 2.0, cv.T((0, H / 2.0)).Y)
        draw_dim(g, a, b, inter, 20.0, u"%.0f" % sec["b"], th, font)
        if lt > 0:
            draw_dim(g, cv.T((sec["vmin"] - lo, -lt)), cv.T((sec["vmax"] + lo, -lt)), inter, 42.0,
                     u"%.0f" % (sec["b"] + 2 * lo), th, font)
        draw_dim(g, cv.T((sec["vmin"], 0)), cv.T((sec["vmin"], H)), inter, 22.0, u"%.0f" % H, th, font)
        if lt > 0:
            q = cv.T((sec["vmin"] - lo, -lt))
            g.DrawString(u"BT lót %.0f" % lt, font, SolidBrush(th["dim"]), float(q.X), float(q.Y + 62))

    def _draw_strip_sections(self, g, panel):
        """Cac mat cat ngang 1-1, 2-2, 3-3 canh nhau (gan goi trai / giua nhip / gan goi phai)."""
        th = self.th
        W, Hh = panel.ClientSize.Width, panel.ClientSize.Height
        font = Font(FONT, 8.5)
        title = Font(FONT, 9.5, FontStyle.Bold)
        loai, ten = self.cur_key
        rec = self.cur_rec
        rows = R.rows_for(self.data, loai, ten)
        chain, cs, ce = R.chain_segments(self._segments(loai, ten), rec)
        fr = R.frame_chain(chain, cs, ce)
        z0 = M.to_float(rec.get("ZDay"))
        foots = self._chain_foots(loai, chain, fr, z0)
        cuts, ca, cb = self._cut_positions(foots, fr["umin"], fr["umax"])
        g.DrawString(u"%s  -  các mặt cắt ngang (vị trí xem ở mặt cắt dọc)" % ten, title, SolidBrush(th["fg"]), 12.0, 8.0)
        self._legend_line(g, rows, 12.0, 28.0, font)
        cw = float(W) / len(cuts)
        for i, (lab, u) in enumerate(cuts):
            seg = self._seg_at(chain, fr, u, rec)
            g.TranslateTransform(float(i * cw), 0.0)
            try:
                self._draw_strip_xsec(g, int(cw), Hh, seg, rows, u"Mặt cắt %s   (cách đầu dầm %.0f)" % (lab, u - fr["umin"]))
            finally:
                g.ResetTransform()

    def _draw_strip_long(self, g, panel):
        """Mat cat doc theo tim: gop cac doan cung Mark thanh 1 dam; co dai / mong gac, cot, BT lot, dai, thep, mat cat 1-1..3-3."""
        th = self.th
        W, Hh = panel.ClientSize.Width, panel.ClientSize.Height
        font = Font(FONT, 8.5)
        title = Font(FONT, 9.5, FontStyle.Bold)
        loai, ten = self.cur_key
        rec = self.cur_rec
        rows = R.rows_for(self.data, loai, ten)
        lt, lo = self._lean()
        chain, cs, ce = R.chain_segments(self._segments(loai, ten), rec)
        fr = R.frame_chain(chain, cs, ce)
        H = M.to_float(rec.get("H"))
        z0 = M.to_float(rec.get("ZDay"))
        u0, u1 = fr["umin"], fr["umax"]
        L = u1 - u0
        g.DrawString(u"%s  -  mặt cắt dọc theo tim (gộp %d đoạn cùng Mark, dài %.0f)" % (ten, len(chain), L),
                     title, SolidBrush(th["fg"]), 12.0, 10.0)
        if H <= 0 or L <= 0:
            return
        foots = self._chain_foots(loai, chain, fr, z0)       # (sheet, rec, a, b, fz0, fz1)
        colh = max(0.9 * H, 450.0)
        cols = []                                             # (cot, cao do chan cot)
        seen = set()
        for c in self._cols_all(loai, rec, chain):
            if c.get("ElementId") not in seen:
                seen.add(c.get("ElementId"))
                cols.append((c, H, None))
        for sh_, f, a, b, fz0, fz1 in foots:                  # cot dung tren dai / mong don o hai dau dam
            for c in self._cols_of(sh_, f):
                if c.get("ElementId") not in seen:
                    seen.add(c.get("ElementId"))
                    cols.append((c, fz1, (a, b)))
        xmin = min([u0] + [x[2] for x in foots]) - lo
        xmax = max([u1] + [x[3] for x in foots]) + lo
        ymin = min([0.0] + [x[4] for x in foots]) - lt - 0.1 * H
        ymax = max([H + colh] + [x[5] + colh for x in foots]) + 0.25 * H
        ky = max(1.0, min(6.0, (xmax - xmin) / (ymax - ymin) / 4.0))
        if ky > 1.05:
            g.DrawString(u"(tỉ lệ đứng phóng x%.1f)" % ky, font, SolidBrush(th["dim"]), 14.0, 30.0)
        cv = Canvas(W, Hh, (xmin, ymin, xmax, ymax), ml=70, mr=170, mt=52, mb=110, ky=ky)
        # be tong lot (duoi dam va duoi tung dai)
        if lt > 0:
            lp = self._pen(th["dim"], 1.2)
            self._rect(g, cv, u0, -lt, u1, 0.0, th["line"], lp)
            for sh_, f, a, b, fz0, fz1 in foots:
                self._rect(g, cv, a - lo, fz0 - lt, b + lo, fz0, th["line"], lp)
        # dam (da gop)
        self._rect(g, cv, u0, 0.0, u1, H, th["main_fill"], self._pen(th["main"], 1.8))
        # dai: de len dam, phan dam nam trong dai bi che
        for sh_, f, a, b, fz0, fz1 in foots:
            self._rect(g, cv, a, fz0, b, fz1, th["main_fill"], self._pen(th["main"], 1.8))
            q = cv.T((a, fz1))
            g.DrawString(u"%s %s" % (u"Đài" if sh_ == "DaiMong" else u"Móng", f.get("Ten") or u""), font,
                         SolidBrush(th["pile"]), float(q.X + 2), float(q.Y + 2))
        # cot
        for c, base, rng in cols:
            if rng is None:
                self._draw_col_elev(g, cv, fr, c, base, colh, u0, u1, font)
            else:
                self._draw_col_elev(g, cv, fr, c, base, colh, rng[0] - 1500.0, rng[1] + 1500.0, font)
        dai = [r for r in rows if r.get("ViTri") == "BangDai"]
        dd = M.to_float(dai[0].get("D")) if dai else 0.0
        cov_d = R.row_cover(dai[0], self.rules) if dai else self.rules["cover"]
        # dai (ho tro phan vung goi/nhip va dai tang cuong; khong ve trong dai mong)
        dai_nhip = [r for r in rows if r.get("ViTri") == "BangDaiNhip"]
        dai_tc = [r for r in rows if r.get("ViTri") == "BangDaiTC"]
        if dai:
            a1 = M.to_float(dai[0].get("A"))
            a2 = M.to_float(dai_nhip[0].get("A")) if dai_nhip else a1
            if a1 > 0:
                pen1 = Pen(_color(R.COLORS["BangDai"]), 1.1)
                pen2 = Pen(_color(R.COLORS["BangDaiNhip"]), 1.0)
                x, nst = u0 + cov_d, 0
                z_lo, z_hi = u0 + 0.25 * L, u1 - 0.25 * L
                while x <= u1 - cov_d + 1e-6:
                    in_end = (x <= z_lo or x >= z_hi)
                    step = a1 if (in_end or a2 <= 0) else a2
                    if not any(fa < x < fb for _, _, fa, fb, _, _ in foots):
                        nst += 1
                        g.DrawLine(pen1 if in_end else pen2, cv.T((x, cov_d)), cv.T((x, H - cov_d)))
                    x += step
                lab = cv.T((u1, 0.5 * H))
                stxt = u"đai Ø%.0f a%.0f/%.0f" % (dd, a1, a2) if dai_nhip else u"đai Ø%.0f a%.0f" % (dd, a1)
                g.DrawString(u"T%d  %s  (%d bộ)" % (M.to_float(dai[0].get("STT")), stxt, nst), font,
                             SolidBrush(_color(R.COLORS["BangDai"])), float(lab.X + 10), float(lab.Y - 8))
        if dai_tc:
            atc = M.to_float(dai_tc[0].get("A"))
            dtc = M.to_float(dai_tc[0].get("D"))
            if atc > 0:
                ptc = Pen(_color(R.COLORS["BangDaiTC"]), 1.2)
                ptc.DashStyle = DashStyle.Dash
                x = u0 + cov_d + 50.0
                while x <= u1 - cov_d:
                    if not any(fa < x < fb for _, _, fa, fb, _, _ in foots):
                        g.DrawLine(ptc, cv.T((x, cov_d)), cv.T((x, H - cov_d)))
                    x += atc
                lab = cv.T((u1, 0.5 * H))
                g.DrawString(u"T%d  đai TC Ø%.0f a%.0f" % (M.to_float(dai_tc[0].get("STT")), dtc, atc), font,
                             SolidBrush(_color(R.COLORS["BangDaiTC"])), float(lab.X + 10), float(lab.Y + 8))
        # thep doc + tang cuong + chong phinh
        r_bot = next((x for x in rows if x.get("ViTri") == "BangDuoi"), None)
        r_top = next((x for x in rows if x.get("ViTri") == "BangTren"), None)
        d_bot = M.to_float(r_bot.get("D")) if r_bot else 0.0
        d_top = M.to_float(r_top.get("D")) if r_top else 0.0
        for r in rows:
            vt = r.get("ViTri")
            if vt not in ("BangDuoi", "BangTren", "BangDuoiTC", "BangTrenTC", "BangChongPhinh"):
                continue
            d, n = M.to_float(r.get("D")), int(M.to_float(r.get("SoThanh")))
            if d <= 0 or n <= 0:
                continue
            cov = R.row_cover(r, self.rules)
            pen_w = float(min(max(d * cv.k * cv.ky, 2.0), 4.0))
            if vt in ("BangDuoi", "BangTren"):
                z = (cov + dd + d / 2.0) if vt == "BangDuoi" else (H - cov - dd - d / 2.0)
                pa, pb = cv.T((u0 + cov, z)), cv.T((u1 - cov, z))
                p_main = Pen(_color(R.COLORS[vt]), pen_w)
                g.DrawLine(p_main, pa, pb)
                # Moc neo 90 do 2 dau vao goi/dai (Tren: be xuong, Duoi: be len)
                hk_px = 14.0 if vt == "BangTren" else -14.0
                g.DrawLine(p_main, pa.X, pa.Y, pa.X, pa.Y + hk_px)
                g.DrawLine(p_main, pb.X, pb.Y, pb.X, pb.Y + hk_px)
                g.DrawString(u"T%d  %dØ%.0f (+móc)" % (M.to_float(r.get("STT")), n, d), font, SolidBrush(_color(R.COLORS[vt])),
                             float(pb.X + 10), float(pb.Y - 8))
            elif vt == "BangTrenTC":
                # Phan luc nen day len -> tang cuong lop tren o GIUA NHIP
                gap = max(self.rules["clear_min"], d_top, d)
                z = H - cov - dd - d_top - gap - d / 2.0
                pa, pb = cv.T((u0 + 0.22 * L, z)), cv.T((u1 - 0.22 * L, z))
                g.DrawLine(Pen(_color(R.COLORS[vt]), pen_w), pa, pb)
                g.DrawString(u"T%d  %dØ%.0f (TC nhịp)" % (M.to_float(r.get("STT")), n, d), font, SolidBrush(_color(R.COLORS[vt])),
                             float(cv.T((u1, z)).X + 10), float(pb.Y - 6))
            elif vt == "BangDuoiTC":
                # Phan luc nen + tai cot -> tang cuong lop duoi o VUNG GOI
                gap = max(self.rules["clear_min"], d_bot, d)
                z = cov + dd + d_bot + gap + d / 2.0
                p_btc = Pen(_color(R.COLORS[vt]), pen_w)
                for ua, ub in ((u0 + cov, u0 + 0.28 * L), (u1 - 0.28 * L, u1 - cov)):
                    q0, q1 = cv.T((ua, z)), cv.T((ub, z))
                    g.DrawLine(p_btc, q0, q1)
                q_end = cv.T((u1 - cov, z))
                g.DrawLine(p_btc, cv.T((u0 + cov, z)).X, cv.T((u0 + cov, z)).Y, cv.T((u0 + cov, z)).X, cv.T((u0 + cov, z)).Y - 12.0)
                g.DrawLine(p_btc, q_end.X, q_end.Y, q_end.X, q_end.Y - 12.0)
                g.DrawString(u"T%d  %dØ%.0f (TC gối)" % (M.to_float(r.get("STT")), n, d), font, SolidBrush(_color(R.COLORS[vt])),
                             float(q_end.X + 10), float(q_end.Y - 6))
            elif vt == "BangChongPhinh":
                z = 0.5 * H
                pcp = Pen(_color(R.COLORS[vt]), 1.6)
                pcp.DashStyle = DashStyle.DashDot
                pa, pb = cv.T((u0 + cov, z)), cv.T((u1 - cov, z))
                g.DrawLine(pcp, pa, pb)
        # vi tri cac mat cat ngang
        cuts, ca, cb = self._cut_positions(foots, u0, u1)
        cpen = Pen(th["hl"], 1.6)
        cpen.DashStyle = DashStyle.DashDot
        bold = Font(FONT, 10.0, FontStyle.Bold)
        for lab, u in cuts:
            ta, tb = cv.T((u, -lt - 0.05 * H)), cv.T((u, H + 0.4 * colh))
            g.DrawLine(cpen, ta, tb)
            g.DrawLine(Pen(th["hl"], 2.4), float(tb.X), float(tb.Y), float(tb.X + 14), float(tb.Y))
            g.DrawLine(Pen(th["hl"], 2.4), float(ta.X), float(ta.Y), float(ta.X + 14), float(ta.Y))
            g.DrawString(lab, bold, SolidBrush(th["hl"]), float(tb.X - 12), float(tb.Y - 20))
        # goi (neu chua tim thay dai thi ghi theo ten)
        if loai == "DamMong" and not foots and rec.get("NoiDai"):
            ends = (u"%s" % rec.get("NoiDai")).split(u" - ")
            p0, p1 = cv.T((u0, H)), cv.T((u1, H))
            if len(ends) == 2:
                g.DrawString(u"gối: %s" % ends[0], font, SolidBrush(th["dim"]), float(p0.X), float(p0.Y - 20))
                t2 = u"gối: %s" % ends[1]
                g.DrawString(t2, font, SolidBrush(th["dim"]), float(p1.X - g.MeasureString(t2, font).Width), float(p0.Y - 20))
        # kich thuoc
        zd = min([-lt] + [x[4] - lt for x in foots])
        a, b = cv.T((u0, zd)), cv.T((u1, zd))
        inter = ((a.X + b.X) / 2.0, cv.T((0, H / 2.0)).Y)
        draw_dim(g, a, b, inter, 30.0, u"%.0f" % L, th, font)
        if foots and cb - ca > 1.0 and (ca > u0 + 1.0 or cb < u1 - 1.0):
            draw_dim(g, cv.T((ca, zd)), cv.T((cb, zd)), inter, 54.0, u"%.0f (thông thủy giữa hai gối)" % (cb - ca), th, font)
        xl = min([u0] + [x[2] for x in foots]) - lo
        draw_dim(g, cv.T((xl, 0)), cv.T((xl, H)), inter, 30.0, u"%.0f" % H, th, font)
        if lt > 0:
            q = cv.T((u0, -lt))
            g.DrawString(u"BT lót dày %.0f, chìa %.0f" % (lt, lo), font, SolidBrush(th["dim"]), float(q.X), float(q.Y + 3))

    def show(self):
        self.f.ShowDialog()

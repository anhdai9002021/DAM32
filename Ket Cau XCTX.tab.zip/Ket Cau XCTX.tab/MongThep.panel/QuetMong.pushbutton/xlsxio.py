# -*- coding: utf-8 -*-
"""Doc / ghi file .xlsx bang thu vien chuan cua Python (khong can openpyxl)."""
import os
import re
import zipfile
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

_M = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_PR = "http://schemas.openxmlformats.org/package/2006/relationships"

_ILLEGAL = re.compile(u"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _col_name(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _col_index(ref):
    letters = re.match(r"[A-Za-z]+", ref).group(0).upper()
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def _cell_xml(ref, v, style):
    st = ' s="%d"' % style if style else ""
    if v is None or v == "":
        return '<c r="%s"%s/>' % (ref, st) if style else ""
    if isinstance(v, bool):
        return '<c r="%s"%s t="b"><v>%d</v></c>' % (ref, st, 1 if v else 0)
    if isinstance(v, int):
        return '<c r="%s"%s><v>%d</v></c>' % (ref, st, v)
    if isinstance(v, float):
        if v != v or v in (float("inf"), float("-inf")):
            return ""
        return '<c r="%s"%s><v>%s</v></c>' % (ref, st, format(v, ".10g"))
    text = escape(_ILLEGAL.sub("", u"%s" % v))
    return ('<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
            % (ref, st, text))


def _sheet_xml(rows, header=True):
    ncols = max([len(r) for r in rows] + [1])
    widths = [8] * ncols
    for r in rows[:200]:
        for j, v in enumerate(r):
            if v is None:
                continue
            w = len(u"%s" % v) + 2
            if w > widths[j]:
                widths[j] = min(w, 34)
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="%s" xmlns:r="%s">' % (_M, _R)]
    if header:
        out.append('<sheetViews><sheetView workbookViewId="0">'
                   '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
                   '</sheetView></sheetViews>')
    out.append("<cols>")
    for j, w in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (j + 1, j + 1, w))
    out.append("</cols><sheetData>")
    for i, r in enumerate(rows):
        cells = []
        style = 1 if (header and i == 0) else 0
        for j, v in enumerate(r):
            c = _cell_xml("%s%d" % (_col_name(j), i + 1), v, style)
            if c:
                cells.append(c)
        out.append('<row r="%d">%s</row>' % (i + 1, "".join(cells)))
    out.append("</sheetData></worksheet>")
    return "".join(out)


_STYLES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<styleSheet xmlns="%s">'
    '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
    '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
    '<fills count="3"><fill><patternFill patternType="none"/></fill>'
    '<fill><patternFill patternType="gray125"/></fill>'
    '<fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill></fills>'
    '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
    '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
    '</styleSheet>' % _M
)


def write_xlsx(path, sheets):
    """sheets: list[(ten_sheet, rows)], rows = list[list]. Dong dau la tieu de."""
    tmp = path + ".tmp"
    n = len(sheets)
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
              '<Default Extension="xml" ContentType="application/xml"/>',
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
              '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
        for i in range(n):
            ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" '
                      'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
        ct.append("</Types>")
        z.writestr("[Content_Types].xml", "".join(ct))
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="%s"><Relationship Id="rId1" '
                   'Type="%s/officeDocument" Target="xl/workbook.xml"/></Relationships>' % (_PR, _R))
        wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<workbook xmlns="%s" xmlns:r="%s"><sheets>' % (_M, _R)]
        rel = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
               '<Relationships xmlns="%s">' % _PR]
        for i, (name, rows) in enumerate(sheets):
            wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (escape(name), i + 1, i + 1))
            rel.append('<Relationship Id="rId%d" Type="%s/worksheet" Target="worksheets/sheet%d.xml"/>'
                       % (i + 1, _R, i + 1))
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), _sheet_xml(rows))
        wb.append("</sheets></workbook>")
        rel.append('<Relationship Id="rId%d" Type="%s/styles" Target="styles.xml"/></Relationships>' % (n + 1, _R))
        z.writestr("xl/workbook.xml", "".join(wb))
        z.writestr("xl/_rels/workbook.xml.rels", "".join(rel))
        z.writestr("xl/styles.xml", _STYLES)
    os.replace(tmp, path)


def _num(txt):
    try:
        f = float(txt)
    except Exception:
        return txt
    if f == int(f) and abs(f) < 1e15 and "." not in txt and "E" not in txt.upper():
        return int(f)
    return f


def read_xlsx(path):
    """Tra ve list[(ten_sheet, rows)] theo thu tu trong file."""
    z = zipfile.ZipFile(path)
    try:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("{%s}si" % _M):
                parts = []
                for node in si.iter():
                    if node.tag == "{%s}t" % _M:
                        parts.append(node.text or "")
                shared.append("".join(parts))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        targets = {}
        for r in rels:
            targets[r.get("Id")] = r.get("Target")
        result = []
        sheets = wb.find("{%s}sheets" % _M)
        for sh in sheets:
            name = sh.get("name")
            rid = sh.get("{%s}id" % _R)
            tgt = targets.get(rid, "")
            tgt = tgt.lstrip("/")
            if not tgt.startswith("xl/"):
                tgt = "xl/" + tgt
            if tgt not in names:
                continue
            root = ET.fromstring(z.read(tgt))
            grid = {}
            maxr = 0
            for row in root.iter("{%s}row" % _M):
                for c in row.findall("{%s}c" % _M):
                    ref = c.get("r")
                    if not ref:
                        continue
                    ri = int(re.search(r"\d+", ref).group(0)) - 1
                    ci = _col_index(ref)
                    t = c.get("t")
                    v = c.find("{%s}v" % _M)
                    val = None
                    if t == "inlineStr":
                        is_ = c.find("{%s}is" % _M)
                        if is_ is not None:
                            val = "".join((x.text or "") for x in is_.iter("{%s}t" % _M))
                    elif v is None or v.text is None:
                        val = None
                    elif t == "s":
                        try:
                            val = shared[int(v.text)]
                        except Exception:
                            val = None
                    elif t == "b":
                        val = bool(int(v.text))
                    elif t in ("str", "e"):
                        val = v.text
                    else:
                        val = _num(v.text)
                    if val is not None:
                        grid[(ri, ci)] = val
                        if ri > maxr:
                            maxr = ri
            rows = []
            if grid:
                maxc = max(c for (_, c) in grid)
                for ri in range(maxr + 1):
                    rows.append([grid.get((ri, ci)) for ci in range(maxc + 1)])
            result.append((name, rows))
        return result
    finally:
        z.close()

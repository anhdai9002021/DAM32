# -*- coding: utf-8 -*-
"""Cau noi voi Revit cho cua so khong chan (modeless): ExternalEvent + cua so chu."""
import os
import traceback
import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")
clr.AddReference("System.Windows.Forms")
import System
from System.Diagnostics import Process
from System.Windows.Forms import NativeWindow
from Autodesk.Revit.UI import IExternalEventHandler, ExternalEvent

LOG = os.path.join(os.path.expanduser('~'), 'Documents', 'BeamRebar', 'error.log')

try:
    _Handler                                  # reload: khong tao lai lop .NET
except NameError:
    class _Handler(IExternalEventHandler):
        __namespace__ = "BeamRebarToolsNS"
        jobs = []

        def Execute(self, uiapp):
            while _Handler.jobs:
                fn, args = _Handler.jobs.pop(0)
                try:
                    fn(uiapp, *args)
                except Exception:
                    log(traceback.format_exc())

        def GetName(self):
            return "BeamRebarTools"


def log(text):
    try:
        d = os.path.dirname(LOG)
        if not os.path.isdir(d):
            os.makedirs(d)
        open(LOG, 'a', encoding='utf-8').write(text + '\n')
    except Exception:
        pass


class Runner(object):
    """Chay ham trong ngu canh Revit API: runner.run(fn, *args) -> fn(uiapp, *args)."""

    def __init__(self):
        self.handler = _Handler()
        self.event = ExternalEvent.Create(self.handler)

    def run(self, fn, *args):
        _Handler.jobs.append((fn, args))
        self.event.Raise()


_RUNNER = [None]
_OWNER = [None]


def get_runner():
    """Phai goi lan dau trong ngu canh lenh pyRevit (truoc khi hien cua so)."""
    if _RUNNER[0] is None:
        try:
            _RUNNER[0] = Runner()
        except Exception:
            _RUNNER[0] = False
            log(traceback.format_exc())
    return _RUNNER[0] or None


def owner_window():
    """Cua so chu = cua so chinh cua Revit (de cua so cong cu luon noi tren Revit)."""
    if _OWNER[0] is None:
        try:
            nw = NativeWindow()
            nw.AssignHandle(Process.GetCurrentProcess().MainWindowHandle)
            _OWNER[0] = nw
        except Exception:
            _OWNER[0] = False
    return _OWNER[0] or None

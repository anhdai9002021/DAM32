# -*- coding: utf-8 -*-
"""Mo hinh nhom thep dam + hinh hoc (thuan Python, don vi mm).
Moi nhom thep = n thanh Ø d, o vi tri Tren/Duoi/Giua, lop k, chay tu goi a den goi b; moi dau co kieu rieng.
build() tra ve cac duong gap khuc (polyline) dung chung cho ve man hinh va thong ke.
LUU Y: buoc xuat LISP sang CAD CHUA duoc viet - build() la nguon hinh hoc de sau nay sinh LISP."""
import math
import re

POS = [u'Trên', u'Dưới', u'Giữa']
K_NEO, K_HET, K_GAP, K_EXT, K_MID, K_UON, K_CUT = (u'Neo vào gối', u'Hết cột / đầu dầm', u'Gập vào cột',
                                                  u'Kéo dài ra nhịp', u'Giữa gối', u'Uốn xiên',
                                                  u'Cắt trong nhịp')
KINDS = [K_NEO, K_HET, K_GAP, K_EXT, K_CUT, K_MID, K_UON]
X_AUTO, X_NEO, X_BEND, X_STR = u'Tự động', u'Luôn neo (cắt)', u'Luôn uốn', u'Luôn thẳng (nối liền)'
CROSS = [X_AUTO, X_NEO, X_BEND, X_STR]

DEFAULT_OPT = dict(cover=30.0, neo=u'30d', gap=u'xuống', ext=u'L/3', straight=0.0, thr=100.0, slope=6.0,
                   stir=8.0, pitch=25.0, short=1500.0, zone_top=u'L/4', zone_bot=u'L/6',
                   merge_on=0.0, merge_gap=1200.0, near=800.0,
                   tct1_on=0.0, tct1_n=1.0, tct1_d=0.0, tcb1_on=0.0, tcb1_n=1.0, tcb1_d=0.0,      # tang cuong lop 1 tren / duoi (d = 0: giong thep chu)
                   tct2_on=0.0, tct2_n=2.0, tct2_d=0.0, tcb2_on=0.0, tcb2_n=2.0, tcb2_d=0.0,
                   # ---- TCVN 5574:2018
                   skin_on=1.0, skin_h=700.0, skin_s=400.0, skin_d=12.0, skin_ratio=0.1,   # thep than (chong phinh): h > skin_h, s <= skin_s, As >= skin_ratio% * s * max(b/2, 200)
                   tcvn_stir=1.0, stir_a0=50.0,          # 10.3.4.3: kep khoang cach dai (h0 = h - stir_a0)
                   hang_on=1.0, hang_a=50.0,             # 10.4.12: dai bo sung cho dam phu gac len dam chinh, dai b + 2h
                   leg_b=400.0, leg_n=5.0,               # dai 4 nhanh khi b >= leg_b hoac > leg_n thanh / lop
                   # gioi han dai (mac dinh cho be tong < B70); B70-B100 chat hon -> nhap theo tieu chuan du an o tab Thiet lap
                   stir_dmin=6.0, stir_a1=300.0, stir_a2=500.0,
                   # ---- be neo vao cot
                   tc_hook=1.0,        # thep tang cuong ket thuc o cot bien -> be neo vao cot (tren be xuong / duoi be len), bang chieu cao dam
                   hook_clr=20.0)      # khoang ho giua chan BE LEN (thep duoi) va chan BE XUONG (thep tren): theo phuong ngang va dau mut chan be toi thanh doi dien (mm, co o nhap)
HEADER = [u'Dầm', u'STT', u'Vị trí', u'Lớp', u'SL', u'Ø', u'Từ gối', u'Đầu trái', u'Giá trị trái',
          u'Đến gối', u'Đầu phải', u'Giá trị phải', u'Qua gối đổi tiết diện', u'Ghi chú']

_D = re.compile(r'^(\d+(?:\.\d+)?)[dDØø]$')
_LD = re.compile(r'^[Ll]/(\d+(?:\.\d+)?)$')
_FL = re.compile(r'^(\d+(?:\.\d+)?)[Ll]$')


def parse_len(txt, d, L, default=''):
    """'30d' -> 30*d | 'L/3' -> L/3 | '0.3L' | '1500' (mm)"""
    t = txt if (txt or '').strip() else default
    t = (t or '').strip().replace(',', '.').replace(' ', '')
    if not t:
        return 0.0
    for rx, f in ((_D, lambda v: v * d), (_LD, lambda v: L / v if v else 0.0), (_FL, lambda v: L * v)):
        m = rx.match(t)
        if m:
            return f(float(m.group(1)))
    try:
        return float(t)
    except ValueError:
        return 0.0


_DOWN = (u'xuống', u'xuong', u'h', u'sát', u'sat', u'down')


def is_down(t):
    return (t or '').strip().lower() in _DOWN


def len_valid(txt):
    t = (txt or '').strip().replace(',', '.').replace(' ', '')
    if not t:
        return True
    for part in t.split(';'):
        if not (is_down(part) or _D.match(part) or _LD.match(part) or _FL.match(part) or re.match(r'^\d+(\.\d+)?$', part)):
            return False
    return True


def new_group(**kw):
    g = dict(pos=POS[1], layer=1, n=2, d=16, a=0, b=1, lk=K_NEO, lv='', rk=K_NEO, rv='', cross=X_AUTO, note='')
    g.update(kw)
    return g


def layout(beam):
    sup, sp = beam['supports'], beam['spans']
    x, sx0, fl, fr = 0.0, [], [], []
    for k in range(len(sp) + 1):
        sx0.append(x)
        x += sup[k]['w']
        if k < len(sp):
            fl.append(x)
            x += sp[k]['clear']
            fr.append(x)
    return dict(n=len(sp), sx0=sx0, fl=fl, fr=fr, L=x, maxtop=max([s['top'] for s in sp] + [0.0]))


def span_y(lay, sp):
    """(y mat tren, y day) cua nhip, mm, truc y huong xuong, goc = dinh cao nhat."""
    t = lay['maxtop'] - sp['top']
    return t, t + sp['h']


def yline(lay, sp, pos, layer, d, opt):
    t, bt = span_y(lay, sp)
    if pos == POS[2]:
        return t + (bt - t) * {1: 0.5, 2: 1.0 / 3, 3: 2.0 / 3}.get(int(layer), 0.5)
    off = opt['cover'] + opt['stir'] + d / 2.0 + (layer - 1) * (d + opt['pitch'])
    return t + off if pos == POS[0] else bt - off


def cross_modes(g, ys, s0, s1, opt):
    """Che do qua tung goi trung gian: 'straight' | 'jog' | 'split'."""
    modes = {}
    mode = g.get('cross') or X_AUTO
    for j in range(s0, s1):
        dy = abs(ys[j + 1] - ys[j])
        if mode == X_NEO:
            m = 'split'
        elif mode == X_STR:
            m = 'straight'
        elif mode == X_BEND:
            m = 'jog' if dy >= 0.5 else 'straight'
        else:
            m = 'straight' if dy <= opt['straight'] + 1e-6 else ('jog' if dy <= opt['thr'] + 1e-6 else 'split')
        modes[j] = m
    return modes


def gap_leg(txt, d, opt, lay, sp_i, pos, y0, tip=None):
    """Chieu dai doan gap vao cot. 'xuong' (= 'Bang dam') = be het chieu cao dam, toi ngay tren lop thep phia doi dien.
    tip = cao do (y, mm) dau mut be da tinh san (xem _tip_y); None = tinh theo 1 lop thep doi dien cung duong kinh.
    Gia tri so (mm) luon bi chan tren boi chieu cao dam HIEN TAI -> sua cote / tiet dien thi neo khong thua ra ngoai dam."""
    t = (txt or '').strip() or opt['gap']
    top, bt = span_y(lay, sp_i)
    cov, sd = opt['cover'], opt['stir']
    if tip is not None:
        full = (y0 - tip) if pos == POS[1] else (tip - y0)
    elif pos == POS[1]:
        full = y0 - (top + cov + sd + d + 25.0)
    else:
        full = (bt - cov - sd - d - 25.0) - y0
    full = max(full, 15.0 * d)
    if is_down(t):
        return full
    v = parse_len(t, d, 0)
    return min(v if v > 0 else 15.0 * d, full)


def _lan(d, opt):
    """Chieu dai doan neo l_an (cau tao): theo tuy chon 'neo' (mac dinh 30d), khong nho hon 200 mm."""
    return max(parse_len(opt.get('neo', u'30d'), d, 0.0), 200.0)


def _col_zones(beam, lay, d, opt):
    """Vat can ma thep tang cuong phai lao qua: cot cay len dam va dam phu gac len dam.
    Moi vat can -> (mep trai, mep phai, mep trai - l_an, mep phai + l_an) tren truc x ban ve."""
    lan = _lan(d, opt)
    out = []
    for i, s in enumerate(beam['spans']):
        for q in s.get('planted') or []:
            w = float(q.get('w') or 0.0)
            xm = lay['fl'][i] + float(q['pos'])
            out.append((xm - w / 2.0, xm + w / 2.0, xm - w / 2.0 - lan, xm + w / 2.0 + lan))
    for k, su in enumerate(beam['supports']):
        if su.get('kind') == u'Dầm' and u'Dầm phụ' in (su.get('role') or '') and su.get('w', 0.0) > 0.5:
            out.append((lay['sx0'][k], lay['sx0'][k] + su['w'], lay['sx0'][k] - lan, lay['sx0'][k] + su['w'] + lan))
    return out


def _cover_end(zones, lay, x, side, near=0.0):
    """Dau tu do cua thanh tang cuong gan vat can (cot cay / dam phu) -> lao ra qua vat can va neo l_an.
    Keo khi dau thanh: (a) da roi vao vung [mep - l_an, mep + l_an], hoac (b) cach vat can <= near (mm).
    Chi keo DAI them, khong bao gio rut ngan; khong vuot ra ngoai dam."""
    for _ in range(len(zones) + 1):
        moved = False
        for c0, c1, z0, z1 in zones:
            trig = max(near, c0 - z0)
            if side == 'R' and c0 - trig < x < z1 - 1.0:
                nx = min(z1, lay['L'])
            elif side == 'L' and z0 + 1.0 < x < c1 + trig:
                nx = max(z0, 0.0)
            else:
                continue
            if (side == 'L' and nx < x - 0.5) or (side == 'R' and nx > x + 0.5):
                x, moved = nx, True
        if not moved:
            break
    return x


def _ends(g, beam, opt, lay=None):
    """Hai dau cua nhom thep sau khi 'hieu' (dung chung cho build va kiem tra 2 neo de len nhau).
    Tra ve {'L': (kieu, gia_tri, co_be_neo, chi_so_goi), 'R': (...)}.
    Thep TANG CUONG (hoac lop >= 2) ket thuc o COT BIEN (goi dau / goi cuoi dam) -> doi thanh 'Gap vao cot' (be bang chieu cao dam).
    Tat bang opt['tc_hook'] = 0."""
    lay = lay or layout(beam)
    sp, sup, n = beam['spans'], beam['supports'], lay['n']
    d, pos = float(g['d']), g['pos']
    a, b = int(g['a']), int(g['b'])
    near = float(opt.get('near') or 0.0)

    def cl(i):
        return sp[i]['clear'] if 0 <= i < n else 0.0

    def real(k):
        return (0 <= k <= n and sup[k].get('kind') in (u'Cột', u'Dầm') and sup[k]['w'] > 0.5
                and u'Dầm phụ' not in (sup[k].get('role') or ''))
    tc = bool(opt.get('tc_hook', 1.0)) and pos != POS[2] and (is_tc(g) or int(g['layer']) >= 2)      # tang cuong / thep lop 2, 3...
    out = {}
    for side in ('L', 'R'):
        if side == 'L':
            k, kk, v, edge, ci = a, g['lk'], g['lv'], a == 0, a
        else:
            k, kk, v, edge, ci = b, g['rk'], g['rv'], b == n, b - 1
        if kk == K_EXT and edge:
            kk = K_HET
        if kk == K_CUT and near > 0 and real(k) and parse_len(v, d, cl(ci), 'L/4') <= near + 0.5:
            kk, v = K_NEO, opt['neo']                 # dau tang cuong cat gan goi (<= near) -> vao luon cot / dam do
        hook = False
        if 0 <= k <= n:
            if kk == K_GAP:
                hook = True
            elif edge and pos != POS[2]:
                if tc and kk in (K_NEO, K_HET) and real(k):
                    kk, v, hook = K_GAP, opt['gap'], True
                elif (kk == K_NEO and sup[k]['w'] > 0.5
                      and parse_len(v, d, cl(ci), opt['neo']) > max(sup[k]['w'] - opt['cover'], 0.0) + 1.0):
                    hook = True                        # goi bien hep: keo het goi roi be phan con thieu
        out[side] = (kk, v, hook, k)
    return out


def _hook_x(lay, sup, side, k, d, layer, opt):
    off = opt['cover'] + d / 2.0 + (layer - 1) * (d + opt['pitch'])
    return lay['sx0'][k] + off if side == 'L' else lay['sx0'][k] + sup[k]['w'] - off


def _present(g2, E2, k):
    """Nhom g2 co thanh nam o goi k (di xuyen qua, hoac ket thuc o goi nay)?"""
    a2, b2 = int(g2['a']), int(g2['b'])
    if a2 < k < b2:
        return True
    ok = (K_NEO, K_HET, K_GAP, K_MID, K_EXT)
    return (k == a2 and E2['L'][0] in ok) or (k == b2 and E2['R'][0] in ok)


def _tip_y(g, beam, opt, lay, side, k, sp_i):
    """Cao do (y) dau mut cua doan be 'xuong' (= bang dam): thanh TREN be xuong toi ngay tren lop thep DUOI THUC TE dang co o goi
    (cach 25 mm); thanh DUOI be len toi cach lop thep TREN thuc te hook_clr (50 mm).  Khong co thanh doi dien -> tinh theo 1 lop."""
    sp = beam['spans'][sp_i]
    top, bt = span_y(lay, sp)
    cov, sd, d = opt['cover'], opt['stir'], float(g['d'])
    want = POS[0] if g['pos'] == POS[1] else POS[1]
    ys_ = []
    for g2 in beam.get('groups') or []:
        if g2 is g or g2['pos'] != want:
            continue
        if _present(g2, _ends(g2, beam, opt, lay), k):
            d2 = float(g2['d'])
            y2 = yline(lay, sp, want, int(g2['layer']), d2, opt)
            ys_.append(y2 + d2 / 2.0 if want == POS[0] else y2 - d2 / 2.0)
    if g['pos'] == POS[1]:
        return (max(ys_) + float(opt.get('hook_clr') or 20.0)) if ys_ else top + cov + sd + d + 25.0
    return (min(ys_) - float(opt.get('hook_clr') or 20.0)) if ys_ else bt - cov - sd - d - 25.0


def _hook_shift(g, beam, opt, lay, side, k):
    """Neo DUOI (be len) o cung goi voi neo TREN (be xuong): doi neo duoi vao phia trong (theo phuong ngang) de cach neo tren
    hook_clr (~50 mm) - hai neo khong de len nhau. Tra ve do dich (mm) cho cac thanh DUOI; thanh tren = 0."""
    groups = beam.get('groups') or []
    if g['pos'] != POS[1] or not groups:
        return 0.0
    cov, pitch = opt['cover'], opt['pitch']
    clr = float(opt.get('hook_clr') or 0.0)
    t_edge, b_min = None, None
    for g2 in groups:
        if g2['pos'] not in (POS[0], POS[1]):
            continue
        if g2 is not g:
            e2 = _ends(g2, beam, opt, lay)[side]
            if not e2[2] or e2[3] != k:
                continue
        d2 = float(g2['d'])
        off = cov + d2 / 2.0 + (int(g2['layer']) - 1) * (d2 + pitch)
        if g2['pos'] == POS[0]:
            t_edge = off + d2 / 2.0 if t_edge is None else max(t_edge, off + d2 / 2.0)
        else:
            b_min = off - d2 / 2.0 if b_min is None else min(b_min, off - d2 / 2.0)
    if t_edge is None or b_min is None:
        return 0.0
    return max(0.0, t_edge + clr - b_min)


def normalize_hooks(groups, beam, opt):
    """Goi TRUOC KHI doi cote / tiet dien (beam = du lieu dam CU): doan be dang so (mm) ma ~ bang chieu cao dam cu (>= 60%)
    -> doi thanh 'xuong' (= bang dam) de tu theo chieu cao moi. Doan be ngan hon thi giu so, nhung luon bi chan boi h moi.
    Tra ve so doan da doi."""
    lay = layout(beam)
    sp, n = beam['spans'], lay['n']
    cnt = 0
    if not n:
        return 0
    for g in groups:
        if g['pos'] == POS[2]:
            continue
        d = float(g['d'])
        for s in ('l', 'r'):
            if g[s + 'k'] != K_GAP:
                continue
            v = (g[s + 'v'] or '').strip()
            if not v or is_down(v):
                continue
            i = min(max(int(g['a']) if s == 'l' else int(g['b']) - 1, 0), n - 1)
            y0 = yline(lay, sp[i], g['pos'], int(g['layer']), d, opt)
            if parse_len(v, d, 0.0) >= 0.6 * gap_leg('xuống', d, opt, lay, sp[i], g['pos'], y0):
                g[s + 'v'] = u'xuống'
                cnt += 1
    return cnt


def build(g, beam, opt, lay=None):
    lay = lay or layout(beam)
    sp, sup, n = beam['spans'], beam['supports'], lay['n']
    pos, d, layer = g['pos'], float(g['d']), int(g['layer'])
    a, b = int(g['a']), int(g['b'])
    if n == 0 or a < 0 or b > n or a > b:
        return []
    lk, rk = g['lk'], g['rk']
    s0 = a - 1 if (lk == K_EXT and a > 0) else a
    s1 = b if (rk == K_EXT and b < n) else b - 1
    s0, s1 = min(max(s0, 0), n - 1), min(max(s1, 0), n - 1)
    if s0 > s1:
        return []
    cov = opt['cover']
    zones = _col_zones(beam, lay, d, opt)        # thep tang cuong (dau K_EXT / K_CUT): khong cat trong vung cot cay / dam phu
    near = float(opt.get('near') or 0.0)
    ys = dict((s, yline(lay, sp[s], pos, layer, d, opt)) for s in range(s0, s1 + 1))
    modes = cross_modes(g, ys, s0, s1, opt)
    j = s0                                   # cac nhip noi thang -> chay cung 1 cao do
    while j <= s1:
        k = j
        while k < s1 and modes[k] == 'straight':
            k += 1
        if k > j:
            vals = [ys[q] for q in range(j, k + 1)]
            yc = max(vals) if pos == POS[0] else (min(vals) if pos == POS[1] else sum(vals) / len(vals))
            for q in range(j, k + 1):
                ys[q] = yc
        j = k + 1
    sign = -1.0 if pos == POS[1] else 1.0     # gap: thep tren/giua gap xuong, thep duoi gap len
    opp = POS[0] if pos == POS[1] else POS[1]

    def xL(k):
        return lay['sx0'][k]

    def xR(k):
        return lay['sx0'][k] + sup[k]['w']

    def cl(i):
        return sp[i]['clear'] if 0 <= i < n else 0.0

    def cap(k):
        return max(sup[k]['w'] - cov, 0.0)

    def real_sup(k):          # goi that de neo vao: cot hoac dam do (khong tinh dam phu gac len, goi ao, dau tu do)
        return (0 <= k <= n and sup[k].get('kind') in (u'Cột', u'Dầm') and sup[k]['w'] > 0.5
                and u'Dầm phụ' not in (sup[k].get('role') or ''))

    # ---- dau trai
    E = _ends(g, beam, opt, lay)             # kieu dau sau khi 'hieu' (gom: tang cuong o cot bien -> be neo vao cot)
    kk, glv, hk_l, _kl = E['L']
    y0 = ys[s0]
    tip_l = _tip_y(g, beam, opt, lay, 'L', a, s0) if (hk_l and pos != POS[2] and 0 <= a < n) else None
    sh_l = _hook_shift(g, beam, opt, lay, 'L', a) if (hk_l and 0 <= a <= n) else 0.0

    def hx(side, k, sh):                       # vi tri x cua doan be: lop trong be long ben trong lop ngoai; neo duoi dich them sh
        off = cov + d / 2.0 + (layer - 1) * (d + opt['pitch']) + sh
        if sh > 0 and sup[k]['w'] > 0.5:
            off = min(off, max(sup[k]['w'] - cov - d / 2.0, cov + d / 2.0))
        return xL(k) + off if side == 'L' else xR(k) - off
    if kk == K_NEO:
        need = parse_len(glv, d, cl(a), opt['neo'])
        if a == 0 and pos != POS[2] and sup[a]['w'] > 0.5 and need > cap(a) + 1.0:
            # gối biên không đủ chỗ neo thẳng l_an -> neo hết bề rộng gối rồi bẻ mỏ phần còn thiếu (>= 15d)
            xh = hx('L', a, sh_l)
            leg = min(max(need - cap(a), 15.0 * d), gap_leg('xuống', d, opt, lay, sp[s0], pos, y0, tip_l))
            pts = [(xh, y0 + sign * leg), (xh, y0)]
        else:
            pts = [(xR(a) - min(need, cap(a)), y0)]
    elif kk == K_HET:
        pts = [(xL(a) + cov, y0)]
    elif kk == K_MID:
        pts = [(xL(a) + sup[a]['w'] / 2.0, y0)]
    elif kk == K_EXT:
        pts = [(xL(a) - parse_len(g['lv'], d, cl(a - 1), opt['ext']), y0)]
    elif kk == K_CUT:
        pts = [(xR(a) + parse_len(g['lv'], d, cl(a), 'L/4'), y0)]
    elif kk == K_GAP:
        x = hx('L', a, sh_l)
        pts = [(x, y0 + sign * gap_leg(glv, d, opt, lay, sp[s0], pos, y0, tip_l)), (x, y0)]
    else:   # uon xieng
        v = (g['lv'] or '').split(';')
        e = parse_len(v[0], d, cl(a), 'L/6')
        e2 = parse_len(v[1] if len(v) > 1 else '', d, cl(a - 1), 'L/4')
        yo = yline(lay, sp[s0], opp, 2, d, opt)
        xs = xR(a) + e
        pts = [((xL(a) - e2) if a > 0 else xL(a) + cov, yo), (xs - abs(yo - y0), yo), (xs, y0)]
    if kk in (K_EXT, K_CUT):                      # dau tu do trong nhip roi vao vung cot cay -> keo trum het vung
        pts[0] = (_cover_end(zones, lay, pts[0][0], 'L', near), pts[0][1])
    # ---- dau phai
    kk, grv, hk_r, _kr = E['R']
    y1 = ys[s1]
    tip_r = _tip_y(g, beam, opt, lay, 'R', b, s1) if (hk_r and pos != POS[2] and 0 < b <= n) else None
    sh_r = _hook_shift(g, beam, opt, lay, 'R', b) if (hk_r and 0 <= b <= n) else 0.0
    if kk == K_NEO:
        need = parse_len(grv, d, cl(b - 1), opt['neo'])
        if b == n and pos != POS[2] and sup[b]['w'] > 0.5 and need > cap(b) + 1.0:
            xh = hx('R', b, sh_r)
            leg = min(max(need - cap(b), 15.0 * d), gap_leg('xuống', d, opt, lay, sp[s1], pos, y1, tip_r))
            rp = [(xh, y1), (xh, y1 + sign * leg)]
        else:
            rp = [(xL(b) + min(need, cap(b)), y1)]
    elif kk == K_HET:
        rp = [(xR(b) - cov, y1)]
    elif kk == K_MID:
        rp = [(xL(b) + sup[b]['w'] / 2.0, y1)]
    elif kk == K_EXT:
        rp = [(xR(b) + parse_len(g['rv'], d, cl(b), opt['ext']), y1)]
    elif kk == K_CUT:
        rp = [(xL(b) - parse_len(g['rv'], d, cl(b - 1), 'L/4'), y1)]
    elif kk == K_GAP:
        x = hx('R', b, sh_r)
        rp = [(x, y1), (x, y1 + sign * gap_leg(grv, d, opt, lay, sp[s1], pos, y1, tip_r))]
    else:
        v = (g['rv'] or '').split(';')
        e = parse_len(v[0], d, cl(b - 1), 'L/6')
        e2 = parse_len(v[1] if len(v) > 1 else '', d, cl(b), 'L/4')
        yo = yline(lay, sp[s1], opp, 2, d, opt)
        xs = xL(b) - e
        rp = [(xs, y1), (xs + abs(yo - y1), yo), ((xR(b) + e2) if b < n else xR(b) - cov, yo)]
    if kk in (K_EXT, K_CUT):
        rp[-1] = (_cover_end(zones, lay, rp[-1][0], 'R', near), rp[-1][1])
    # ---- than: qua cac goi trung gian
    lines, cur = [], list(pts)
    for j in range(s0, s1):
        k = j + 1
        yl, yr = ys[j], ys[j + 1]
        dy = abs(yr - yl)
        m = modes[j]
        if m == 'split' and pos != POS[2] and dy >= 0.5:
            # LECH COTE > nguong: thanh o dam TO (cao do nam ngoai tiet dien dam kia) BE vao cot (tren xuong / duoi len);
            # thanh o dam BE XUYEN qua goi vao dam to them 1 doan noi l_an (theo tuy chon 'Neo tieu chuan', TCVN).
            La = _lan(d, opt)
            poker_left = (yl > yr) if pos == POS[0] else (yl < yr)
            off = cov + d / 2.0 + (layer - 1) * (d + opt['pitch'])
            if poker_left:                                    # nhip trai la dam be: xuyen sang phai
                cur.append((min(xR(k) + La, lay['fr'][k]), yl))
                lines.append(cur)
                xh = min(xL(k) + off, xR(k))                  # nhip phai la dam to: keo het goi roi be
                cur = [(xh, yr + sign * gap_leg('xuống', d, opt, lay, sp[j + 1], pos, yr)), (xh, yr)]
            else:                                             # nhip trai la dam to: keo het goi roi be; nhip phai xuyen sang trai
                xh = max(xR(k) - off, xL(k))
                cur.append((xh, yl))
                cur.append((xh, yl + sign * gap_leg('xuống', d, opt, lay, sp[j], pos, yl)))
                lines.append(cur)
                cur = [(max(xL(k) - La, lay['fl'][j]), yr)]
        elif m == 'split':
            La = parse_len(opt['neo'], d, 0)
            av = cap(k)
            if sup[k]['w'] <= 0.5:                    # cho doi tiet dien (khong co goi): noi thang, chong 2 thanh qua cho doi
                cur.append((xL(k) + La, yl))
                lines.append(cur)
                cur = [(xR(k) - La, yr)]
            elif La <= av + 1e-6:                       # du cho: neo thang 30d vao goi
                cur.append((xL(k) + La, yl))
                lines.append(cur)
                cur = [(xR(k) - La, yr)]
            else:                                     # goi hep: keo het goi roi gap phan con thieu (>= 15d)
                legl = min(max(La - av, 15.0 * d), gap_leg('xuống', d, opt, lay, sp[j], pos, yl))
                legr = min(max(La - av, 15.0 * d), gap_leg('xuống', d, opt, lay, sp[j + 1], pos, yr))
                cur.append((xL(k) + av, yl))
                cur.append((xL(k) + av, yl + sign * legl))
                lines.append(cur)
                cur = [(xR(k) - av, yr + sign * legr), (xR(k) - av, yr)]
        elif m == 'jog' and dy >= 0.5:
            xc = (xL(k) + xR(k)) / 2.0
            run = opt['slope'] * dy
            cur.append((xc - run / 2.0, yl))
            cur.append((xc + run / 2.0, yr))
    cur.extend(rp)
    lines.append(cur)
    out = []
    for ln in lines:
        q = [ln[0]]
        for p in ln[1:]:
            if abs(p[0] - q[-1][0]) > 0.01 or abs(p[1] - q[-1][1]) > 0.01:
                q.append(p)
        if len(q) > 1:
            out.append(q)
    return out


def cross_report(g, beam, opt, lay=None):
    """Mo ta ket qua qua tung goi trung gian: 'G1: uon 80; G2: neo 170'."""
    lay = lay or layout(beam)
    n, sp = lay['n'], beam['spans']
    a, b = int(g['a']), int(g['b'])
    if n == 0 or a < 0 or b > n or a > b:
        return u''
    s0 = a - 1 if (g['lk'] == K_EXT and a > 0) else a
    s1 = b if (g['rk'] == K_EXT and b < n) else b - 1
    s0, s1 = min(max(s0, 0), n - 1), min(max(s1, 0), n - 1)
    if s0 >= s1:
        return u''
    d = float(g['d'])
    ys = dict((q, yline(lay, sp[q], g['pos'], int(g['layer']), d, opt)) for q in range(s0, s1 + 1))
    modes = cross_modes(g, ys, s0, s1, opt)
    nm = {'straight': u'thẳng liền', 'jog': u'uốn', 'split': u'cắt (dầm to bẻ, dầm bé xuyên vào dầm to)'}
    out = []
    for j in range(s0, s1):
        dy = round(abs(ys[j + 1] - ys[j]))
        out.append(u'G%d: %s%s' % (j + 1, nm[modes[j]], (u' (lệch %d)' % dy) if dy else u''))
    return u'; '.join(out)


def length(lines):
    return sum(math.hypot(q[i + 1][0] - q[i][0], q[i + 1][1] - q[i][1]) for q in lines for i in range(len(q) - 1))


def parse_spec(s):
    m = re.match(r'^\s*(\d+)\s*[TtØøΦφ]\s*(\d+)\s*$', s or '')
    return (int(m.group(1)), int(m.group(2))) if m else None


def describe(g, ln):
    return u'%dØ%d %s lớp %d  L=%d mm' % (int(g['n']), int(g['d']), g['pos'], int(g['layer']), round(length(ln)))


# =====================================================================================
#  Tu hieu net but: net ve (toa do mm) -> nhom thep
# =====================================================================================
def _r10(v):
    return str(int(round(max(v, 0.0) / 10.0) * 10))


def _where(lay, su, x, tol=40.0):
    ns = lay['n']
    for k in range(ns + 1):
        if su[k]['w'] > 0 and lay['sx0'][k] - tol <= x <= lay['sx0'][k] + su[k]['w'] + tol:
            return ('sup', k)
    for j in range(ns):
        if lay['fl'][j] < x < lay['fr'][j]:
            return ('span', j)
    return ('out', 0 if x < 0 else ns)


def _left_end(lay, su, opt, x, xr_eff, hook):
    w = _where(lay, su, x)
    cov = opt['cover']
    if w[0] == 'sup':
        k = w[1]
        if x <= lay['sx0'][k] + cov + 40.0:
            return k, (K_GAP if hook else K_HET), (opt['gap'] if hook else '')
        return k, K_NEO, _r10(lay['sx0'][k] + su[k]['w'] - x)
    if w[0] == 'out':
        return w[1], (K_GAP if hook else K_HET), (opt['gap'] if hook else '')
    j = w[1]
    if xr_eff > lay['fr'][j] + 50.0:
        return j + 1, K_EXT, _r10(lay['fr'][j] - x)
    return j, K_CUT, _r10(x - lay['fl'][j])


def _right_end(lay, su, opt, x, xl_eff, hook):
    w = _where(lay, su, x)
    cov = opt['cover']
    if w[0] == 'sup':
        k = w[1]
        if x >= lay['sx0'][k] + su[k]['w'] - cov - 40.0:
            return k, (K_GAP if hook else K_HET), (opt['gap'] if hook else '')
        return k, K_NEO, _r10(x - lay['sx0'][k])
    if w[0] == 'out':
        return w[1], (K_GAP if hook else K_HET), (opt['gap'] if hook else '')
    j = w[1]
    if xl_eff < lay['fl'][j] - 50.0:
        return j, K_EXT, _r10(x - lay['fl'][j])
    return j + 1, K_CUT, _r10(lay['fr'][j] - x)


def _span_at(lay, x):
    best, bd = 0, 1e18
    for i in range(lay['n']):
        if lay['fl'][i] <= x <= lay['fr'][i]:
            return i
        dd = min(abs(x - lay['fl'][i]), abs(x - lay['fr'][i]))
        if dd < bd:
            best, bd = i, dd
    return best


def _peel_leg(seq, d):
    """Tach doan thang dung o CUOI net ve (thep be vao cot). Tra ve (than, dy co dau, x_cua_doan) hoac (seq, None, None)."""
    if len(seq) < 5:
        return seq, None, None
    j = len(seq) - 1
    x0 = seq[-1][0]
    while j > 0 and abs(seq[j - 1][0] - x0) <= 45.0:
        j -= 1
    dy = seq[-1][1] - seq[j][1]
    if len(seq) - j >= 3 and j >= 2 and abs(dy) >= max(120.0, 4.0 * d):
        return seq[:j + 1], dy, x0
    return seq, None, None


def _clear(lay, sp, i):
    return sp[i]['clear'] if 0 <= i < lay['n'] else 0.0


def _snap_standard(g, beam, opt, lay, full):
    """Che do but 'bam tieu chuan': vung tang cuong tren = L/4, tang cuong duoi theo tieu chuan, ve het dam = lop 2,3,4."""
    sp = beam['spans']
    d = float(g['d'])
    if g['pos'] == POS[2]:
        return g
    if full:
        g['layer'] = max(2, int(g['layer']))
        return g
    for side in ('l', 'r'):
        kk, vv, sup = g[side + 'k'], g[side + 'v'], g['a'] if side == 'l' else g['b']
        try:
            raw = float(vv)
        except (TypeError, ValueError):
            raw = None
        if g['pos'] == POS[0]:
            if kk == K_EXT and raw is not None:
                cl = _clear(lay, sp, sup - 1 if side == 'l' else sup)
                if raw <= parse_len(opt['zone_top'], d, cl) * 1.3:
                    g[side + 'v'] = opt['zone_top']
        else:
            if kk == K_CUT and raw is not None:
                cl = _clear(lay, sp, sup if side == 'l' else sup - 1)
                std = parse_len(opt['zone_bot'], d, cl)
                if std > 0 and abs(raw - std) <= 0.4 * std:
                    g[side + 'v'] = opt['zone_bot']
            elif kk == K_NEO and raw is not None:
                std = parse_len(opt['neo'], d, 0)
                if std > 0 and abs(raw - std) <= 0.3 * std:
                    g[side + 'v'] = opt['neo']
    if g['pos'] == POS[0] or (g['pos'] == POS[1] and (g['lk'] in (K_CUT, K_EXT) or g['rk'] in (K_CUT, K_EXT))):
        g['layer'] = max(2, int(g['layer']))        # tang cuong khong nam o lop 1 (lop 1 la thep chu)
    return g


def infer_group(beam, opt, pts, n, d, hook=False, snap=False, layer_force=0):
    """Nhom thep tu net ve tay. pts = [(x_mm, y_mm)] THEO THU TU VE; tra ve dict nhom hoac None.
    Nhan: thep thang, thep uon xieng, thep be vao cot (doan thang dung o dau net ve)."""
    lay = layout(beam)
    sp, su, ns = beam['spans'], beam['supports'], lay['n']
    if len(pts) < 2 or ns == 0:
        return None
    # ---- thep be vao cot: tach doan thang dung o hai dau net ve
    body, dy_e, x_e = _peel_leg(list(pts), d)
    body, dy_s, x_s = _peel_leg(list(reversed(body)), d)
    body = list(reversed(body))
    legs = []                                    # [(x_cua_doan, dy)]
    if dy_e is not None:
        legs.append((x_e, dy_e))
    if dy_s is not None:
        legs.append((x_s, dy_s))
    pts = sorted(body, key=lambda p: p[0])
    xs = [p[0] for p in pts]
    xl, xr = xs[0], xs[-1]
    if xr - xl < 150.0:
        return None
    ys = [p[1] for p in pts]
    im = _span_at(lay, (xl + xr) / 2.0)
    t, bt = span_y(lay, sp[im])
    h = bt - t
    ymid = t + h / 2.0
    cov = opt['cover']
    k20 = max(len(pts) // 5, 1)
    y_last = sum(ys[-k20:]) / k20
    above = [p for p in pts if p[1] < ymid - 0.18 * h]
    below = [p for p in pts if p[1] > ymid + 0.18 * h]
    bent = len(above) >= 3 and len(below) >= 3 and min(ys) < ymid - 0.3 * h and max(ys) > ymid + 0.3 * h
    g = new_group(n=int(n), d=int(d))
    if not bent:
        ymed = sorted(ys)[len(ys) // 2]
        if abs(ymed - ymid) < 0.10 * h:
            g['pos'], off = POS[2], 0.0
        elif ymed < ymid:
            g['pos'], off = POS[0], ymed - t
        else:
            g['pos'], off = POS[1], bt - ymed
        if g['pos'] == POS[2]:
            g['layer'] = 1
        else:
            g['layer'] = int(max(1, min(4, round((off - cov - opt['stir'] - d / 2.0) / (d + opt['pitch'])) + 1)))
        a, lk, lv = _left_end(lay, su, opt, xl, xr, hook)
        b, rk, rv = _right_end(lay, su, opt, xr, xl, hook)
        g.update(a=a, lk=lk, lv=lv, b=b, rk=rk, rv=rv)
    else:
        low_len = (max(p[0] for p in below) - min(p[0] for p in below))
        up_len = (max(p[0] for p in above) - min(p[0] for p in above))
        main_low = low_len >= up_len
        g['pos'] = POS[1] if main_low else POS[0]
        ymain = [p[1] for p in (below if main_low else above)]
        ymed = sorted(ymain)[len(ymain) // 2]
        off = (bt - ymed) if main_low else (ymed - t)
        g['layer'] = int(max(1, min(4, round((off - cov - opt['stir'] - d / 2.0) / (d + opt['pitch'])) + 1)))
        main_zone = below if main_low else above
        opp_zone = above if main_low else below
        right_bent = (y_last < ymid) if main_low else (y_last > ymid)
        nsup = [k for k in range(ns + 1) if su[k]['w'] > 0] or list(range(ns + 1))
        if right_bent:
            xs_bend = max(p[0] for p in main_zone)
            x_top = min(p[0] for p in opp_zone)
            k = min(nsup, key=lambda q: abs(lay['sx0'][q] + su[q]['w'] / 2.0 - x_top))
            e = max(0.0, lay['sx0'][k] - xs_bend)
            e2 = max(0.0, xr - (lay['sx0'][k] + su[k]['w'])) if k < ns else 0.0
            a, lk, lv = _left_end(lay, su, opt, xl, xr, hook)
            g.update(a=a, lk=lk, lv=lv, b=k, rk=K_UON, rv='%s;%s' % (_r10(e), _r10(e2)))
        else:
            xs_bend = min(p[0] for p in main_zone)
            x_top = max(p[0] for p in opp_zone)
            k = min(nsup, key=lambda q: abs(lay['sx0'][q] + su[q]['w'] / 2.0 - x_top))
            e = max(0.0, xs_bend - (lay['sx0'][k] + su[k]['w']))
            e2 = max(0.0, lay['sx0'][k] - xl) if k > 0 else 0.0
            b, rk, rv = _right_end(lay, su, opt, xr, xl, hook)
            g.update(a=k, lk=K_UON, lv='%s;%s' % (_r10(e), _r10(e2)), b=b, rk=rk, rv=rv)
        if g['a'] > g['b']:
            g['a'], g['b'] = g['b'], g['a']
    # ---- ap doan be vao cot len dau tuong ung
    if legs and g['pos'] != '':
        for xleg, dyl in legs:
            if (g['pos'] == POS[1]) != (dyl < 0):
                continue                          # be nguoc chieu quy dinh (thep tren xuong / thep duoi len) -> bo qua
            side = 'l' if abs(xleg - xl) <= abs(xleg - xr) else 'r'
            if g[side + 'k'] == K_UON:
                continue
            w = _where(lay, su, xleg)
            k = w[1] if w[0] != 'span' else (g['a'] if side == 'l' else g['b'])
            sp_i = sp[min(max(_span_at(lay, xleg), 0), ns - 1)]
            y0 = yline(lay, sp_i, g['pos'], g['layer'], d, opt)
            full = gap_leg('xuống', d, opt, lay, sp_i, g['pos'], y0)
            leg = abs(dyl)
            val = u'xuống' if leg >= 0.6 * full else _r10(leg)      # be gan het chieu cao dam -> 'xuong': tu theo h khi doi tiet dien / cote
            if side == 'l':
                g.update(a=k, lk=K_GAP, lv=val)
            else:
                g.update(b=k, rk=K_GAP, rv=val)
    if g['a'] > g['b']:
        g['a'], g['b'] = g['b'], g['a']
    full_beam = (xr - xl) >= 0.9 * lay['L']
    if snap:
        g = _snap_standard(g, beam, opt, lay, full_beam)
    if layer_force:
        g['layer'] = int(layer_force)
    return g


def retarget(g, beam, opt, which, new_x):
    """Keo dau 'L'/'R' cua nhom thep den new_x (mm); tra ve nhom moi hoac None."""
    if g['lk'] == K_UON or g['rk'] == K_UON:
        return None
    lines = build(g, beam, opt)
    if not lines:
        return None
    xs = [p[0] for q in lines for p in q]
    xl, xr = min(xs), max(xs)
    if which == 'L':
        xl = new_x
    else:
        xr = new_x
    if xl > xr:
        xl, xr = xr, xl
    if xr - xl < 150.0:
        return None
    lay = layout(beam)
    su = beam['supports']
    a, lk, lv = _left_end(lay, su, opt, xl, xr, False)
    b, rk, rv = _right_end(lay, su, opt, xr, xl, False)
    ng = dict(g)
    if which == 'L':
        ng.update(a=a, lk=lk, lv=lv)
        if (b, rk) == (g['b'], g['rk']):
            rk, rv = g['rk'], g['rv']
        ng.update(b=b, rk=rk, rv=rv)
    else:
        ng.update(b=b, rk=rk, rv=rv)
        if (a, lk) == (g['a'], g['lk']):
            lk, lv = g['lk'], g['lv']
        ng.update(a=a, lk=lk, lv=lv)
    if ng['a'] > ng['b']:
        return None
    return ng


# =====================================================================================
#  Tu bo tri thep theo tiet dien / nhip
# =====================================================================================
DEFAULT_RULES = {
    'h': [dict(lo=0, hi=400, top='2T14', bot='2T16', tc_sup='', tc_span='', mid='', stir='6-150/200', stir2=''),
          dict(lo=400, hi=700, top='2T16', bot='3T18', tc_sup='2T16', tc_span='', mid='', stir='8-100/200', stir2=''),
          dict(lo=700, hi=0, top='3T18', bot='4T20', tc_sup='2T18', tc_span='2T16', mid='2T12', stir='8-100/200', stir2='8-200/400')],
    'l': [dict(lo=0, hi=4000, top='2T16', bot='2T16', tc_sup='', tc_span='', mid='', stir='8-150/200', stir2=''),
          dict(lo=4000, hi=7000, top='2T16', bot='3T18', tc_sup='2T16', tc_span='', mid='', stir='8-100/200', stir2=''),
          dict(lo=7000, hi=0, top='3T18', bot='4T20', tc_sup='2T18', tc_span='2T16', mid='', stir='8-100/200', stir2='8-200/400')],
}


def pick_section_rule(rules, b, h):
    """Quy tac theo tiet dien da quet: khop b x h, neu khong co lay tiet dien gan nhat."""
    best = None
    for r in rules:
        d = abs(float(r.get('h') or 0) - h) * 10.0 + abs(float(r.get('b') or 0) - b)
        if best is None or d < best[0]:
            best = (d, r)
    return best[1] if best else None


def suggest_rule(h):
    """Goi y thep ban dau cho 1 tiet dien theo chieu cao h (nguoi dung sua lai)."""
    r = pick_rule(DEFAULT_RULES['h'], h) or DEFAULT_RULES['h'][1]
    return dict((k, r[k]) for k in ('top', 'bot', 'tc_sup', 'tc_span', 'mid', 'stir', 'stir2'))


def pick_rule(rules, v):
    for r in rules:
        lo = float(r.get('lo') or 0.0)
        hi = float(r.get('hi') or 0.0)
        if v >= lo and (hi <= 0 or v < hi):
            return r
    return None


_FREE = (K_EXT, K_CUT)


def _extent(g, beam, opt, lay):
    xs = [p[0] for ln in build(g, beam, opt, lay) for p in ln]
    return (min(xs), max(xs)) if xs else None


def merge_tc(beam, G, opt):
    """Noi 2 doan tang cuong (lop >= 2, cung vi tri / SL / Ø) thanh 1 thanh khi khoang ho giua 2 dau <= merge_gap (mm)."""
    gap_max = float(opt.get('merge_gap') or 0.0)
    if not opt.get('merge_on') or gap_max <= 0 or not beam.get('spans'):
        return G
    lay = layout(beam)
    G = list(G)
    for _ in range(len(G) + 1):
        cand = {}
        for i, g in enumerate(G):
            if g['pos'] not in (POS[0], POS[1]):
                continue
            e = _extent(g, beam, opt, lay)
            if e:
                cand.setdefault((g['pos'], int(g['layer']), int(g['n']), float(g['d']), g.get('cross')), []).append((e[0], e[1], i))
        done = False
        for items in cand.values():
            items.sort()
            for (xa0, xa1, ia), (xb0, xb1, ib) in zip(items[:-1], items[1:]):
                ga, gb = G[ia], G[ib]
                if ga['rk'] not in _FREE or gb['lk'] not in _FREE or xb0 - xa1 > gap_max:
                    continue
                m = dict(ga, b=gb['b'], rk=gb['rk'], rv=gb['rv'])
                em = _extent(m, beam, opt, lay)
                if not em or abs(em[0] - min(xa0, xb0)) > 1.0 or abs(em[1] - max(xa1, xb1)) > 1.0:
                    continue                      # thanh gop khong trung 2 doan cu -> khong gop
                G[ia] = m
                del G[ib]
                done = True
                break
            if done:
                break
        if not done:
            break
    return G


# ---- Thep tang cuong theo tuy chon (tick) ---------------------------------------------------------------
TC_CELLS = [('tct1', POS[0], 1, u'Tăng cường lớp 1 trên'), ('tcb1', POS[1], 1, u'Tăng cường lớp 1 dưới'),
            ('tct2', POS[0], 2, u'Tăng cường lớp 2 trên'), ('tcb2', POS[1], 2, u'Tăng cường lớp 2 dưới')]
TC_NOTE = u'TC tự động'


def tc_enabled(opt):
    return any(opt.get(k + '_on') for k, p, ly, t in TC_CELLS)


def is_tc(g):
    """Nhom thep tang cuong: co nhan 'TC tu dong' trong ghi chu, hoac dau mu gối (K_EXT) / nhip (2 dau K_CUT)."""
    if (g.get('note') or '').startswith(TC_NOTE):
        return True
    if g['pos'] == POS[0] and K_EXT in (g['lk'], g['rk']):
        return True
    return g['pos'] == POS[1] and g['lk'] == K_CUT and g['rk'] == K_CUT


def _main_d(main, pos, spans):
    """Duong kinh thep chu (lop 1) cung vi tri phu cac nhip da cho; khong co thi lay lon nhat cung vi tri; khong co nua thi 16."""
    def covers(g):
        return any(g['a'] <= j < g['b'] for j in spans)
    cand = [int(g['d']) for g in main if g['pos'] == pos and int(g['layer']) == 1 and covers(g)]
    if not cand:
        cand = [int(g['d']) for g in main if g['pos'] == pos and int(g['layer']) == 1]
    return max(cand) if cand else 16


def apply_tc(beam, groups, opt):
    """Ap dung cac o tang cuong da tick cho 1 dam: xoa tang cuong cu cung (vi tri, lop) roi tao lai.
    Tren: mu goi (keo vao nhip L/3 tu mep goi, goi bien thi gap vao cot). Duoi: nhip, cat cach mep goi L/6.
    Dau tang cuong di qua cot cay / dam phu va neo l_an (xem build)."""
    sp, sup = beam['spans'], beam['supports']
    n = len(sp)
    cells = [(k, p, ly, t) for k, p, ly, t in TC_CELLS if opt.get(k + '_on')]
    if not cells or not n:
        return list(groups)
    drop = set((p, ly) for k, p, ly, t in cells)
    G = [g for g in groups if not (is_tc(g) and (g['pos'], int(g['layer'])) in drop)]
    main = [g for g in G if not is_tc(g)]
    zb = (opt.get('zone_bot') or u'L/6').strip() or u'L/6'
    for key, p, ly, title in cells:
        nb = max(1, int(round(float(opt.get(key + '_n') or 1))))
        dd = int(round(float(opt.get(key + '_d') or 0)))
        note = u'%s: %s' % (TC_NOTE, title.replace(u'Tăng cường ', u''))
        if p == POS[0]:
            for k in range(n + 1):
                if sup[k].get('kind') in (u'Đổi tiết diện', u'Đầu tự do'):
                    continue
                d = dd or _main_d(main, p, [j for j in (k - 1, k) if 0 <= j < n])
                if 0 < k < n:
                    G.append(new_group(pos=p, layer=ly, n=nb, d=d, a=k, b=k, lk=K_EXT, rk=K_EXT, note=note))
                elif k == 0:
                    G.append(new_group(pos=p, layer=ly, n=nb, d=d, a=0, b=0, lk=K_GAP, lv=opt['gap'], rk=K_EXT, note=note))
                else:
                    G.append(new_group(pos=p, layer=ly, n=nb, d=d, a=n, b=n, lk=K_EXT, rk=K_GAP, rv=opt['gap'], note=note))
        else:
            for i in range(n):
                d = dd or _main_d(main, p, [i])
                G.append(new_group(pos=p, layer=ly, n=nb, d=d, a=i, b=i + 1, lk=K_CUT, lv=zb, rk=K_CUT, rv=zb, note=note))
    return merge_tc(beam, G, opt)


def auto_layout(beam, rules, crit, opt, merge=True, top_end=K_HET):
    """Tra ve (danh sach nhom thep, [(dai, dai_trong)] moi nhip). Sau khi bo tri theo quy tac: them thep than (h > skin_h)
    va kep dai theo TCVN 5574:2018 neu duoc bat trong Thiet lap."""
    G, stirs = _auto_core(beam, rules, crit, opt, merge, top_end)
    if opt.get('skin_on'):
        G = apply_skin(beam, G, opt)
    if opt.get('tcvn_stir'):
        stirs = tcvn_stirrups(beam, G, opt, stirs)
    return G, stirs


def _auto_core(beam, rules, crit, opt, merge=True, top_end=K_HET):
    sp = beam['spans']
    n = len(sp)
    if crit == 's':
        rl = [pick_section_rule(rules, s['b'], s['h']) for s in sp]
    else:
        rl = [pick_rule(rules, s['h'] if crit == 'h' else s['clear']) for s in sp]
    stirs = [((r or {}).get('stir', ''), (r or {}).get('stir2', '')) for r in rl]
    G = []

    def endv(k):
        return opt['gap'] if k == K_GAP else (opt['neo'] if k == K_NEO else '')

    def val(i, key):
        return ((rl[i] or {}).get(key) or '').strip()

    def runs(key):
        out, i = [], 0
        while i < n:
            v = val(i, key)
            if not v or not parse_spec(v):
                i += 1
                continue
            j = i
            while merge and j + 1 < n and val(j + 1, key) == v:
                j += 1
            out.append((i, j, v))
            i = j + 1
        return out
    for i, j, v in runs('top'):
        nb, d = parse_spec(v)
        lk = top_end if i == 0 else K_NEO
        rk = top_end if j == n - 1 else K_NEO
        G.append(new_group(pos=POS[0], layer=1, n=nb, d=d, a=i, b=j + 1, lk=lk, lv=endv(lk), rk=rk, rv=endv(rk)))
    for i, j, v in runs('bot'):
        nb, d = parse_spec(v)
        G.append(new_group(pos=POS[1], layer=1, n=nb, d=d, a=i, b=j + 1, lk=K_NEO, lv=opt['neo'], rk=K_NEO, rv=opt['neo']))
    for i, j, v in runs('mid'):
        nb, d = parse_spec(v)
        G.append(new_group(pos=POS[2], layer=1, n=nb, d=d, a=i, b=j + 1, lk=K_NEO, lv=opt['neo'], rk=K_NEO, rv=opt['neo']))
    if tc_enabled(opt):                      # che do tuy chon tang cuong (tick): dung tuy chon, bo cot TC cua bang quy tac
        return apply_tc(beam, G, opt), stirs
    for k in range(n + 1):
        if beam['supports'][k].get('kind') == u'Đổi tiết diện':       # gối ảo: không đặt tăng cường mũ gối
            continue
        cand = [i for i in (k - 1, k) if 0 <= i < n and parse_spec(val(i, 'tc_sup'))]
        if not cand:
            continue
        i = max(cand, key=lambda q: sp[q]['h'] if True else 0)
        nb, d = parse_spec(val(i, 'tc_sup'))
        if 0 < k < n:
            G.append(new_group(pos=POS[0], layer=2, n=nb, d=d, a=k, b=k, lk=K_EXT, rk=K_EXT))
        elif k == 0:
            G.append(new_group(pos=POS[0], layer=2, n=nb, d=d, a=0, b=0, lk=K_GAP, lv=opt['gap'], rk=K_EXT))
        else:
            G.append(new_group(pos=POS[0], layer=2, n=nb, d=d, a=n, b=n, lk=K_EXT, rk=K_GAP, rv=opt['gap']))
    for i in range(n):
        sp_ = parse_spec(val(i, 'tc_span'))
        if sp_:
            G.append(new_group(pos=POS[1], layer=2, n=sp_[0], d=sp_[1], a=i, b=i + 1, lk=K_CUT, lv='L/6', rk=K_CUT, rv='L/6'))
    return merge_tc(beam, G, opt), stirs


# =====================================================================================
#  Vung dai (zones): dai theo nhip + dai ve tay
# =====================================================================================
_S = re.compile(r'^(\d+)-(\d+)(?:/(\d+))?$')


def parse_stir(s):
    m = _S.match((s or '').replace(' ', ''))
    if not m:
        return None
    return int(m.group(1)), int(m.group(2)), int(m.group(3) or m.group(2))


def derived_zones(beam, opt):
    """Vung dai suy ra tu thong so dai moi nhip (8-100/200). Nhip < opt['short'] -> 1 khoang cach (a gối) suot nhip."""
    lay = layout(beam)
    out = []
    for i, s in enumerate(beam['spans']):
        st = parse_stir(s.get('stir'))
        if not st:
            continue
        d, a1, a2 = st
        fl, fr, c = lay['fl'][i], lay['fr'][i], s['clear']
        if c < opt.get('short', 1500.0) or a2 == a1:
            out.append(dict(x0=fl, x1=fr, d=d, a=a1))
        else:
            z = c / 4.0
            out.extend([dict(x0=fl, x1=fl + z, d=d, a=a1), dict(x0=fl + z, x1=fr - z, d=d, a=a2),
                        dict(x0=fr - z, x1=fr, d=d, a=a1)])
        # cot cay len dam: dai day dac ngay chan cot, keo sang moi ben >= h dam tinh tu mep cot (buoc 50..100)
        for q in s.get('planted') or []:
            w = float(q.get('w') or 0.0)
            xm = fl + float(q['pos'])
            h = float(s.get('h') or 0.0)
            x0, x1 = max(xm - w / 2.0 - h, fl), min(xm + w / 2.0 + h, fr)
            if x1 - x0 > 1.0:
                col_a = int(min(a1 or 100, opt.get('col_a', 100)))
                out = add_zone(out, x0, x1, d, col_a)
    if opt.get('hang_on', DEFAULT_OPT['hang_on']):
        # TCVN 5574:2018 10.4.12: dam phu gac len dam chinh -> dai bo sung (om thep doc) tren doan b + 2h cua dam phu
        ha = int(opt.get('hang_a', DEFAULT_OPT['hang_a']) or 50)
        for k, su in enumerate(beam['supports']):
            if su.get('kind') == u'Dầm' and u'Dầm phụ' in (su.get('role') or u'') and su.get('w', 0.0) > 0.5:
                hs = su.get('dh') or max([q.get('h', 0.0) for q in beam['spans']] + [0.0])
                c = lay['sx0'][k] + su['w'] / 2.0
                half = (su['w'] + 2.0 * hs) / 2.0
                x0, x1 = max(c - half, 0.0), min(c + half, lay['L'])
                dd = max([parse_stir(q.get('stir'))[0] for q in beam['spans'] if parse_stir(q.get('stir'))] + [8])
                if x1 - x0 > 1.0:
                    out = add_zone(out, x0, x1, dd, ha)
    merged = []                                   # gop cac vung dai ke nhau co cung Ø va a
    for z in out:
        if merged and abs(merged[-1]['x1'] - z['x0']) < 0.5 and merged[-1]['d'] == z['d'] and merged[-1]['a'] == z['a']:
            merged[-1] = dict(merged[-1], x1=z['x1'])
        else:
            merged.append(z)
    return merged


def add_zone(zones, x0, x1, d, a):
    """Chen vung dai moi (ve tay), cat bot / xoa cac vung cu bi de."""
    if x1 < x0:
        x0, x1 = x1, x0
    new = []
    for z in zones:
        if z['x1'] <= x0 or z['x0'] >= x1:
            new.append(z)
            continue
        if z['x0'] < x0:
            new.append(dict(z, x1=x0))
        if z['x1'] > x1:
            new.append(dict(z, x0=x1))
    new.append(dict(x0=x0, x1=x1, d=int(d), a=int(a)))
    new.sort(key=lambda z: z['x0'])
    return new


def final_zones(beam, explicit, opt):
    z = derived_zones(beam, opt)
    for e in explicit or []:
        z = add_zone(z, e['x0'], e['x1'], e['d'], e['a'])
    return z


def snap_x(beam, x, tol):
    """Hut x (mm) vao diem dac biet: mep goi, 1/4, 1/2 nhip (trong pham vi tol mm); mac dinh lam tron 10 mm."""
    lay = layout(beam)
    keys = []
    for i in range(lay['n']):
        c = lay['fr'][i] - lay['fl'][i]
        keys.extend([lay['fl'][i], lay['fl'][i] + c / 4.0, lay['fl'][i] + c / 2.0, lay['fr'][i] - c / 4.0, lay['fr'][i]])
    best = min(keys, key=lambda k: abs(k - x)) if keys else x
    if abs(best - x) <= tol:
        return best
    return round(x / 10.0) * 10.0


# =====================================================================================
#  TCVN 5574:2018 - cau tao dam: thep than (chong phinh), dai theo khoang cach toi da, dai 4 nhanh,
#  dai bo sung tai dam phu, kiem tra
#    10.3.3.1  ham luong toi thieu 0,1% (cau kien chiu uon)
#    10.3.3.3  khoang cach toi da giua cac thanh doc: min(1,5h; 400) khi h > 150
#    10.3.3.4  b > 150: it nhat 2 thanh chiu keo
#    10.3.3.5  thep nhip keo vao goi: >= 1/2 dien tich va >= 2 thanh
#    10.3.2    khoang ho thanh doc >= max(d; 25)
#    10.3.4.2  Ø dai >= 6 (B70-B100: 8)
#    10.3.4.3  dai chiu cat: a <= min(0,5h0; 300) (doan gan goi, ~L/4); doan giua nhip: a <= min(0,75h0; 500)
#    10.4.12   nut giao dam: dai bo sung dang om thep doc, dai tren doan b + 2h cua dam chinh (b, h cua DAM PHU)
#  10.4.13   Thep than (cot giá) khi h > 700: moi canh ben dat doc cau tao sao cho s < 400 va tong As >= 0,1% s max(b/2; 200)
#            (nguon: tai lieu VIETCONS 'Cau tao thep dam theo TCVN' - Nguyen Dinh Nghia, dan 10.4.13; CHUA doi chieu ban TCVN goc)
#  Gioi han dai Ø >= stir_dmin, a <= stir_a1 / stir_a2: mac dinh 6 / 300 / 500 (be tong < B70); B70-B100 phai tu nhap.
# =====================================================================================
SKIN_NOTE = u'TCVN thân'          # 10.4.13
_DIAS = (10, 12, 14, 16, 18, 20, 22, 25, 28, 32)


def is_skin(g):
    return (g.get('note') or u'').startswith(SKIN_NOTE)


def _o(opt, k):
    return float(opt.get(k, DEFAULT_OPT[k]) or 0.0)


def stir_limits(h, opt):
    """(a_toi_da_gan_goi, a_toi_da_giua_nhip) theo 10.3.4.3, h0 = h - stir_a0. Tran 300 / 500 chinh duoc (stir_a1 / stir_a2)."""
    h0 = max(h - _o(opt, 'stir_a0'), 1.0)
    return min(0.5 * h0, _o(opt, 'stir_a1') or 300.0), min(0.75 * h0, _o(opt, 'stir_a2') or 500.0)


def _down50(v):
    return max(50, int(v // 50) * 50)


def fmt_stir(d, a1, a2):
    return u'%d-%d/%d' % (d, a1, a2) if a1 != a2 else u'%d-%d' % (d, a1)


def _covx(lines, x):
    for q in lines:
        for p0, p1 in zip(q[:-1], q[1:]):
            lo, hi = min(p0[0], p1[0]), max(p0[0], p1[0])
            if lo - 0.01 <= x <= hi + 0.01 and hi - lo > 0.5:
                return True
    return False


def _at(beam, groups, lines, x):
    """{(vi tri, lop): [tong SL, tong dien tich mm2, Ø lon nhat]} cac nhom thep co mat tai x."""
    out = {}
    for g, ln in zip(groups, lines):
        if not _covx(ln, x):
            continue
        r = out.setdefault((g['pos'], int(g['layer'])), [0, 0.0, 0.0])
        n, d = int(g['n']), float(g['d'])
        r[0] += n
        r[1] += n * math.pi * d * d / 4.0
        r[2] = max(r[2], d)
    return out


def _sum(at, pos):
    return (sum(v[0] for k, v in at.items() if k[0] == pos), sum(v[1] for k, v in at.items() if k[0] == pos))


def legs_for(b, at, opt):
    """So nhanh dai: 4 khi b >= leg_b hoac so thanh trong 1 lop > leg_n, nguoc lai 2."""
    mx = max([v[0] for k, v in at.items() if k[0] != POS[2]] + [0])
    return 4 if (b >= _o(opt, 'leg_b') or mx > _o(opt, 'leg_n')) else 2


# ---- thep than (chong phinh) ------------------------------------------------------------------------
def skin_need(h, b, opt, dmain=16.0):
    """None neu h <= skin_h; nguoc lai (so thanh moi mat nf, Ø, khoang cach s)."""
    if h <= _o(opt, 'skin_h'):
        return None
    off = _o(opt, 'cover') + _o(opt, 'stir') + dmain / 2.0          # tam thep chu lop 1 tinh tu mep be tong
    heff = max(h - 2.0 * off, 1.0)
    nf = max(1, int(math.ceil(heff / _o(opt, 'skin_s'))) - 1)
    s = heff / (nf + 1.0)
    need = _o(opt, 'skin_ratio') / 100.0 * s * max(b / 2.0, 200.0)        # mm2 cho moi thanh (moi mat)
    d0 = int(_o(opt, 'skin_d'))
    d = next((x for x in _DIAS if x >= d0 and math.pi * x * x / 4.0 >= need), _DIAS[-1])
    return nf, d, s


def apply_skin(beam, groups, opt):
    """Xoa thep than 'TCVN than' cu, tao lai cho cac nhip h > skin_h. Khong dung vao thep chu va thep than nguoi dung tu nhap."""
    sp = beam['spans']
    n = len(sp)
    G = [g for g in groups if not is_skin(g)]
    if not n:
        return G
    user_mid = [g for g in G if g['pos'] == POS[2]]
    need = []
    for i, s in enumerate(sp):
        dm = max([float(g['d']) for g in G if g['pos'] == POS[1] and int(g['layer']) == 1 and g['a'] <= i < g['b']] + [0.0]) or 16.0
        r = skin_need(s['h'], s['b'], opt, dm)
        if r and any(g['a'] <= i < g['b'] and int(g['n']) >= 2 * r[0] and float(g['d']) >= r[1] for g in user_mid):
            r = None                                  # nguoi dung da co thep than du cho nhip nay
        need.append(r)
    i = 0
    while i < n:
        if need[i] is None:
            i += 1
            continue
        j = i
        while j + 1 < n and need[j + 1] is not None and need[j + 1][:2] == need[i][:2]:
            j += 1
        nf, d, s = need[i]
        G.append(new_group(pos=POS[2], layer=1, n=2 * nf, d=d, a=i, b=j + 1, lk=K_NEO, lv=u'', rk=K_NEO, rv=u'',
                           note=u'%s: %dØ%d (mỗi mặt %d, s≈%d) - h > %d' % (SKIN_NOTE, 2 * nf, d, nf, round(s), round(_o(opt, 'skin_h')))))
        i = j + 1
    return G


# ---- dai theo TCVN ----------------------------------------------------------------------------------
def tcvn_stirrups(beam, groups, opt, stirs=None):
    """[(dai, dai_trong)] moi nhip:
       - chua co dai -> dai cau tao: Ø8 (Ø6 neu h <= 300), a gan goi <= min(100; a_max), a giua nhip <= min(200; a_max);
       - da co dai -> kep Ø >= 6 va a ve <= TCVN 10.3.4.3 (chi GIAM, khong tang);
       - dai 4 nhanh (b >= leg_b hoac > leg_n thanh / lop): dai trong cung Ø va a voi dai ngoai neu chua co."""
    sp = beam['spans']
    lay = layout(beam)
    beam = dict(beam, groups=groups)
    lines = [build(g, beam, opt, lay) for g in groups]
    out = []
    for i, s in enumerate(sp):
        cur = stirs[i] if stirs and i < len(stirs) else (s.get('stir') or u'', s.get('stir2') or u'')
        st, st2 = (cur[0] or u'').strip(), (cur[1] or u'').strip()
        m1, m2 = stir_limits(s['h'], opt)
        p = parse_stir(st)
        if p:
            d, a1, a2 = p
            d = max(d, int(_o(opt, 'stir_dmin') or 6))
            a1, a2 = min(a1, _down50(m1)), min(a2, _down50(m2))
            st = fmt_stir(d, a1, a2)
        else:
            d = max(6 if s['h'] <= 300 else 8, int(_o(opt, 'stir_dmin') or 6))
            st = fmt_stir(d, min(100, _down50(m1)), min(200, _down50(m2)))
        if not st2:
            xs = [lay['fl'][i] + min(150.0, s['clear'] * 0.12), (lay['fl'][i] + lay['fr'][i]) / 2.0, lay['fr'][i] - min(150.0, s['clear'] * 0.12)]
            nl = max(legs_for(s['b'], _at(beam, groups, lines, x), opt) for x in xs)
            if nl == 4:
                st2 = st
        out.append((st, st2))
    return out


# ---- kiem tra ---------------------------------------------------------------------------------------
def tcvn_check(beam, groups, opt):
    """Danh sach (dat?, noi dung) cho tung nhip theo TCVN 5574:2018. dat = True / False (canh bao)."""
    sp, su = beam['spans'], beam['supports']
    lay = layout(beam)
    beam = dict(beam, groups=groups)
    lines = [build(g, beam, opt, lay) for g in groups]
    res = []
    a0 = _o(opt, 'stir_a0')
    for i, s in enumerate(sp):
        tag = u'N%s' % s.get('idx', i + 1)
        b, h = s['b'], s['h']
        h0 = max(h - a0, 1.0)
        fl, fr = lay['fl'][i], lay['fr'][i]
        xm = (fl + fr) / 2.0
        mid = _at(beam, groups, lines, xm)
        # --- dai
        p = parse_stir(s.get('stir'))
        m1, m2 = stir_limits(h, opt)
        if not p:
            res.append((False, u'%s: chưa có đai (10.3.4.3) - bấm "Áp dụng TCVN" để đặt đai cấu tạo.' % tag))
        else:
            d, a1, a2 = p
            bad = []
            dmin = int(_o(opt, 'stir_dmin') or 6)
            if d < dmin:
                bad.append(u'Ø%d < %d (10.3.4.2)' % (d, dmin))
            if a1 > m1 + 0.5:
                bad.append(u'a gần gối %d > %d = min(0,5h0; %d)' % (a1, round(m1), round(_o(opt, 'stir_a1') or 300)))
            if a2 > m2 + 0.5:
                bad.append(u'a giữa nhịp %d > %d = min(0,75h0; %d)' % (a2, round(m2), round(_o(opt, 'stir_a2') or 500)))
            res.append((not bad, u'%s: đai %s %s' % (tag, s.get('stir'), u'đạt 10.3.4' if not bad else u'- ' + u'; '.join(bad))))
        nl = max(legs_for(b, _at(beam, groups, lines, x), opt) for x in (fl + 50.0, xm, fr - 50.0))
        if nl == 4 and not (s.get('stir2') or u'').strip():
            res.append((False, u'%s: b=%d / số thanh nhiều → nên đai 4 nhánh (thêm đai trong).' % (tag, round(b))))
        # --- thep doc
        nb, ab = _sum(mid, POS[1])
        nt, at_ = _sum(mid, POS[0])
        if nb < (2 if b > 150 else 1):
            res.append((False, u'%s: thép dưới giữa nhịp %d thanh < 2 (10.3.3.4)' % (tag, nb)))
        else:
            xa, xb = fl - 1.0 if su[i]['w'] > 0.5 else fl, fr + 1.0 if su[i + 1]['w'] > 0.5 else fr
            nin = ain = 0
            for g, ln in zip(groups, lines):
                if g['pos'] == POS[1] and _covx(ln, xa) and _covx(ln, xb):
                    nin += int(g['n'])
                    ain += int(g['n']) * math.pi * float(g['d']) ** 2 / 4.0
            if not s.get('console') and (nin < 2 or ain + 1e-6 < 0.5 * ab):
                res.append((False, u'%s: thép dưới vào cả 2 gối %d thanh, %.0f/%.0f mm² - cần ≥ 2 thanh và ≥ 1/2 As nhịp (10.3.3.5)' % (tag, nin, ain, ab)))
            if ab < 0.001 * b * h0:
                res.append((False, u'%s: As dưới %.0f mm² < 0,1%% b·h0 = %.0f (10.3.3.1)' % (tag, ab, 0.001 * b * h0)))
        if nt < 2:
            res.append((False, u'%s: thép trên (thép giá) %d thanh - cần ≥ 2 thanh góc để buộc đai' % (tag, nt)))
        for (pos, ly), (cnt, area, dmax) in sorted(mid.items()):
            if pos == POS[2] or cnt < 2:
                continue
            xa_, xb_ = _o(opt, 'cover') + _o(opt, 'stir') + dmax / 2.0, b - _o(opt, 'cover') - _o(opt, 'stir') - dmax / 2.0
            pitch = (xb_ - xa_) / (cnt - 1.0)
            if pitch - dmax < max(dmax, 25.0) - 1e-6:
                res.append((False, u'%s: %s lớp %d: %d thanh Ø%d - khoảng hở %d < max(d; 25) (10.3.2)' % (tag, pos, ly, cnt, dmax, round(pitch - dmax))))
            if pitch > min(1.5 * h, 400.0) + 1e-6:
                res.append((False, u'%s: %s lớp %d: khoảng cách %d > min(1,5h; 400) (10.3.3.3)' % (tag, pos, ly, round(pitch))))
        # --- thep than
        r = skin_need(h, b, opt, max([v[2] for k, v in mid.items() if k[0] == POS[1] and k[1] == 1] + [16.0]))
        if r:
            nm, am = _sum(mid, POS[2])
            dm_ = max([v[2] for k, v in mid.items() if k[0] == POS[2]] + [0.0])
            if nm < 2 * r[0] or dm_ < r[1]:
                res.append((False, u'%s: h=%d > %d cần thép thân %dØ%d (mỗi mặt %d, s≈%d, 10.4.13) - hiện có %d thanh' % (
                    tag, round(h), round(_o(opt, 'skin_h')), 2 * r[0], r[1], r[0], round(r[2]), nm)))
            else:
                res.append((True, u'%s: thép thân %d thanh đạt 10.4.13 (s ≤ %d)' % (tag, nm, round(_o(opt, 'skin_s')))))
    hc = float(opt.get('hook_clr') or 0.0)
    dm = max([float(g['d']) for g in groups] + [0.0])
    if hc and hc < max(25.0, dm) - 1e-6 and any(K_GAP in (g['lk'], g['rk']) or is_tc(g) for g in groups):
        res.append((False, u'Khoảng hở giữa chân bẻ lên / bẻ xuống = %d mm < max(d; 25) = %d mm (10.3.2) - tăng ô "Khoảng hở chân bẻ" ở tab Thiết lập nếu cần đúng TCVN.' % (round(hc), round(max(25.0, dm)))))
    for k, x in enumerate(su):
        if x.get('kind') == u'Dầm' and u'Dầm phụ' in (x.get('role') or u'') and x.get('w', 0) > 0.5:
            hs = x.get('dh') or max([q['h'] for q in sp] + [0.0])
            res.append((True, u'G%d: dầm phụ %s gác lên dầm - đai bổ sung ôm thép dọc trên đoạn b+2h = %d + 2×%d = %d (10.4.12), a = %d' % (
                k, x.get('ref') or u'', round(x['w']), round(hs), round(x['w'] + 2 * hs), round(_o(opt, 'hang_a')))))
    return res


def tcvn_report(beam, groups, opt):
    it = tcvn_check(beam, groups, opt)
    bad = [t for ok, t in it if not ok]
    head = u'Dầm %s: %d mục đạt, %d cảnh báo (TCVN 5574:2018)\r\n' % (beam.get('name', ''), len(it) - len(bad), len(bad))
    return head + u'\r\n'.join((u'[OK] ' if ok else u'[!]  ') + t for ok, t in it)

# -*- coding: utf-8 -*-
"""Ve trien khai dam: mat dung + dim + cote + cac mat cat (co san) + nhom thep.
Huong nhin tren mat bang: dam ngang TRAI -> PHAI, dam dung DUOI -> TREN.
render() tra ve (primitives, W, ctx) theo toa do pixel; ctx dung cho but ve / chon thep.
('rect',x,y,w,h,fill|None,line|None) ('line',x1,y1,x2,y2,rgb,width,dash) ('circle',cx,cy,r,fill,line)
('text',x,y,s,rgb,size,align,bold)"""
import math
import re
import bm_bars as B

C_TOP, C_BOT, C_MID, C_SEL = (192, 57, 43), (36, 99, 190), (30, 140, 60), (255, 140, 0)
C_STIR, C_DIM, C_TXT = (112, 132, 165), (95, 95, 95), (45, 45, 45)
C_AXIS, C_DELTA, C_CUT = (176, 120, 120), (190, 100, 10), (60, 60, 60)
BEAM_FILL, COL_FILL, SLAB_FILL = (244, 247, 252), (236, 236, 236), (240, 238, 226)
HATCH_B, HATCH_C, HATCH_S = (218, 226, 240), (205, 205, 205), (214, 208, 180)
PX_MM = 3.7795
parse_stir = B.parse_stir


def _hatch(P, x, y, w, h, step, col, cross=False):
    if w < 2 or h < 2:
        return
    k = -int(h // step) - 1
    while k * step <= w:
        x0 = x + k * step
        t0, t1 = max(0.0, x - x0), min(h, x + w - x0)
        if t1 - t0 > 1:
            P.append(('line', x0 + t0, y + h - t0, x0 + t1, y + h - t1, col, 1, False))
            if cross:
                P.append(('line', x0 + t0, y + t0, x0 + t1, y + t1, col, 1, False))
        k += 1


def _zig(P, x, y, w, col=(120, 120, 120), vertical=False):
    if vertical:
        P.append(('line', x, y, x - 4, y + w * 0.4, col, 1, False))
        P.append(('line', x - 4, y + w * 0.4, x + 4, y + w * 0.6, col, 1, False))
        P.append(('line', x + 4, y + w * 0.6, x, y + w, col, 1, False))
    else:
        P.append(('line', x, y, x + w * 0.4, y - 4, col, 1, False))
        P.append(('line', x + w * 0.4, y - 4, x + w * 0.6, y + 4, col, 1, False))
        P.append(('line', x + w * 0.6, y + 4, x + w, y, col, 1, False))


def hdim(P, xa, xb, y, text, up=False, col=C_DIM, size=7.5, bold=False, sub=None):
    if xb - xa < 1:
        return
    P.append(('line', xa, y, xb, y, col, 1, False))
    for x in (xa, xb):
        P.append(('line', x - 3, y + 3, x + 3, y - 3, col, 1, False))
    if text and (xb - xa) >= 12:
        P.append(('text', (xa + xb) / 2.0, y - 14 if up else y + 2, text, col, size, 'c', bold))
    if sub and (xb - xa) >= 40:
        P.append(('text', (xa + xb) / 2.0, y + 2 if up else y - 14, sub, col, size - 0.5, 'c', False))


def vdim(P, x, ya, yb, text, right=True, col=C_DIM, size=7.5):
    if abs(yb - ya) < 1:
        return
    P.append(('line', x, ya, x, yb, col, 1, False))
    for y in (ya, yb):
        P.append(('line', x - 3, y + 3, x + 3, y - 3, col, 1, False))
    if text and abs(yb - ya) >= 9:
        P.append(('text', x + (4 if right else -4), (ya + yb) / 2.0 - 5, text, col, size, 'l' if right else 'r', False))


def cote_txt(v, base=0.0):
    v = v + base
    return u'±0.000' if abs(v) < 0.5 else u'%+.3f' % (v / 1000.0)


def cote(P, x, y, v, tip_down=True, col=C_TXT, label=True, x_text=None, base=0.0):
    """Ky hieu cote (cao do, m, so voi Level): tam giac + gach ngang."""
    P.append(('line', x - 10, y, x + 10, y, col, 1, False))
    d = -6 if tip_down else 6
    P.append(('line', x - 4, y + d, x + 4, y + d, col, 1, False))
    P.append(('line', x - 4, y + d, x, y, col, 1, False))
    P.append(('line', x + 4, y + d, x, y, col, 1, False))
    if label:
        tx = x_text if x_text is not None else x + 12
        ty = y - 14 if tip_down else y + 2
        txt_ = cote_txt(v, base)
        P.append(('rect', tx - 2, ty - 1, 7.0 * len(txt_) + 4, 13, (255, 255, 255), None))
        P.append(('text', tx, ty, txt_, col, 8, 'l', True))


def _covers(lines, xm):
    for q in lines:
        for p0, p1 in zip(q[:-1], q[1:]):
            lo, hi = min(p0[0], p1[0]), max(p0[0], p1[0])
            if lo <= xm <= hi and hi - lo > 0.5:
                return True
    return False


def _gcol(g, sel=False):
    if sel:
        return C_SEL
    return C_TOP if g['pos'] == B.POS[0] else (C_BOT if g['pos'] == B.POS[1] else C_MID)


def _zone_at(zones, x):
    hit = None
    for z in zones:
        if z['x0'] - 1 <= x <= z['x1'] + 1:
            hit = z
    return hit


def cut_info(beam, groups, opt, lay, zones, i, xm):
    layers = {}
    for gi, g in enumerate(groups):
        if _covers(B.build(g, beam, opt, lay), xm):
            layers.setdefault((g['pos'], int(g['layer'])), []).append((int(g['n']), float(g['d']), gi))
    z = _zone_at(zones, xm)
    return dict(span=i, xm=xm, layers=layers, stir=(z['d'], z['a']) if z else None)


def _sig(beam, info):
    sp = beam['spans'][info['span']]
    lay = tuple(sorted((k[0], k[1], tuple(sorted((n, d) for n, d, gi in v))) for k, v in info['layers'].items()))
    return (round(sp['b']), round(sp['h']), round(sp['top']), sp.get('slabL'), sp.get('slabR'), lay, info['stir'], bool((sp.get('stir2') or u'').strip()))


def _section_cell(P, beam, groups, opt, info, x0, y0, s, title, caption, sel, flip, hl, zb=0.0, E=None, spans=()):
    """Ve 1 mat cat o toa do (x0,y0); tra ve (be rong da dung, chieu cao da dung)."""
    sp = beam['spans'][info['span']]
    b, h = max(sp['b'], 50.0), max(sp['h'], 50.0)
    fl_mm = 250.0
    tot = b + 2 * fl_mm
    ox = x0 + 44
    bx, by = ox + fl_mm * s, y0 + 46
    top_b = sp['top']
    sides = [('slabL', ox), ('slabR', bx + b * s)]
    if flip:
        sides = [('slabR', ox), ('slabL', bx + b * s)]
    cotes = [(by, top_b, 'top'), (by + h * s, top_b - h, 'bot')]
    for side, sx in sides:
        sl = sp.get(side)
        if not sl or sl[0] <= 0:
            if E is not None:                         # chua co san ben nay: o '+ san' de them
                cxs = sx + fl_mm * s / 2.0
                P.append(('text', cxs, by + 3, u'+ sàn', (150, 150, 150), 7, 'c', False))
                E.append(dict(key=('slab', spans, side[-1], 'th'), x0=cxs - 18, x1=cxs + 18, y0=by + 1, y1=by + 16, cur=0.0, text=False,
                              title=u'Thêm sàn bên %s dầm: nhập chiều dày sàn (mm). Đỉnh sàn mặc định = đỉnh dầm.' % (u'trái' if side == 'slabL' else u'phải')))
            continue
        th, ztop = sl
        dtop = top_b - ztop
        sy, sh = by + dtop * s, th * s
        P.append(('rect', sx, sy, fl_mm * s, sh, SLAB_FILL, (70, 70, 70)))
        _hatch(P, sx, sy, fl_mm * s, sh, 6, HATCH_S, True)
        left = sx == ox
        _zig(P, sx if left else sx + fl_mm * s, sy, sh, vertical=True)
        vdim(P, (sx - 8) if left else (sx + fl_mm * s + 8), sy, sy + sh, u'd=%d' % round(th), right=not left)
        if E is not None and sh >= 9:
            xe = (sx - 12 - 40) if left else (sx + fl_mm * s + 12)
            E.append(dict(key=('slab', spans, side[-1], 'th'), x0=xe, x1=xe + 40, y0=sy + sh / 2.0 - 7, y1=sy + sh / 2.0 + 9, cur=th, text=False,
                          title=u'Chiều dày sàn bên %s (mm). Nhập 0 để xóa sàn.' % (u'trái' if left else u'phải')))
        if abs(dtop) >= 1:
            vdim(P, (sx + 6) if left else (sx + fl_mm * s - 6), by, sy, u'giật %d' % round(abs(dtop)), right=not left, col=C_DELTA)
            cotes.append((sy, ztop, ('slab', side[-1])))
    P.append(('rect', bx, by, b * s, h * s, BEAM_FILL, (50, 50, 50)))
    _hatch(P, bx, by, b * s, h * s, 9, HATCH_B)
    c, sd = opt['cover'], opt['stir']
    P.append(('rect', bx + c * s, by + c * s, (b - 2 * c) * s, (h - 2 * c) * s, None, C_STIR))
    P.append(('rect', bx + (c + 1.5) * s, by + (c + 1.5) * s, (b - 2 * c - 3) * s, (h - 2 * c - 3) * s, None, C_STIR))
    if (sp.get('stir2') or u'').strip():                      # dai trong (dai 4 nhanh): hinh chu nhat hep o giua
        win = (b - 2 * c) / 3.0
        P.append(('rect', bx + (b - win) / 2.0 * s, by + (c + 1.5) * s, win * s, (h - 2 * c - 3) * s, None, (150, 120, 60)))
    asT = asB = asM = 0.0
    lines = []
    order = {B.POS[0]: 0, B.POS[2]: 1, B.POS[1]: 2}
    for (pos, ly), items in sorted(info['layers'].items(), key=lambda kv: (order[kv[0][0]], kv[0][1])):
        total = sum(n for n, d, gi in items)
        dmax = max(d for n, d, gi in items)
        xa, xb = c + sd + dmax / 2.0, b - c - sd - dmax / 2.0
        tight = False
        slots = []
        sp_txt = u''
        if pos == B.POS[2]:
            pairs = int(math.ceil(total / 2.0))
            off0 = c + sd + 16.0                                   # tam thep chu lop 1: thep than nam giua 2 lop thep chu
            for k in range(total):
                slots.append((xa if k % 2 == 0 else xb, off0 + (h - 2.0 * off0) * (k // 2 + 1) / (pairs + 1.0)))
        else:
            off = c + sd + dmax / 2.0 + (ly - 1) * (dmax + opt['pitch'])
            yc = off if pos == B.POS[0] else h - off
            pitch = (xb - xa) / (total - 1) if total > 1 else 0.0
            tight = total > 1 and (pitch - dmax) < max(25.0, dmax)
            for k in range(total):
                slots.append(((xa + xb) / 2.0 if total == 1 else xa + pitch * k, yc))
            sp_txt = (u' @%d' % round(pitch)) if total > 1 else u''
        k = 0
        for n, d, gi in items:
            for _ in range(n):
                cx, cy = slots[k]
                k += 1
                P.append(('circle', bx + cx * s, by + cy * s, max(d * s / 2.0, 2.5), _gcol(groups[gi], gi == sel),
                          (255, 60, 60) if tight else (40, 40, 40)))
            area = n * math.pi * d * d / 400.0
            if pos == B.POS[0]:
                asT += area
            elif pos == B.POS[1]:
                asB += area
            else:
                asM += area
        lines.append(u'%s lớp %d: %s%s%s' % (pos, ly, u' + '.join(u'%dØ%d' % (n, d) for n, d, gi in items), sp_txt,
                                             u'  (chật!)' if tight else u''))
    xr = ox + tot * s
    hdim(P, bx, bx + b * s, by + h * s + 14, u'b=%d' % round(b), up=False, col=C_TXT, size=8)
    vdim(P, xr + 10, by, by + h * s, u'h=%d' % round(h), right=True, col=C_TXT, size=8)
    P.append(('text', bx + 3, by + 2 * c * s, u'a=%d' % round(c), (130, 130, 130), 6.5, 'l', False))
    seen = []
    for yy, val, kd in cotes:                   # cote dinh dam / day dam / dinh san
        if any(abs(val - v2) < 1 for v2 in seen):
            continue
        seen.append(val)
        P.append(('line', bx + b * s if not flip else bx, yy, xr + 40, yy, (200, 200, 200), 1, True))
        cote(P, xr + 52, yy, val, tip_down=(yy <= by + 1), base=zb)
        if E is not None:                       # cote sua duoc: ap dung cho moi nhip co mat cat giong nhau
            ct = cote_txt(val, zb)
            ty = yy - 14 if (yy <= by + 1) else yy + 2
            if kd == 'top':
                kk_, ttl = ('top', spans), u'Cote ĐỈNH dầm (m). Gõ 3.6 hoặc 3600; áp dụng cho các nhịp có mặt cắt này. Đáy đổi theo h.'
            elif kd == 'bot':
                kk_, ttl = ('bot', spans), u'Cote ĐÁY dầm (m). Đỉnh giữ nguyên, h đổi.'
            else:
                kk_, ttl = ('slab', spans, kd[1], 'top'), u'Cote ĐỈNH sàn bên %s (m).' % (u'trái' if kd[1] == 'L' else u'phải')
            E.append(dict(key=kk_, x0=xr + 50, x1=xr + 50 + 7.0 * len(ct) + 4, y0=ty - 1, y1=ty + 12, cur=val, text=False,
                          unit='m', base=zb, title=ttl))
    if hl:
        P.append(('rect', x0 - 2, y0 - 4, (xr + 120) - x0, 46 + h * s + 40 + 13 * (len(lines) + 3), None, C_SEL))
    P.append(('text', bx + b * s / 2.0, y0 + 2, title, C_SEL if hl else C_TXT, 9.5, 'c', True))
    if caption:
        P.append(('text', bx + b * s / 2.0, y0 + 20, caption, C_DIM, 7.5, 'c', False))
    ty = by + h * s + 34
    for ln in lines:
        P.append(('text', bx + b * s / 2.0, ty, ln, C_TXT, 8, 'c', False))
        ty += 13
    if info['stir']:
        P.append(('text', bx + b * s / 2.0, ty, u'Đai Ø%da%d' % info['stir'], C_STIR, 8, 'c', True))
        ty += 13
        if (sp.get('stir2') or u'').strip():
            P.append(('text', bx + b * s / 2.0, ty, u'+ đai trong %s (4 nhánh)' % sp['stir2'], (150, 120, 60), 8, 'c', False))
            ty += 13
    P.append(('text', bx + b * s / 2.0, ty + 1, u'As trên %.2f | thân %.2f | dưới %.2f cm²' % (asT, asM, asB), C_DELTA, 8, 'c', True))
    return (xr + 120) - x0, ty + 18 - y0


def _prep_cuts(beam, groups, opt, lay, zones):
    """Cac vi tri cat (gối trái / giữa nhịp / gối phải moi nhip); gop cac mat cat giong nhau."""
    sp = beam['spans']
    cuts = []
    for i in range(len(sp)):
        c = sp[i]['clear']
        e = min(150.0, c * 0.12)
        cuts.append((lay['fl'][i] + e, i, u'gối trái'))
        cuts.append(((lay['fl'][i] + lay['fr'][i]) / 2.0, i, u'giữa nhịp'))
        cuts.append((lay['fr'][i] - e, i, u'gối phải'))
    infos = [cut_info(beam, groups, opt, lay, zones, i, x) for x, i, w in cuts]
    uniq, num = [], []
    for ci, info in enumerate(infos):
        sg = _sig(beam, info)
        for ui, (sg2, _) in enumerate(uniq):
            if sg2 == sg:
                num.append(ui)
                break
        else:
            uniq.append((sg, ci))
            num.append(len(uniq) - 1)
    return cuts, infos, uniq, num


def _draw_sections(P, beam, groups, opt, uniq, infos, num, cuts, y0, Wmax, sel, sel_span, flip, zb=0.0, E=None):
    """Ve cac mat cat (tu xuong hang khi het cho). Tra ve y duoi cung."""
    sp = beam['spans']
    hmax = max(s_['h'] for s_ in sp)
    s_sec = min(0.40, 170.0 / hmax)
    bmax = max(s_['b'] for s_ in sp)
    wcell = 44 + (bmax + 500.0) * s_sec + 125
    maxl = max([len(infos[ci0]['layers']) for sg, ci0 in uniq] + [1])
    hcell = 46 + hmax * s_sec + 34 + 13 * (maxl + 4) + 24
    sel_cut = None
    if sel_span is not None:
        for ci, (xc_, i_, wh) in enumerate(cuts):
            if i_ == sel_span and wh == u'giữa nhịp':
                sel_cut = num[ci]
    xcur, ycur = 12.0, y0
    for ui, (sg, ci0) in enumerate(uniq):
        if xcur + wcell > Wmax - 6 and xcur > 12.0:
            xcur, ycur = 12.0, ycur + hcell + 8
        where = [u'N%s %s' % (sp[cuts[k][1]]['idx'], cuts[k][2]) for k in range(len(cuts)) if num[k] == ui]
        cap = u', '.join(where[:3]) + (u' ...' if len(where) > 3 else u'')
        spans = tuple(sorted(set(cuts[k][1] for k in range(len(cuts)) if num[k] == ui)))
        _section_cell(P, beam, groups, opt, infos[ci0], xcur, ycur, s_sec, u'MẶT CẮT %d-%d' % (ui + 1, ui + 1),
                      cap, sel, flip, sel_cut == ui, zb, E, spans)
        xcur += wcell + 8
    return ycur + hcell


def render_sections(items, opt, view=None):
    """Che do chi ve mat cat ngang cho 1 hoac nhieu dam. items = [(beam, groups)]."""
    v = dict(Wfit=1200, H=520, flip=False, sel=None, span=None, absc=True)
    v.update(view or {})
    P = []
    y = 8.0
    for beam, groups in items:
        sp = beam['spans']
        if not sp:
            continue
        lay = B.layout(beam)
        zones = beam.get('zones')
        if zones is None:
            zones = B.derived_zones(beam, opt)
        P.append(('text', 8, y, u'Dầm %s   SL = %s   -  CÁC MẶT CẮT NGANG   (nhìn dọc dầm từ G0 → G%d, T = trái, P = phải)' % (
            beam['name'], beam['sl'], len(sp)), C_TXT, 11, 'l', True))
        cuts, infos, uniq, num = _prep_cuts(beam, groups, opt, lay, zones)
        sel = v['sel'] if len(items) == 1 else None
        y = _draw_sections(P, beam, groups, opt, uniq, infos, num, cuts, y + 34, v['Wfit'], sel,
                           v['span'] if len(items) == 1 else None, bool(v['flip']),
                           beam.get('level_z', 0.0) if v['absc'] else 0.0) + 24
    return P, int(v['Wfit']), dict(ml=0, oy=0, kx=1, ky=1, H=int(max(v['H'], y)), lay=None)


def render(beam, groups, opt, view=None):
    v = dict(ratio=0, vex=0, stir=True, sel=None, span=None, Wfit=1200, H=520, dims=1, flip=False, absc=True)
    v.update(view or {})
    zb = beam.get('level_z', 0.0) if v['absc'] else 0.0
    P = []
    sp, su = beam['spans'], beam['supports']
    n = len(sp)
    if n == 0:
        return P, v['Wfit'], dict(ml=0, oy=0, kx=1, ky=1, H=v['H'], lay=None)
    lay = B.layout(beam)
    beam['groups'] = groups                  # de build() biet cac thanh khac (neo tren / duoi be vao nhau)
    zones = beam.get('zones')
    if zones is None:
        zones = B.derived_zones(beam, opt)
    Lt = max(lay['L'], 1.0)
    npl = max([len(x.get('planted') or []) for x in sp] + [0])
    ml, mr, oy = 46, 20, 130 + ((54 + 20 * min(npl, 4)) if npl else 0)       # cot cay: them cho cho dim phia tren
    kx = (v['Wfit'] - ml - mr) / Lt if not v['ratio'] else PX_MM / float(v['ratio'])
    W = int(max(v['Wfit'], ml + mr + Lt * kx))
    ext = max(B.span_y(lay, s)[1] for s in sp)
    hp = max(100.0, min(300.0, v['H'] - 330))
    ky = kx * v['vex'] if v['vex'] else min(0.9, hp / ext)
    ybot = oy + ext * ky
    y_s, y_c, y_t = ybot + 70, ybot + 112, ybot + 176

    def X(mm):
        return ml + mm * kx

    def Y(mm):
        return oy + mm * ky

    def txt(x, y, s, col=C_TXT, size=8.5, al='c', bold=False):
        if s:
            P.append(('text', x, y, s, col, size, al, bold))

    E = []                                   # cac kich thuoc SUA DUOC (nhap dup): dict(key, x0, x1, y0, y1, cur, title, text)

    def eh(key, xa, xb, y, text, cur, title, up=False, col=C_DIM, size=7.5, bold=False, sub=None, istext=False):
        hdim(P, xa, xb, y, text, up=up, col=col, size=size, bold=bold, sub=sub)
        cx, hw = (xa + xb) / 2.0, max((xb - xa) / 2.0, 14.0)
        ty = y - 14 if up else y + 2
        E.append(dict(key=key, x0=cx - hw, x1=cx + hw, y0=min(y, ty) - 3, y1=max(y, ty + 12) + 3, cur=cur, title=title, text=istext))

    cuts, infos, uniq, num = _prep_cuts(beam, groups, opt, lay, zones)
    sel = v['sel'] if (v['sel'] is not None and 0 <= v['sel'] < len(groups)) else None
    # ---- nhip dang chon
    if v['span'] is not None and 0 <= v['span'] < n:
        i = v['span']
        P.append(('rect', X(lay['fl'][i]), 84, (lay['fr'][i] - lay['fl'][i]) * kx, y_t + 24 - 84, (255, 249, 205), None))
    # ---- truc luoi
    for k in range(n + 1):
        xc = X(lay['sx0'][k] + su[k]['w'] / 2.0)          # tim goi
        if su[k]['w'] > 0:
            off = su[k].get('off') or 0.0                  # lech truc (mm) tu Excel: truc luoi Revit - tim goi
            xg = xc + off * kx                             # truc luoi THAT (khong con ve tai tim goi)
            if abs(off) >= 1.0:
                P.append(('line', xc, 96, xc, y_s - 8, (190, 190, 190), 1, True))      # tim goi (net nhat)
                eh(('off', k), min(xc, xg), max(xc, xg), 104, u'%+d' % round(off), off, u'Lệch trục lưới - tim gối G%d (mm, + = lưới nằm bên phải tim gối)' % k,
                   up=True, col=(190, 100, 10), size=7)
            P.append(('line', xg, 82, xg, y_s - 8, C_AXIS, 1, True))
            P.append(('circle', xg, 70, 12, (255, 255, 255), C_AXIS))
            E.append(dict(key=('gname', k), x0=xg - 13, x1=xg + 13, y0=57, y1=83, cur=su[k].get('grid') or u'', text=True,
                          title=u'Tên trục lưới tại gối G%d (ví dụ A, 3; để trống = xóa trục). Lệch trục: sửa số cam bên cạnh' % k))
            if abs(off) < 1.0:                             # chua lech: van co o so '0' de nhap lech truc
                txt(xg + 16, 74, u'0', (190, 100, 10), 7, 'l')
                E.append(dict(key=('off', k), x0=xg + 14, x1=xg + 28, y0=73, y1=85, cur=0.0, text=False,
                              title=u'Lệch trục lưới - tim gối G%d (mm, + = lưới nằm bên phải tim gối)' % k))
            txt(xg, 63, (su[k].get('grid') or u'-')[:4], C_AXIS, 8, 'c', True)
            txt(xg + 15, 63, u'G%d' % k, (150, 150, 150), 7, 'l')
        elif su[k]['kind'] == u'Đổi tiết diện':          # goi ao: cho doi tiet dien / ha cote
            P.append(('line', xc, 96, xc, y_s - 8, C_DELTA, 1, True))
            txt(xc, 82, u'G%d' % k, C_DELTA, 7.5, 'c', True)

    def zone(k):
        adj = [sp[j] for j in (k - 1, k) if 0 <= j < n]
        return (min(B.span_y(lay, s)[0] for s in adj), max(B.span_y(lay, s)[1] for s in adj))
    # ---- cot + be tong
    for k in range(n + 1):
        w = su[k]['w']
        yt, yb = zone(k)
        if w > 0 and su[k]['kind'] == u'Cột':
            x0, wd = X(lay['sx0'][k]), max(w * kx, 6)
            role = su[k].get('role') or ''
            thru = (u'tiếp tục' in role) or (u'liên tục' in role)      # cot lien tuc (co cot tren): ve ca tren + duoi dam
            lower = (u'Cột dưới' in role) and not thru   # cot duoi dung lai o dam (khong co cot tren) -> chi ve phia duoi dam
            y0 = Y(yt) if lower else Y(yt) - 44
            hh = Y(yb) + 44 - y0
            P.append(('rect', x0, y0, wd, hh, COL_FILL, (110, 110, 110)))
            _hatch(P, x0, y0, wd, hh, 9, HATCH_C)
            if not lower:
                _zig(P, x0, y0 + 2, wd)
            _zig(P, x0, y0 + hh - 2, wd)
            dep = su[k].get('dep')
            lab_c = u'%s %dx%s' % ((su[k].get('ref') or u'Cột')[:8], round(w), (u'%d' % round(dep)) if dep else u'?')
            txt(x0 + wd / 2.0, y0 + hh + 9, lab_c, (90, 90, 90), 7, 'c')
            E.append(dict(key=('colsec', 's', k), x0=x0 + wd / 2.0 - 3.6 * len(lab_c) - 3, x1=x0 + wd / 2.0 + 3.6 * len(lab_c) + 3,
                          y0=y0 + hh + 6, y1=y0 + hh + 19, text=True,
                          cur=((su[k].get('ref') + u' ') if su[k].get('ref') else u'') + u'%dx%d' % (round(w), round(dep or w)),
                          title=u'Tiết diện cột G%d: "Tên  RộngDọcDầm x CạnhVuôngGócDầm" (mm), ví dụ C9 400x600. Đổi rộng dọc dầm: tim cột giữ nguyên, thông thủy 2 nhịp kề đổi. Tên có thể bỏ trống.' % k))
            if su[k].get('ref'):
                txt(x0 + wd / 2.0, y0 + hh + 18, u'cột dưới - đỡ dầm' if lower else (u'cột liên tục - đỡ dầm' if thru else (u'băng qua dầm' if u'Băng qua' in role else u'đỡ dầm')), (90, 90, 90), 6.5, 'c')
        elif w > 0 and su[k]['kind'] == u'Dầm':
            P.append(('rect', X(lay['sx0'][k]), Y(yt), max(w * kx, 6), (yb - yt) * ky, (222, 236, 214), None))
    for i in range(n):
        t, bt = B.span_y(lay, sp[i])
        x0, wd, y0, hh = X(lay['fl'][i]), (lay['fr'][i] - lay['fl'][i]) * kx, Y(t), (bt - t) * ky
        P.append(('rect', x0, y0, wd, hh, BEAM_FILL, (60, 60, 60)))
        _hatch(P, x0, y0, wd, hh, 12, HATCH_B)
    for k in range(n + 1):
        w = su[k]['w']
        if w > 0:
            yt, yb = zone(k)
            P.append(('rect', X(lay['sx0'][k]), Y(yt), max(w * kx, 4), (yb - yt) * ky, (232, 236, 244), (60, 60, 60)))
    # ---- COT CAY LEN DAM: chan cot nam tren dam (Base Level = tang dam) -> ve phia TREN mat dam, khong phai goi
    for i in range(n):
        t, bt = B.span_y(lay, sp[i])
        for q in sp[i].get('planted') or []:
            wq = q.get('w') or 300.0
            xm = lay['fl'][i] + q['pos']      # pos = tam cot tinh tu mep goi trai, KHONG ep vao trong nhip (cot tren nut giao nam trong vung goi)
            x0, wd = X(xm - wq / 2.0), max(wq * kx, 6)
            y0 = Y(t) - 46
            P.append(('rect', x0, y0, wd, 46, (255, 236, 214), (190, 100, 10)))
            _hatch(P, x0, y0, wd, 46, 8, (225, 170, 110))
            _zig(P, x0, y0 + 2, wd, (190, 100, 10))
            P.append(('line', x0, Y(t), x0 + wd, Y(t), (190, 100, 10), 2, False))
            txt(x0 + wd + 3, y0 + 14, u'%s %dx%s' % (q['name'][:8], round(wq), (u'%d' % round(q['dep'])) if q.get('dep') else u'?'), (190, 100, 10), 7.5, 'l', True)
            txt(x0 + wd + 3, y0 + 25, u'cột cấy lên dầm', (190, 100, 10), 6.5, 'l')
    # ---- DIM COT CAY: (1) chuoi mep goi - mep cot - be rong cot - mep goi (2) truc luoi -> tim cot
    def xgrid(k):
        return lay['sx0'][k] + su[k]['w'] / 2.0 + (su[k].get('off') or 0.0)

    def has_grid(k):
        return su[k]['w'] > 0 and bool((su[k].get('grid') or '').strip())
    OC = (190, 100, 10)
    for i in range(n):
        pls = sorted(sp[i].get('planted') or [], key=lambda q: q['pos'])
        if not pls:
            continue
        t, bt = B.span_y(lay, sp[i])
        y_ch = Y(t) - 60
        prev_end, last_j = lay['fl'][i], len(pls) - 1
        for j, q in enumerate(pls):
            wq = q.get('w') or 300.0
            xm = lay['fl'][i] + q['pos']
            a, b = xm - wq / 2.0, xm + wq / 2.0
            if a - prev_end > 1.0:
                eh(('plgap', i, j, 'left' if j == 0 else 'between'), X(prev_end), X(a), y_ch, u'%d' % round(a - prev_end),
                   a - prev_end, (u'Cột cấy %s: khoảng hở mép gối trái → mép cột (mm)' if j == 0 else u'Cột cấy %s: khoảng hở từ cột trước → mép cột (mm)') % q['name'],
                   up=True, col=OC, size=7.5)
            eh(('plw', i, j), X(a), X(b), y_ch, u'%d' % round(wq), wq, u'Cột cấy %s: bề rộng (mm). Nhập 0 để xóa cột này' % q['name'],
               up=True, col=OC, size=7.5, bold=True)
            E.append(dict(key=('colsec', 'p', i, j), x0=X(a), x1=X(b) + 90, y0=Y(t) - 46, y1=Y(t), text=True,
                          cur=u'%s %dx%d' % (q['name'], round(wq), round(q.get('dep') or wq)),
                          title=u'Tiết diện cột cấy: "Tên  RộngDọcDầm x CạnhVuôngGócDầm" (mm), ví dụ CP 300x600. Đổi rộng dọc dầm: tim cột giữ nguyên.'))
            prev_end = b
            row = y_ch - 20 * (1 + (j % 4))
            if has_grid(i) and xgrid(i) < xm:
                eh(('plgrid', i, j, 'L'), X(xgrid(i)), X(xm), row, u'%d' % round(xm - xgrid(i)), xm - xgrid(i),
                   u'Cột cấy %s: từ trục %s → tim cột (mm)' % (q['name'], su[i].get('grid') or u'-'), up=True, col=OC, size=7)
            if has_grid(i + 1) and xgrid(i + 1) > xm:
                eh(('plgrid', i, j, 'R'), X(xm), X(xgrid(i + 1)), row, u'%d' % round(xgrid(i + 1) - xm), xgrid(i + 1) - xm,
                   u'Cột cấy %s: từ tim cột → trục %s (mm)' % (q['name'], su[i + 1].get('grid') or u'-'), up=True, col=OC, size=7)
            P.append(('line', X(xm), Y(t) - 46, X(xm), row, OC, 1, True))          # giong tim cot len cac dim
        if lay['fr'][i] - prev_end > 1.0:
            eh(('plgap', i, last_j, 'right'), X(prev_end), X(lay['fr'][i]), y_ch, u'%d' % round(lay['fr'][i] - prev_end),
               lay['fr'][i] - prev_end, u'Cột cấy %s: khoảng hở mép cột → mép gối phải (mm)' % pls[last_j]['name'], up=True, col=OC, size=7.5)
    # ---- lech cote tai goi + cote tung nhip
    for k in range(1, n):
        ta, tb = B.span_y(lay, sp[k - 1]), B.span_y(lay, sp[k])
        xc = X(lay['sx0'][k] + su[k]['w'] / 2.0)
        if abs(ta[0] - tb[0]) >= 1:
            txt(xc, Y(min(ta[0], tb[0])) - 16, u'lệch đỉnh %d' % round(abs(ta[0] - tb[0])), C_DELTA, 7.5, 'c', True)
        if abs(ta[1] - tb[1]) >= 1:
            txt(xc, Y(max(ta[1], tb[1])) + 5, u'lệch đáy %d' % round(abs(ta[1] - tb[1])), C_DELTA, 7.5, 'c', True)
    # ---- dai (theo vung)
    if v['stir']:
        supint = [(lay['sx0'][k], lay['sx0'][k] + su[k]['w']) for k in range(n + 1)]
        for z in zones:
            x, cnt = z['x0'] + z['a'] / 2.0, 0
            while x < z['x1'] and cnt < 800:
                for i in range(n):
                    if lay['fl'][i] <= x <= lay['fr'][i]:
                        t, bt = B.span_y(lay, sp[i])
                        P.append(('line', X(x), Y(t + opt['cover']), X(x), Y(bt - opt['cover']), C_STIR, 1, False))
                        break
                x += max(z['a'], 3.0 / kx)
                cnt += 1
    # ---- thep
    order = [i for i in range(len(groups)) if i != sel] + ([sel] if sel is not None else [])
    sel_span = v['span']
    built = {}
    stag = 0
    for gi in order:
        g = groups[gi]
        lines = B.build(g, beam, opt, lay)
        built[gi] = lines
        if not lines:
            continue
        is_sel = gi == sel
        col = _gcol(g, is_sel)
        wd = max(2.0, float(g['d']) * 0.2) + (2 if is_sel else 0)
        best = None
        for q in lines:
            for p0, p1 in zip(q[:-1], q[1:]):
                P.append(('line', X(p0[0]), Y(p0[1]), X(p1[0]), Y(p1[1]), col, wd, False))
                ln = abs(p1[0] - p0[0])
                if best is None or ln > best[0]:
                    best = (ln, (p0[0] + p1[0]) / 2.0, (p0[1] + p1[1]) / 2.0)
        if best:
            r = 9 if is_sel else 8
            cx, cy = X(best[1]), Y(best[2])
            P.append(('circle', cx, cy, r, (255, 255, 255), col))
            txt(cx, cy - 7, str(gi + 1), col, 8, 'c', True)
            above = g['pos'] != B.POS[1]
            txt(cx + r + 3, cy - (19 if above else -3), u'%dØ%d' % (int(g['n']), int(g['d'])), col, 8, 'l', True)
        if is_sel:
            txt(W / 2.0, 92, B.describe(g, lines), C_SEL, 10, 'c', True)
            if sel_span is None and best:
                for i in range(n):
                    if lay['fl'][i] <= best[1] <= lay['fr'][i]:
                        sel_span = i
            if g['lk'] != B.K_UON and g['rk'] != B.K_UON:
                for p in (lines[0][0], lines[-1][-1]):
                    P.append(('rect', X(p[0]) - 5, Y(p[1]) - 5, 10, 10, (255, 255, 255), C_SEL))
    # ---- vach cat mat cat tren mat dung
    last_x = -1e9
    for (xcut, i, wh), ui in zip(cuts, num):
        t, bt = B.span_y(lay, sp[i])
        xc = X(xcut)
        hl = sel_span == i and wh == u'giữa nhịp'
        if xc - last_x < 30 and not hl:          # nhip hep: bo bot vach cat trung nhau cho do roi
            continue
        last_x = xc
        col = C_SEL if hl else C_CUT
        P.append(('line', xc, Y(t) - 10, xc, Y(bt) + 10, col, 1, True))
        P.append(('line', xc - 6, Y(bt) + 10, xc + 6, Y(bt) + 10, col, 3, False))
        P.append(('line', xc - 6, Y(t) - 10, xc + 6, Y(t) - 10, col, 3, False))
        txt(xc, Y(bt) + 14, u'%d-%d' % (ui + 1, ui + 1), col, 8, 'c', True)
    # ---- dim cho thep
    if v['dims']:
        dim_ids = [sel] if (v['dims'] == 1 and sel is not None) else ([] if v['dims'] == 1 else list(range(len(groups))))
        for gi in dim_ids:
            g, lines = groups[gi], built.get(gi) or B.build(groups[gi], beam, opt, lay)
            up = g['pos'] != B.POS[1]
            off = (-20 - 12 * (stag % 3)) if up else (20 + 12 * (stag % 3))
            stag += 1
            col = C_SEL if gi == sel else _gcol(g)
            for q in lines:
                for p0, p1 in zip(q[:-1], q[1:]):
                    dx, dy = abs(p1[0] - p0[0]), abs(p1[1] - p0[1])
                    ln = math.hypot(dx, dy)
                    xa, xb = X(min(p0[0], p1[0])), X(max(p0[0], p1[0]))
                    ya, yb = Y(p0[1]), Y(p1[1])
                    if ln * kx < 6 and dy * ky < 6:
                        continue
                    if dx >= 2 * dy and xb - xa >= 12:
                        yd = (ya + yb) / 2.0 + off
                        P.append(('line', xa, (ya + yb) / 2.0, xa, yd, (200, 200, 200), 1, False))
                        P.append(('line', xb, (ya + yb) / 2.0, xb, yd, (200, 200, 200), 1, False))
                        hdim(P, xa, xb, yd, u'%d' % round(dx), up=up, col=col, size=7.5, bold=gi == sel)
                    elif dy >= 2 * dx and abs(yb - ya) >= 8:
                        vdim(P, xa + 12, min(ya, yb), max(ya, yb), u'%d' % round(dy), right=True, col=col)
                    else:
                        txt((xa + xb) / 2.0 + 8, (ya + yb) / 2.0 - 5, u'%d' % round(ln), col, 7, 'l', gi == sel)
    # ---- cote tung nhip (ve sau cung de nam tren cac dim)
    def ecote(i, xp, yp, val, tip_down, kind):
        cote(P, xp, yp, val, tip_down=tip_down, base=zb)
        ct = cote_txt(val, zb)
        ty = yp - 14 if tip_down else yp + 2
        ttl = (u'Cote ĐỈNH dầm nhịp N%s (m): gõ 3.6 hoặc 3600. Thêm * (3.6*) để đặt cùng cote cho TẤT CẢ nhịp. Đáy đổi theo h.' if kind == 'top'
               else u'Cote ĐÁY dầm nhịp N%s (m): đỉnh giữ nguyên, h đổi. Thêm * để áp dụng TẤT CẢ nhịp.') % sp[i]['idx']
        E.append(dict(key=(kind, i), x0=xp + 10, x1=xp + 10 + 7.0 * len(ct) + 4, y0=ty - 1, y1=ty + 12, cur=val, text=False,
                      unit='m', base=zb, title=ttl))
    for i in range(n):
        t, bt = B.span_y(lay, sp[i])
        ecote(i, X(lay['fl'][i] + 0.62 * sp[i]['clear']), Y(t), sp[i]['top'], True, 'top')
        ecote(i, X(lay['fl'][i] + 0.30 * sp[i]['clear']), Y(bt), sp[i]['top'] - sp[i]['h'], False, 'bot')
        if X(lay['fr'][i]) - X(lay['fl'][i]) >= 46:      # tiet dien b x h cua doan ngay tren mat dung
            lab = u'%dx%d' % (round(sp[i]['b']), round(sp[i]['h']))
            xm_, ym_ = (X(lay['fl'][i]) + X(lay['fr'][i])) / 2.0, (Y(t) + Y(bt)) / 2.0
            P.append(('rect', xm_ - 3.6 * len(lab) - 2, ym_ - 7, 7.2 * len(lab) + 4, 14, (255, 255, 255), (150, 150, 150)))
            P.append(('text', xm_, ym_ - 6, lab, C_TXT, 8, 'c', True))
            E.append(dict(key=('sec', i), x0=xm_ - 3.6 * len(lab) - 2, x1=xm_ + 3.6 * len(lab) + 2, y0=ym_ - 7, y1=ym_ + 7, text=True, cur=lab,
                          title=u'Tiết diện nhịp N%s: b x h (mm), ví dụ 300x600. Thêm * ở cuối (300x600*) để áp dụng cho TẤT CẢ nhịp của dầm. Cao đỉnh giữ nguyên, đáy dầm đổi theo h.' % sp[i]['idx']))
    # ---- dim dai theo vung
    for z in zones:
        cnt = max(int(round((z['x1'] - z['x0']) / float(z['a']))), 1)
        hdim(P, X(z['x0']), X(z['x1']), y_s, u'Ø%da%d' % (z['d'], z['a']), up=True, col=C_STIR, size=7.5, bold=True,
             sub=u'%d@%d=%d' % (cnt, z['a'], round(z['x1'] - z['x0'])))
    # ---- chuoi kich thuoc
    for k in range(n + 1):
        if su[k]['w'] > 0:
            eh(('w', k), X(lay['sx0'][k]), X(lay['sx0'][k] + su[k]['w']), y_c, u'%d' % round(su[k]['w']), su[k]['w'],
               u'Bề rộng gối G%d (mm). Tim gối giữ nguyên, thông thủy 2 nhịp kề bên tự đổi' % k, up=True, col=C_DIM, size=7)
    for i in range(n):
        sh = 30 if ((X(lay['fr'][i]) - X(lay['fl'][i])) < 125 and i % 2) else 0
        hdim(P, X(lay['fl'][i]), X(lay['fr'][i]), y_c, u'', col=C_DIM)
        txt((X(lay['fl'][i]) + X(lay['fr'][i])) / 2.0, y_c + 3 + sh, u'N%s: %d  (%dx%d)' % (sp[i]['idx'], round(sp[i]['clear']), round(sp[i]['b']), round(sp[i]['h'])), C_TXT, 8.5, 'c', True)
        xmid = (X(lay['fl'][i]) + X(lay['fr'][i])) / 2.0
        E.append(dict(key=('clear', i), x0=xmid - 62, x1=xmid + 62, y0=y_c + 1 + sh, y1=y_c + 16 + sh, cur=sp[i]['clear'], text=False,
                      title=u'Nhịp N%s - chiều dài thông thủy (mm). Các nhịp phía sau tự dịch theo' % sp[i]['idx']))
        xm0 = (X(lay['fl'][i]) + X(lay['fr'][i])) / 2.0
        for dy_, kk_, val_, pre_, col_ in ((17, 'stir', sp[i].get('stir') or u'', u'đai ', C_STIR),
                                           (29, 'stir2', sp[i].get('stir2') or u'', u'đai trong ', (130, 130, 130))):
            lab_ = pre_ + (val_ or u'-')
            hw_ = 2.2 * len(lab_) + 3
            txt(xm0, y_c + dy_ + sh, lab_, col_, 7.5, 'c', kk_ == 'stir')
            E.append(dict(key=(kk_, i), x0=xm0 - hw_, x1=xm0 + hw_, y0=y_c + dy_ + sh - 1, y1=y_c + dy_ + sh + 12, cur=val_, text=True,
                          title=(u'%s nhịp N%s: Ø-a gối/a nhịp, ví dụ 8-100/200. Thêm * (8-100/200*) để áp dụng TẤT CẢ nhịp. Để trống = xóa.'
                                 % (u'Đai' if kk_ == 'stir' else u'Đai trong', sp[i]['idx']))))
    cen = [lay['sx0'][k] + su[k]['w'] / 2.0 for k in range(n + 1)]
    for i in range(n):
        eh(('cc', i), X(cen[i]), X(cen[i + 1]), y_t, u'%d' % round(cen[i + 1] - cen[i]), cen[i + 1] - cen[i],
           u'Nhịp N%s - tim gối → tim gối (mm). Thay đổi cộng vào chiều dài thông thủy' % sp[i]['idx'], up=True, col=C_DIM, size=7.5)
    hdim(P, X(cen[0]), X(cen[-1]), y_t + 24, u'Tổng tim-tim = %d' % round(cen[-1] - cen[0]), up=False, col=C_TXT, size=8, bold=True)
    # ---- CHUOI TRUC LUOI: khoang cach truc-truc (da tinh lech truc), tong truc-truc
    gk = [k for k in range(n + 1) if has_grid(k)]
    y_g = y_t + 62
    for i in range(n):
        if has_grid(i) and has_grid(i + 1):
            eh(('grid', i), X(xgrid(i)), X(xgrid(i + 1)), y_g, u'%d' % round(xgrid(i + 1) - xgrid(i)), xgrid(i + 1) - xgrid(i),
               u'Nhịp N%s - trục %s → trục %s (mm). Thay đổi cộng vào chiều dài thông thủy' % (sp[i]['idx'], su[i].get('grid') or u'-', su[i + 1].get('grid') or u'-'),
               up=True, col=C_AXIS, size=7.5)
    if len(gk) >= 2:
        hdim(P, X(xgrid(gk[0])), X(xgrid(gk[-1])), y_g + 24, u'Tổng trục-trục = %d' % round(xgrid(gk[-1]) - xgrid(gk[0])), up=False, col=C_AXIS, size=8, bold=True)
        txt(4, y_g - 4, u'Trục-trục', C_AXIS, 7, 'l')
    txt(4, y_t - 4, u'Tim-tim', C_DIM, 7, 'l')
    # ---- cac mat cat ngang
    y_sec = y_t + (78 + 56 if len(gk) >= 2 else 78)
    P.append(('line', 8, y_sec - 12, W - 8, y_sec - 12, (205, 205, 205), 1, False))
    hbot = _draw_sections(P, beam, groups, opt, uniq, infos, num, cuts, y_sec, float(W), sel, sel_span, bool(v['flip']), zb, E)
    Hreq = int(max(v['H'], hbot + 20))
    # ---- tieu de + chu giai
    d_txt = beam.get('dir') or ''
    mm_ = re.search(r'\((.*)\)', d_txt)
    view_txt = mm_.group(1) if mm_ else (u'trái → phải' if d_txt.startswith(u'Ngang') else (u'trên → dưới' if d_txt.startswith(u'Đứng') else u''))
    txt(8, 6, u'Dầm %s   SL = %s     (mm%s)%s' % (beam['name'], beam['sl'], u'' if v['vex'] == 1 else u', trục đứng phóng đại',
                                                 (u'     Hướng nhìn trên mặt bằng: ' + view_txt) if view_txt else u''), C_TXT, 10, 'l', True)
    lx = 8
    for lab, col in ((u'Thép trên', C_TOP), (u'Thép dưới', C_BOT), (u'Thép thân', C_MID), (u'Nhóm đang chọn', C_SEL)):
        P.append(('line', lx, 36, lx + 22, 36, col, 4, False))
        txt(lx + 28, 29, lab, C_DIM, 8.5, 'l')
        lx += 118
    txt(lx + 6, 29, u'Số trong vòng tròn = STT nhóm thép. Mặt cắt nhìn dọc dầm từ G0 → G%d (T = trái, P = phải khi nhìn)' % n, C_DIM, 8.5, 'l')
    return P, W, dict(ml=ml, oy=oy, kx=kx, ky=ky, H=Hreq, lay=lay, dims=E)
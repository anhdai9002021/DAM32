# -*- coding: utf-8 -*-
"""Dam mau co doi tiet dien, lech cote, san giat cap; dien san cac nhom thep kem ghi chu de hieu cach dien."""
import bm_bars as B


def make(name):
    sup = [dict(w=400.0, kind=u'Cột', grid=g) for g in ('1', '2', '3', '4')]
    spans = [dict(idx=1, clear=4000.0, b=300.0, h=600.0, top=0.0, stir='8-100/200', stir2='',
                  slabL=(120.0, 0.0), slabR=(120.0, 0.0)),
             dict(idx=2, clear=3000.0, b=300.0, h=600.0, top=-80.0, stir='8-100/200', stir2='8-200/400',
                  slabL=(120.0, -80.0), slabR=(150.0, -130.0)),
             dict(idx=3, clear=3500.0, b=300.0, h=450.0, top=-250.0, stir='8-100/200', stir2='',
                  slabL=(100.0, -250.0), slabR=(100.0, -300.0))]
    beam = dict(name=name, sl=1, supports=sup, spans=spans)
    T, D, M = B.POS
    G = [
        B.new_group(pos=T, layer=1, n=3, d=18, a=0, b=3, lk=B.K_GAP, lv='xuống', rk=B.K_HET,
                    note=u'Thép trên chạy suốt, đầu trái GẬP vào cột (xuống sát lớp thép dưới), đầu phải kéo HẾT cột. '
                         u'Qua G1 lệch đỉnh 80 (50 < 80 ≤ 100) → UỐN 1:6. Qua G2 lệch đỉnh 170 (> 100) → CẮT và NEO vào gối.'),
        B.new_group(pos=D, layer=1, n=3, d=18, a=0, b=1, lk=B.K_NEO, lv='30d', rk=B.K_NEO, rv='30d',
                    note=u'Thép dưới nhịp N1: neo thẳng 30d vào 2 gối (G0, G1).'),
        B.new_group(pos=D, layer=1, n=3, d=18, a=1, b=3, lk=B.K_NEO, lv='30d', rk=B.K_NEO, rv='30d',
                    note=u'Thép dưới N2+N3 chạy liền qua G2: lệch đáy chỉ 20 (≤ 50) → NỐI THẲNG một cao độ, không uốn, không cắt.'),
        B.new_group(pos=D, layer=2, n=2, d=16, a=0, b=2, lk=B.K_NEO, lv='30d', rk=B.K_NEO, rv='30d',
                    note=u'Thép dưới lớp 2 chạy qua G1: lệch đáy 80 → tự UỐN 1:6 chuyển tầng.'),
        B.new_group(pos=T, layer=2, n=2, d=16, a=1, b=1, lk=B.K_EXT, lv='L/3', rk=B.K_EXT, rv='L/3',
                    note=u'Tăng cường trên gối G1: Từ gối = Đến gối = 1, kéo ra 2 bên L/3 (L = nhịp thông thủy).'),
        B.new_group(pos=T, layer=2, n=2, d=16, a=0, b=0, lk=B.K_GAP, lv='xuống', rk=B.K_EXT, rv='L/3',
                    note=u'Tăng cường gối đầu G0: MỘT đầu gập vào cột (xuống sát lớp dưới, lớp 2 gập lọt vào trong lớp 1), MỘT đầu kéo ra nhịp L/3.'),
        B.new_group(pos=D, layer=2, n=2, d=16, a=1, b=2, lk=B.K_CUT, lv='L/5', rk=B.K_CUT, rv='L/5',
                    note=u'Tăng cường dưới giữa nhịp N2: cắt trong nhịp, cách mép gối L/5 mỗi đầu.'),
        B.new_group(pos=D, layer=1, n=1, d=18, a=1, b=2, lk=B.K_NEO, lv='30d', rk=B.K_UON, rv='L/6;L/4',
                    note=u'Thép uốn xiên 45° lên gối G2: bắt đầu uốn cách mép gối L/6, đi tiếp qua gối L/4.'),
        B.new_group(pos=T, layer=2, n=2, d=16, a=3, b=3, lk=B.K_EXT, lv='L/3', rk=B.K_GAP, rv='xuống',
                    note=u'Tăng cường gối cuối G3: kéo ra nhịp L/3 và BẺ xuống bằng dầm vào cột ở phía ngoài.'),
        B.new_group(pos=M, layer=1, n=2, d=12, a=0, b=3, lk=B.K_NEO, lv='30d', rk=B.K_NEO, rv='30d',
                    note=u'Thép thân (giá) giữa chiều cao dầm: vị trí "Giữa", 2Ø12 chạy suốt, neo 30d.'),
    ]
    return beam, G

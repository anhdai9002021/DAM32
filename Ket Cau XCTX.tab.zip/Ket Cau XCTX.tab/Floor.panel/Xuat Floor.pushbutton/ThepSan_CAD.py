# -*- coding: utf-8 -*-
"""Triển khai Thép Sàn -> AutoCAD (Chuẩn mẫu DXF + Tỉ lệ Revit + Pick Revit -> CAD)"""
import sys, os, json, math, time, tkinter as tk
from tkinter import ttk, filedialog, messagebox

CFG_FILE = os.path.join(os.path.expanduser("~"), ".thepsan_cad.json")
HDL_FILE = os.path.join(os.path.expanduser("~"), ".thepsan_handles.json")

DEFAULT_CFG = {
    "concrete": "B25", "steel": "CB400-V",
    "cover": 15.0, "dcote": 50.0, "gap": 500.0,
    "main_axis": "auto", "beam_end": 50.0,
    "clip_slab": True, "hole_skip": 500.0, "slab_skip": 500.0, "draw_sep": 4.5,
    "beam_ztol": 50.0, "use_beam": True, "use_col": True,
    "lock_revit_scale": True, "custom_scale": 75.0,
    "sample_style": True, "draw_plan_geom": True, "draw_range": False,
    "draw_title": True, "draw_schedule": True,
    "split_table": True, "max_rows_per_frame": 30,
    "ten_cau_kien": "SÀN TẦNG 2", "ten_ky_hieu": "SÀN T2",
    "sl_san": 1,
    "cad_sc": 1.0,
    "layers": {
        "duoi_chinh": {"dia": 10, "pitch": 200, "hook": "thang", "hook_l": 100.0, "mode": "10d", "on": True},
        "duoi_phu":   {"dia": 10, "pitch": 200, "hook": "thang", "hook_l": 100.0, "mode": "10d", "on": True},
        "tren_chinh": {"dia": 10, "pitch": 200, "hook": "vuong", "hook_l": 100.0, "mode": "10d", "on": True},
        "tren_phu":   {"dia": 10, "pitch": 200, "hook": "vuong", "hook_l": 100.0, "mode": "10d", "on": True},
    }
}

STEEL_FY = {"CB300-V": 260, "CB400-V": 350, "CB500-V": 435}
CONC_FBT = {"B15": 0.75, "B20": 0.90, "B25": 1.05, "B30": 1.15}

LAYER_META = [
    ("duoi_chinh", "Dưới chính", "#22d3ee"),
    ("duoi_phu",   "Dưới phụ",   "#a3e635"),
    ("tren_chinh", "Trên chính", "#ff5555"),
    ("tren_phu",   "Trên phụ",   "#fb923c"),
]

# ─── GEOMETRY HELPERS ─────────────────────────────────────────────────────────
def _pdist(a, b): return math.hypot(a[0] - b[0], a[1] - b[1])
def _dot(a, b): return a[0] * b[0] + a[1] * b[1]

def _poly_area(pts):
    n = len(pts)
    if n < 3: return 0.0
    return abs(sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n))) * 0.5

def _poly_bbox(pts):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)

def _pip(pt, poly):
    x, y = pt; inside = False; n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]; x2, y2 = poly[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            xi = (x2 - x1) * (y - y1) / (y2 - y1) + x1
            if x < xi: inside = not inside
    return inside

def _seg_pt_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    if l2 < 1e-12: return _pdist(p, a)
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2))
    return _pdist(p, (a[0] + t * dx, a[1] + t * dy))

def _poly_edge_dist(p1, p2):
    if any(_pip(p, p2) for p in p1) or any(_pip(p, p1) for p in p2): return 0.0
    md = 1e18
    for a in p1:
        for j in range(len(p2)):
            md = min(md, _seg_pt_dist(a, p2[j], p2[(j + 1) % len(p2)]))
    for b in p2:
        for i in range(len(p1)):
            md = min(md, _seg_pt_dist(b, p1[i], p1[(i + 1) % len(p1)]))
    return md

def _line_line_int(a1, a2, b1, b2):
    dx1, dy1 = a2[0] - a1[0], a2[1] - a1[1]
    dx2, dy2 = b2[0] - b1[0], b2[1] - b1[1]
    det = dx1 * dy2 - dy1 * dx2
    if abs(det) < 1e-9: return None
    t = ((b1[0] - a1[0]) * dy2 - (b1[1] - a1[1]) * dx2) / det
    return (a1[0] + t * dx1, a1[1] + t * dy1)

def _poly_spans(poly):
    if len(poly) < 2:
        return 0.0, 0.0
    x0, y0, x1, y1 = _poly_bbox(poly)
    best_min = min(x1 - x0, y1 - y0)
    best_max = max(x1 - x0, y1 - y0)
    n = len(poly)
    for i in range(n):
        dx = poly[(i + 1) % n][0] - poly[i][0]
        dy = poly[(i + 1) % n][1] - poly[i][1]
        L = math.hypot(dx, dy)
        if L < 1e-6:
            continue
        ux, uy = dx / L, dy / L
        vx, vy = -uy, ux
        us = [p[0] * ux + p[1] * uy for p in poly]
        vs = [p[0] * vx + p[1] * vy for p in poly]
        su, sv = max(us) - min(us), max(vs) - min(vs)
        best_min = min(best_min, min(su, sv))
        best_max = min(best_max, max(su, sv))
    return best_min, best_max

def _is_skipped_hole(poly, skip_hole=0.0):
    return skip_hole > 0.0 and _poly_spans(poly)[1] <= skip_hole + 1.5

def _is_skipped_slab(poly, skip_slab=0.0):
    return skip_slab > 0.0 and _poly_spans(poly)[0] <= skip_slab + 1.5

def _in_slab(pt, slab, skip_hole=0.0):
    if not _pip(pt, slab["outer"]): return False
    return not any((not _is_skipped_hole(h, skip_hole)) and _pip(pt, h) for h in slab.get("holes", []))

def _in_slabs(pt, slabs, skip_hole=0.0):
    return any(_in_slab(pt, s, skip_hole) for s in slabs)

def _in_poly(pt, poly):
    return _pip(pt, poly)

def _band_on_poly(u_fn, v_fn, poly, v_val):
    pts = [(u_fn(p), v_fn(p)) for p in poly]
    n = len(pts); xs = []
    for i in range(n):
        u1, v1 = pts[i]; u2, v2 = pts[(i + 1) % n]
        if (v1 <= v_val < v2) or (v2 <= v_val < v1):
            xs.append(u1 + (u2 - u1) * (v_val - v1) / (v2 - v1))
        elif abs(v1 - v_val) < 0.1 and abs(v2 - v_val) < 0.1:
            xs.extend([u1, u2])
    xs.sort()
    segs = []
    for k in range(0, len(xs) - 1, 2):
        if xs[k + 1] - xs[k] > 1.0:
            segs.append((xs[k], xs[k + 1]))
    return segs

def _sub_segs(segs, cuts):
    for c0, c1 in cuts:
        nxt = []
        for s0, s1 in segs:
            if c1 <= s0 or c0 >= s1: nxt.append((s0, s1))
            else:
                if c0 > s0: nxt.append((s0, c0))
                if c1 < s1: nxt.append((c1, s1))
        segs = nxt
    return segs

def _merge_segs(segs, tol=2.0):
    if not segs: return []
    segs = sorted(segs)
    res = [segs[0]]
    for a, b in segs[1:]:
        if a <= res[-1][1] + tol: res[-1] = (res[-1][0], max(res[-1][1], b))
        else: res.append((a, b))
    return res

def _slab_band_segs(u_fn, v_fn, slabs, v_val, skip_hole=0.0):
    res = []
    for s in slabs:
        segs = _band_on_poly(u_fn, v_fn, s["outer"], v_val)
        h_cuts = []
        for h in s.get("holes", []):
            if _is_skipped_hole(h, skip_hole):
                continue
            h_cuts.extend(_band_on_poly(u_fn, v_fn, h, v_val))
        res.extend(_sub_segs(segs, h_cuts))
    return _merge_segs(res)

# ─── CELL GROUPING & REBAR ENGINE ─────────────────────────────────────────────
def group_slabs(slabs, dcote, gap):
    n = len(slabs); adj = [set() for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if abs(slabs[i]["top"] - slabs[j]["top"]) > dcote: continue
            if _poly_edge_dist(slabs[i]["outer"], slabs[j]["outer"]) <= max(gap, 50.0):
                adj[i].add(j); adj[j].add(i)
    seen = [False] * n; cells = []
    for i in range(n):
        if seen[i]: continue
        comp = []; q = [i]; seen[i] = True
        while q:
            cur = q.pop(0); comp.append(slabs[cur])
            for nb in adj[cur]:
                if not seen[nb]: seen[nb] = True; q.append(nb)
        cells.append(comp)
    cells.sort(key=lambda c: (-c[0]["top"], _poly_bbox(c[0]["outer"])[0]))
    return cells

def cell_obstacles(cell, beams, cols, ztol=50.0):
    top_min = min(s["top"] for s in cell)
    top_max = max(s["top"] for s in cell)
    thick_max = max(s.get("thick", 120.0) for s in cell)
    z_lo = top_min - thick_max - ztol
    z_hi = top_max + ztol
    pts = [p for s in cell for p in s["outer"]]
    cx0, cy0, cx1, cy1 = _poly_bbox(pts)
    mg = 300.0
    def _filt(items):
        out = []
        for it in items:
            zt, zb = it.get("z_top"), it.get("z_bot")
            if zt is not None and zt < z_lo: continue
            if zb is not None and zb > z_hi: continue
            for poly in it.get("polys", []):
                px0, py0, px1, py1 = _poly_bbox(poly)
                if px1 >= cx0 - mg and px0 <= cx1 + mg and py1 >= cy0 - mg and py0 <= cy1 + mg:
                    out.append(poly)
        return out
    return _filt(beams), _filt(cols)

def _long_edge_along_u(poly, u_dir, v_dir):
    max_len = 0.0; best_ang = 0.0
    n = len(poly)
    for i in range(n):
        dx = poly[(i + 1) % n][0] - poly[i][0]
        dy = poly[(i + 1) % n][1] - poly[i][1]
        L = math.hypot(dx, dy)
        if L > max_len:
            max_len = L
            best_ang = abs(dx * u_dir[0] + dy * u_dir[1]) / L
    return best_ang > 0.707

def _prep(beam_polys, col_polys, u_dir, v_dir):
    u_fn = lambda p: p[0] * u_dir[0] + p[1] * u_dir[1]
    v_fn = lambda p: p[0] * v_dir[0] + p[1] * v_dir[1]
    blk, par_beams, perp = [], [], []
    for p in col_polys:
        us = [u_fn(q) for q in p]; vs = [v_fn(q) for q in p]
        blk.append((min(us), max(us), min(vs), max(vs), p))
    for p in beam_polys:
        us = [u_fn(q) for q in p]; vs = [v_fn(q) for q in p]
        su, sv = max(us) - min(us), max(vs) - min(vs)
        item = (min(us), max(us), min(vs), max(vs), p)
        if su > sv * 1.15 and _long_edge_along_u(p, u_dir, v_dir):
            blk.append(item)
            par_beams.append(item)
        else:
            perp.append(item)
    return u_fn, v_fn, blk, par_beams, perp

def free_at(slabs, u_fn, v_fn, blk, perp, v_val, skip_hole=0.0):
    segs = _slab_band_segs(u_fn, v_fn, slabs, v_val, skip_hole)
    cuts = []
    for u0, u1, v0, v1, poly in blk:
        if v0 <= v_val <= v1:
            for s0, s1 in _band_on_poly(u_fn, v_fn, poly, v_val):
                cuts.append((s0, s1))
    return _sub_segs(segs, cuts), cuts

def _pt_on_any(pt, polys):
    return any(_in_poly(pt, p) for p in polys)

def layer_bars(cell, beams, cols, u_dir, v_dir, pitch, cover, beam_end, clip_slab=True, hole_skip=500.0, slab_skip=500.0, v_offset=0.0):
    u_fn, v_fn, blk, par_beams, perp = _prep(beams, cols, u_dir, v_dir)
    all_pts = [p for s in cell for p in s["outer"]]
    vs = [v_fn(p) for p in all_pts]
    lo, hi = min(vs), max(vs)
    perp_polys = [p[4] for p in perp]
    blk_polys = [p[4] for p in blk]
    bars = []
    blk_set = set(id(x) for x in par_beams)
    col_only = [co for co in blk if id(co) not in blk_set]
    v = lo + cover + v_offset
    while v <= hi - cover + 1.0:
        # Trace continuous slab spans from boundary/void to boundary/void ("ve dau nay den dau kia")
        # without chopping continuous bars at interior beams/columns; exclude a segment only when it runs inside a parallel beam.
        raw_segs = _slab_band_segs(u_fn, v_fn, cell, v, hole_skip)
        par_cuts = []
        for pu0_b, pu1_b, pv0, pv1, ppoly in par_beams:
            if pv0 - 0.5 <= v <= pv1 + 0.5:
                vq = min(max(v, pv0 + 0.5), pv1 - 0.5) if (pv1 - pv0 >= 1.5) else 0.5 * (pv0 + pv1)
                par_cuts.extend(_band_on_poly(u_fn, v_fn, ppoly, vq))
        merged_par = _merge_segs(par_cuts, 5.0)
        if merged_par:
            col_cuts = []
            for cu0, cu1, cv0, cv1, cpoly in col_only:
                if cv0 - 0.5 <= v <= cv1 + 0.5:
                    col_cuts.extend(_band_on_poly(u_fn, v_fn, cpoly, v))
            merged_runs = _merge_segs(merged_par + col_cuts, 5.0)
            def _ov_len(c_list, a_s, b_s):
                return sum(max(0.0, min(b_s, c1) - max(a_s, c0)) for c0, c1 in c_list)
            segs = []
            for s0, s1 in raw_segs:
                span = max(1.0, s1 - s0)
                full_run_cov = any(mu0 <= s0 + cover + 10.0 and mu1 >= s1 - cover - 10.0 for mu0, mu1 in merged_runs)
                beam_cov_ratio = _ov_len(merged_par, s0, s1) / span
                run_cov_ratio = _ov_len(merged_runs, s0, s1) / span
                if full_run_cov and beam_cov_ratio >= 0.55:
                    continue
                if run_cov_ratio >= 0.85 and beam_cov_ratio >= 0.65:
                    continue
                segs.append((s0, s1))
        else:
            segs = raw_segs

        if slab_skip > 0.0 and segs:
            def _scan_side(s0, s1, dir_s):
                span = max(1.0, s1 - s0)
                step = 35.0
                max_walk = slab_skip + 60.0
                last_v = v
                d = step
                while d <= max_walk:
                    vt = v + dir_s * (d - 0.27)
                    segs_t = _slab_band_segs(u_fn, v_fn, cell, vt, hole_skip)
                    match = next(((t0, t1) for t0, t1 in segs_t if min(s1, t1) - max(s0, t0) >= 0.45 * span), None)
                    if match is None:
                        return last_v, True, False
                    t0, t1 = match
                    if (t0 < s0 - 250.0 or t1 > s1 + 250.0) and (t1 - t0 - span) >= max(slab_skip, 500.0, 0.2 * span):
                        return vt, False, True
                    last_v = vt
                    d += step
                return v + dir_s * max_walk, False, False

            kept_segs = []
            for s0, s1 in segs:
                lo_b, lo_out, lo_exp = _scan_side(s0, s1, -1.0)
                hi_b, hi_out, hi_exp = _scan_side(s0, s1, 1.0)
                if hi_b - lo_b <= slab_skip + 1.5 and (
                    (lo_out and hi_out) or (lo_out and hi_exp) or (hi_out and lo_exp)
                ):
                    continue
                kept_segs.append((s0, s1))
            segs = kept_segs

        perp_v = []
        for u0, u1, v0, v1, poly in perp:
            if v0 <= v <= v1:
                perp_v.extend(_band_on_poly(u_fn, v_fn, poly, v))
        perp_v = _merge_segs(perp_v)
        for s0, s1 in segs:
            a, b = s0, s1
            matched_s = None
            for pu0, pu1 in perp_v:
                if pu0 - 2.0 <= a <= pu1 + 2.0:
                    matched_s = (pu0, pu1); break
            if matched_s:
                pu0, pu1 = matched_s
                out_p = ((pu0 - 5.0) * u_dir[0] + v * v_dir[0], (pu0 - 5.0) * u_dir[1] + v * v_dir[1])
                if not _in_slabs(out_p, cell, hole_skip):
                    a = max(pu0 + beam_end, pu0)
                else:
                    a = s0 + cover
            else:
                a = s0 + cover

            matched_e = None
            for pu0, pu1 in perp_v:
                if pu0 - 2.0 <= b <= pu1 + 2.0:
                    matched_e = (pu0, pu1); break
            if matched_e:
                pu0, pu1 = matched_e
                out_p = ((pu1 + 5.0) * u_dir[0] + v * v_dir[0], (pu1 + 5.0) * u_dir[1] + v * v_dir[1])
                if not _in_slabs(out_p, cell, hole_skip):
                    b = min(pu1 - beam_end, pu1)
                else:
                    b = s1 - cover
            else:
                b = s1 - cover

            if clip_slab:
                pa = (a * u_dir[0] + v * v_dir[0], a * u_dir[1] + v * v_dir[1])
                pb = (b * u_dir[0] + v * v_dir[0], b * u_dir[1] + v * v_dir[1])
                if not (_in_slabs(pa, cell, hole_skip) or _pt_on_any(pa, perp_polys) or _pt_on_any(pa, blk_polys)):
                    a = max(a, s0 + cover)
                if not (_in_slabs(pb, cell, hole_skip) or _pt_on_any(pb, perp_polys) or _pt_on_any(pb, blk_polys)):
                    b = min(b, s1 - cover)

            if b - a >= 350.0:
                p0 = (a * u_dir[0] + v * v_dir[0], a * u_dir[1] + v * v_dir[1])
                p1 = (b * u_dir[0] + v * v_dir[0], b * u_dir[1] + v * v_dir[1])
                bars.append({"p0": p0, "p1": p1, "len": round(b - a), "v": round(v, 1), "a": round(a, 1), "b": round(b, 1)})
        v += pitch
    return bars

def hook_len(dia, lc, fbt=1.05, fy=350):
    if lc["hook"] == "thang": return 0.0
    if lc.get("mode") == "TCVN":
        return max(10 * dia, round(max(12.0 * dia, 0.25 * fy / max(fbt, 0.5) * dia) / 10.0) * 10.0)
    if lc.get("mode") == "10d":
        return float(10 * dia)
    return float(lc.get("hook_l", 100.0))

def hook_legs(bar, hl, u_dir, hook="thang", dia=10):
    if hl <= 0 or hook == "thang":
        return [bar["p0"], bar["p1"]]
    # Consistent 1-direction hooks for ALL top/bottom hooked rebars: +Y for X-bars, -X for Y-bars
    nx, ny = -u_dir[1], u_dir[0]
    if hook == "135":
        ux, uy = u_dir[0], u_dir[1]
        r = min(max(2.5 * dia, 22.0), hl * 0.28, bar["len"] * 0.2)
        tail = max(hl * 0.72, hl - r * 0.85)
        inv_sq2 = math.sqrt(0.5)

        c0x = bar["p0"][0] + ux * r + nx * r
        c0y = bar["p0"][1] + uy * r + ny * r
        start_arc = []
        for k in (3, 2, 1, 0):
            phi = k * math.pi * 0.25
            du = -r * math.sin(phi)
            dn = -r * math.cos(phi)
            start_arc.append((c0x + ux * du + nx * dn, c0y + uy * du + ny * dn))
        q0 = (
            start_arc[0][0] + (ux + nx) * inv_sq2 * tail,
            start_arc[0][1] + (uy + ny) * inv_sq2 * tail,
        )

        c1x = bar["p1"][0] - ux * r + nx * r
        c1y = bar["p1"][1] - uy * r + ny * r
        end_arc = []
        for k in (0, 1, 2, 3):
            phi = k * math.pi * 0.25
            du = r * math.sin(phi)
            dn = -r * math.cos(phi)
            end_arc.append((c1x + ux * du + nx * dn, c1y + uy * du + ny * dn))
        q1 = (
            end_arc[-1][0] + (-ux + nx) * inv_sq2 * tail,
            end_arc[-1][1] + (-uy + ny) * inv_sq2 * tail,
        )
        return [q0] + start_arc + end_arc + [q1]
    q0 = (bar["p0"][0] + nx * hl, bar["p0"][1] + ny * hl)
    q1 = (bar["p1"][0] + nx * hl, bar["p1"][1] + ny * hl)
    return [q0, bar["p0"], bar["p1"], q1]

def choose_main_axis(slabs, cfg_axis):
    if cfg_axis in ("X", "Y"): return cfg_axis
    pts = [p for s in slabs for p in s["outer"]]
    x0, y0, x1, y1 = _poly_bbox(pts)
    return "X" if (x1 - x0) <= (y1 - y0) else "Y"

def build_model(data, cfg):
    slab_skip = float(cfg.get("slab_skip", 0.0))
    all_slabs = data["slabs"]
    slabs = [s for s in all_slabs if not _is_skipped_slab(s["outer"], slab_skip)] if slab_skip > 0 else all_slabs
    if not slabs:
        return [], [], "Y"
    beams = data.get("beams", []); cols = data.get("columns", [])
    cells = group_slabs(slabs, cfg["dcote"], cfg["gap"])
    ax = choose_main_axis(slabs, cfg["main_axis"])
    u_main = (1.0, 0.0) if ax == "X" else (0.0, 1.0)
    v_main = (0.0, 1.0) if ax == "X" else (1.0, 0.0)
    u_sec = v_main; v_sec = u_main

    layer_defs = [
        ("duoi_chinh", u_main, v_main),
        ("duoi_phu",   u_sec,  v_sec),
        ("tren_chinh", u_main, v_main),
        ("tren_phu",   u_sec,  v_sec),
    ]
    fbt = CONC_FBT.get(cfg.get("concrete", "B25"), 1.05)
    fy = STEEL_FY.get(cfg.get("steel", "CB400-V"), 350)

    groups = []; sh = 1
    for ci, cell in enumerate(cells):
        cb, cc = cell_obstacles(cell, beams if cfg["use_beam"] else [], cols if cfg["use_col"] else [], cfg["beam_ztol"])
        for lname, ud, vd in layer_defs:
            lc = cfg["layers"][lname]
            if not lc.get("on", True): continue
            v_off = lc["pitch"] * 0.5 if lname.startswith("tren") else 0.0
            bars = layer_bars(cell, cb, cc, ud, vd, lc["pitch"], cfg["cover"], cfg["beam_end"], cfg["clip_slab"], cfg["hole_skip"], slab_skip, v_off)
            if not bars: continue
            hl = hook_len(lc["dia"], lc, fbt, fy)
            # Group bars by rounded total length (sharing SH across split bays in the same cell & layer!)
            by_len = {}
            for b in bars:
                b["pts"] = hook_legs(b, hl, ud, lc["hook"], lc["dia"])
                tot_l = int(round(b["len"] + 2 * hl))
                by_len.setdefault(tot_l, []).append(b)

            # Sort length clusters cleanly (matching TS Math.abs(amin - bmin) > 40)
            from functools import cmp_to_key
            def _cmp_by_len(k1, k2):
                a1 = min(x["a"] for x in k1[1]); a2 = min(x["a"] for x in k2[1])
                if abs(a1 - a2) > 40.0:
                    return -1 if a1 < a2 else 1
                v1 = min(x["v"] for x in k1[1]); v2 = min(x["v"] for x in k2[1])
                if v1 != v2:
                    return -1 if v1 < v2 else 1
                return -1 if k1[0] < k2[0] else (1 if k1[0] > k2[0] else 0)
            for tot_l, gbars in sorted(by_len.items(), key=cmp_to_key(_cmp_by_len)):
                # Split into contiguous sub-clusters for plan symbols (each bay gets a callout sharing the SAME SH)
                sub_clusters = []
                # Group by (a, b) tolerance 30mm and contiguous v spacing <= 2.2 * pitch
                gb_sorted = sorted(gbars, key=lambda x: (round(x["a"] / 30.0), round(x["b"] / 30.0), x["v"]))
                cur = []
                for x in gb_sorted:
                    if not cur:
                        cur = [x]
                    else:
                        prev = cur[-1]
                        if abs(x["a"] - prev["a"]) <= 35.0 and abs(x["b"] - prev["b"]) <= 35.0 and abs(x["v"] - prev["v"]) <= lc["pitch"] * 2.2:
                            cur.append(x)
                        else:
                            sub_clusters.append(cur); cur = [x]
                if cur: sub_clusters.append(cur)

                n = len(gbars)
                dia = lc["dia"]
                total_m = round(n * tot_l / 1000.0, 2)
                kg = round(0.00617 * dia * dia * total_m, 2)
                groups.append({
                    "sh": sh, "cell": ci, "layer": lname,
                    "dia": dia, "pitch": lc["pitch"],
                    "hook": lc["hook"], "hl": round(hl),
                    "len": round(tot_l - 2 * hl), "sumL": tot_l,
                    "n": n, "total_m": total_m, "kg": kg,
                    "u_dir": ud, "v_dir": vd,
                    "bars": gbars, "clusters": sub_clusters,
                })
                sh += 1
    return cells, groups, ax

def _seg_hits_aabb(p0, p1, box, pad):
    bx0, by0, bx1, by1 = box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad
    t0, t1 = 0.0, 1.0
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    for p, q in ((-dx, p0[0] - bx0), (dx, bx1 - p0[0]), (-dy, p0[1] - by0), (dy, by1 - p0[1])):
        if abs(p) < 1e-9:
            if q < 0: return False
        else:
            r = q / p
            if p < 0:
                if r > t1: return False
                if r > t0: t0 = r
            else:
                if r < t0: return False
                if r < t1: t1 = r
    return t0 <= t1

def _aabb_overlap(a, b, pad):
    return not (a[2] + pad < b[0] or a[0] - pad > b[2] or a[3] + pad < b[1] or a[1] - pad > b[3])

def _sym_box(cx, cy, ang, sc, label_len):
    txt_w = max(8.5, label_len * 1.42) * sc
    r = 2.65 * sc
    if ang == 0:
        return (cx - 5.2 * sc, cy - r, cx + 1.0 * sc + txt_w, cy + r)
    return (cx - r, cy - 5.2 * sc, cx + r, cy + 1.0 * sc + txt_w)

def plan_symbols(groups, draw_sep=4.0, scale=75.0):
    syms = []
    min_bar_sep = max(1.25 * scale, 95.0)

    # Group adjacent curved/skewed/bent clusters into 1 typical plan zone while keeping ALL groups in schedule
    by_cl = {}
    for g in groups:
        by_cl.setdefault((g["cell"], g["layer"]), []).append(g)

    zones = []
    for l_groups in by_cl.values():
        entries = []
        for g in l_groups:
            for cl in g["clusters"]:
                if not cl: continue
                vs = [b["v"] for b in cl]
                mid = cl[len(cl) // 2]
                entries.append({
                    "g": g, "cl": cl, "v0": min(vs), "v1": max(vs),
                    "a_mid": mid["a"], "b_mid": mid["b"],
                })
        entries.sort(key=lambda e: (e["v0"], e["a_mid"]))
        used = [False] * len(entries)
        for i in range(len(entries)):
            if used[i]: continue
            used[i] = True
            chain = [entries[i]]
            changed = True
            while changed:
                changed = False
                for tail in chain:
                    span_t = max(1.0, tail["b_mid"] - tail["a_mid"])
                    for j in range(len(entries)):
                        if used[j]: continue
                        cand = entries[j]
                        v_gap = (cand["v0"] - tail["v1"]) if cand["v0"] > tail["v1"] else (tail["v0"] - cand["v1"])
                        max_vg = max(tail["g"]["pitch"] * 3.0, 620.0)
                        if v_gap < -0.5 * tail["g"]["pitch"] or v_gap > max_vg:
                            continue
                        ov = min(tail["b_mid"], cand["b_mid"]) - max(tail["a_mid"], cand["a_mid"])
                        span_c = max(1.0, cand["b_mid"] - cand["a_mid"])
                        min_span = min(span_t, span_c)
                        max_span = max(span_t, span_c)
                        if ov < 0.45 * min_span:
                            continue
                        da = abs(cand["a_mid"] - tail["a_mid"])
                        db = abs(cand["b_mid"] - tail["b_mid"])
                        max_edge_step = max(tail["g"]["pitch"] * 4.5, 950.0)
                        compatible_bay = (min_span / max_span >= 0.65) and (max(da, db) <= 1200.0)
                        smooth_curve = (da <= max_edge_step) and (db <= max_edge_step)
                        if compatible_bay or smooth_curve:
                            used[j] = True
                            chain.append(cand)
                            changed = True
                            break
                    if changed: break
            all_bars = sorted([b for e in chain for b in e["cl"]], key=lambda b: b["v"])
            distinct_sh = len(set(e["g"]["sh"] for e in chain))
            dom_e = max(chain, key=lambda e: (len(e["cl"]), e["b_mid"] - e["a_mid"]))
            zg_map = {}
            for e in chain:
                sh_i = e["g"]["sh"]
                if sh_i in zg_map:
                    zg_map[sh_i]["n"] += len(e["cl"])
                else:
                    zg_map[sh_i] = {
                        "sh": sh_i, "len": e["g"]["len"], "hl": e["g"]["hl"],
                        "hook": e["g"]["hook"], "n": len(e["cl"]),
                    }
            zone_groups = [zg_map[k] for k in sorted(zg_map)]
            zones.append({
                "rep_g": dom_e["g"], "bars": all_bars,
                "v0": min(b["v"] for b in all_bars), "v1": max(b["v"] for b in all_bars),
                "is_typical": distinct_sh > 1 or len(chain) > 1,
                "zone_qty": len(all_bars),
                "zone_len_avg": int(round(sum(b["len"] for b in all_bars) / max(1, len(all_bars)))),
                "zone_groups": zone_groups,
            })

    zones.sort(key=lambda z: (z["rep_g"]["sh"], z["v0"]))

    used_reps = []
    pending = []
    desired_pair_gap = max(4.0 * scale, 300.0)
    ordered_zones = [z for z in zones if not z["rep_g"]["layer"].startswith("tren")] + [z for z in zones if z["rep_g"]["layer"].startswith("tren")]

    for z in ordered_zones:
        g = z["rep_g"]
        cl = z["bars"]
        is_top = g["layer"].startswith("tren")
        ud = g["u_dir"]; vd = g["v_dir"]
        ang_deg = 0.0 if abs(ud[0]) > 0.7 else 90.0
        disp_lbl = u"Ø{0}a{1}".format(g["dia"], g["pitch"])
        cad_lbl = u"%%c{0}a{1}".format(g["dia"], g["pitch"])

        n = len(cl)
        mid_a = 0.5 * (cl[0]["a"] + cl[0]["b"])
        span_len = max(1.0, cl[0]["b"] - cl[0]["a"])
        target_v = cl[min(n - 1, max(0, int(round((n - 1) * (0.54 if is_top else 0.46)))))]["v"]
        mate_idx = -1
        if is_top:
            best_mate_v = None
            best_ratio = 0.4
            for ua, uv, ua0, ub0, u_top, u_cell, p_idx in used_reps:
                if (not u_top) and ua == ang_deg and u_cell == g["cell"] and (z["v0"] - g["pitch"] * 2.5 <= uv <= z["v1"] + g["pitch"] * 2.5):
                    ov = min(cl[0]["b"], ub0) - max(cl[0]["a"], ua0)
                    ratio = ov / max(1.0, max(span_len, ub0 - ua0))
                    if ratio >= best_ratio:
                        best_ratio = ratio
                        best_mate_v = uv
                        mate_idx = p_idx
            if best_mate_v is not None:
                up_c = best_mate_v + desired_pair_gap
                dn_c = best_mate_v - desired_pair_gap
                target_v = up_c if up_c <= z["v1"] + g["pitch"] * 0.5 else dn_c

        best_bar = cl[0]; best_sc = 1e18
        for i, cand in enumerate(cl):
            hits = 0
            for ua, uv, ua0, ub0, _, _, _ in used_reps:
                if ua != ang_deg: continue
                if min(cand["b"], ub0) - max(cand["a"], ua0) > 55.0 and abs(cand["v"] - uv) < min_bar_sep:
                    hits += 1
            sc_i = hits * 100000 + abs(cand["v"] - target_v) + abs(0.5 * (cand["a"] + cand["b"]) - mid_a) * 0.01
            if sc_i < best_sc:
                best_sc = sc_i; best_bar = cand

        def _has_rep_hit(vc):
            return any(ua == ang_deg and min(best_bar["b"], ub0) - max(best_bar["a"], ua0) > 55.0 and abs(vc - uv) < min_bar_sep for ua, uv, ua0, ub0, _, _, _ in used_reps)

        rep = best_bar
        if _has_rep_hit(best_bar["v"]):
            pref_d = 1.0 if is_top else -1.0
            step = max(1.3 * scale, 100.0)
            sh_v = pref_d * step
            for k in range(1, 25):
                found = False
                for d in (pref_d, -pref_d):
                    cand_sh = d * k * step
                    if not _has_rep_hit(best_bar["v"] + cand_sh):
                        sh_v = cand_sh; found = True; break
                if found: break
            rep = dict(best_bar)
            rep["v"] = best_bar["v"] + sh_v
            rep["p0"] = (best_bar["p0"][0] + vd[0] * sh_v, best_bar["p0"][1] + vd[1] * sh_v)
            rep["p1"] = (best_bar["p1"][0] + vd[0] * sh_v, best_bar["p1"][1] + vd[1] * sh_v)
            rep["pts"] = [(pt[0] + vd[0] * sh_v, pt[1] + vd[1] * sh_v) for pt in best_bar["pts"]]

        p_idx = len(pending)
        used_reps.append((ang_deg, rep["v"], rep["a"], rep["b"], is_top, g["cell"], p_idx))
        pending.append((z, g, cl, rep, is_top, ang_deg, disp_lbl, cad_lbl, mate_idx))

    bar_segs = []
    for _, _, _, rep, _, _, _, _, _ in pending:
        pts = rep["pts"]
        for i in range(len(pts) - 1):
            bar_segs.append((pts[i], pts[i + 1]))

    placed = []
    chosen_u = {}
    base_perp = max(4.5, draw_sep * 1.02) * scale
    perp_steps = [base_perp + k * scale for k in (0.0, 2.4, 4.8, 7.2, 10.0, 13.5, 18.0, 23.0)]
    u_fracs = [0.5, 0.45, 0.55, 0.39, 0.61, 0.33, 0.67, 0.27, 0.73, 0.21, 0.79, 0.15, 0.85, 0.08, 0.92]

    pass2_order = sorted(
        list(enumerate(pending)),
        key=lambda item: (1 if item[1][4] else 0, item[1][3]["b"] - item[1][3]["a"], item[1][1]["sh"]),
    )

    for p_idx, (z, g, cl, rep, is_top, ang_deg, disp_lbl, cad_lbl, m_idx) in pass2_order:
        ud = g["u_dir"]; vd = g["v_dir"]
        pref_sign = 1.0 if is_top else -1.0
        bar_len = rep["b"] - rep["a"]
        v_min, v_max = cl[0]["v"], cl[-1]["v"]
        mate_u = chosen_u.get(m_idx)

        best_st = [
            0.5 * (rep["p0"][0] + rep["p1"][0]) + vd[0] * pref_sign * base_perp,
            0.5 * (rep["p0"][1] + rep["p1"][1]) + vd[1] * pref_sign * base_perp,
            1e18,
            0.5 * (rep["a"] + rep["b"]),
        ]

        def _eval(u_pos, v_pos, wrong_s, ext_pen):
            cx = u_pos * ud[0] + v_pos * vd[0]
            cy = u_pos * ud[1] + v_pos * vd[1]
            box = _sym_box(cx, cy, ang_deg, scale, len(disp_lbl))
            bar_hits = sum(1 for sp0, sp1 in bar_segs if _seg_hits_aabb(sp0, sp1, box, 1.2 * scale))
            sym_hits = sum(1 for pb in placed if _aabb_overlap(box, pb, 0.8 * scale))
            out_v = 1 if (v_pos < v_min - 2 * scale or v_pos > v_max + 2 * scale) else 0
            dist_v = abs(v_pos - rep["v"]) / max(scale, 1.0)
            u_mid_pen = abs((u_pos - rep["a"]) / max(bar_len, 1.0) - 0.5) * 8.0
            align_pen = min(20.0, abs(u_pos - mate_u) / max(scale * 4.0, 1.0)) * 1.4 if mate_u is not None else 0.0
            score = bar_hits * 10000 + sym_hits * 2000 + ext_pen + out_v * 25 + (18 if wrong_s else 0) + align_pen + u_mid_pen + dist_v * 0.45
            if score < best_st[2]:
                best_st[0] = cx; best_st[1] = cy; best_st[2] = score; best_st[3] = u_pos

        cand_u = ([max(0.06, min(0.94, (mate_u - rep["a"]) / max(bar_len, 1.0)))] + u_fracs) if mate_u is not None else u_fracs

        for sgn in (pref_sign, -pref_sign):
            for off_v in perp_steps:
                for uf in cand_u:
                    _eval(rep["a"] + bar_len * uf, rep["v"] + sgn * off_v, sgn != pref_sign, 0.0)
                    if best_st[2] < 5.5: break
                if best_st[2] < 5.5: break
            if best_st[2] < 5.5: break

        if best_st[2] >= 1800:
            ext_u = [m * scale for m in (-4, 4, -8, 8, -12, 12, -17, 17, -23, 23, -30, 30, -38, 38)]
            ext_v = [0.0, base_perp, -base_perp, base_perp + 4 * scale, -(base_perp + 4 * scale), base_perp + 9 * scale, -(base_perp + 9 * scale), base_perp + 15 * scale, -(base_perp + 15 * scale)]
            for eu in ext_u:
                u_pos = (rep["a"] + eu) if eu < 0 else (rep["b"] + eu)
                for ev in ext_v:
                    _eval(u_pos, rep["v"] + ev, False, 120.0 + abs(eu) / max(scale, 1.0))
                    if best_st[2] < 1800: break
                if best_st[2] < 1800: break

        chosen_u[p_idx] = best_st[3]
        best_cx, best_cy = best_st[0], best_st[1]
        placed.append(_sym_box(best_cx, best_cy, ang_deg, scale, len(disp_lbl)))
        syms.append({
            "sh": g["sh"], "layer": g["layer"], "is_top": is_top,
            "dia": g["dia"], "pitch": g["pitch"],
            "hook": g["hook"], "hl": g["hl"], "len": g["len"],
            "n_cluster": z["zone_qty"] if z["is_typical"] else len(cl),
            "len_eff": z["zone_len_avg"] if z["is_typical"] else g["len"],
            "n_total": g["n"],
            "cx": best_cx, "cy": best_cy, "ang": ang_deg,
            "rep_bar": rep,
            "v0": z["v0"], "v1": z["v1"],
            "a_mid": 0.5 * (rep.get("a", 0) + rep.get("b", 0)) if isinstance(rep, dict) else 0,
            "u_dir": ud, "v_dir": vd,
            "label": cad_lbl,
            "is_typical": z["is_typical"],
            "zone_groups": z["zone_groups"],
        })
    syms.sort(key=lambda s: (s["sh"], s["v0"]))
    return syms

def _build_grid_layout(grids, slabs, sc):
    slab_pts = [p for s in slabs for p in s.get("outer", [])]
    all_pts = slab_pts if slab_pts else [p for g in grids for p in (g["p0"], g["p1"])]
    if not grids or not all_pts:
        return list(grids), []
    families = []
    for idx, g in enumerate(grids):
        dx = g["p1"][0] - g["p0"][0]; dy = g["p1"][1] - g["p0"][1]
        L = math.hypot(dx, dy)
        if L < 1e-3: continue
        ux, uy = dx / L, dy / L
        if ux < -1e-4 or (abs(ux) <= 1e-4 and uy < 0):
            ux, uy = -ux, -uy
        vx, vy = -uy, ux
        fam = None
        for f in families:
            if abs(f["u"][0] * ux + f["u"][1] * uy) > 0.99:
                fam = f; break
        if fam is None:
            fam = {"u": (ux, uy), "v": (vx, vy), "items": []}
            families.append(fam)
        u0 = g["p0"][0] * fam["u"][0] + g["p0"][1] * fam["u"][1]
        u1 = g["p1"][0] * fam["u"][0] + g["p1"][1] * fam["u"][1]
        v_pos = 0.5 * ((g["p0"][0] + g["p1"][0]) * fam["v"][0] + (g["p0"][1] + g["p1"][1]) * fam["v"][1])
        fam["items"].append({"idx": idx, "name": g.get("name", ""), "p0": g["p0"], "p1": g["p1"], "v_pos": v_pos, "u0": min(u0, u1), "u1": max(u0, u1)})

    ext_grids = [dict(g) for g in grids]
    dims = []
    for fam in families:
        if len(fam["items"]) < 2: continue
        ux, uy = fam["u"]; vx, vy = fam["v"]
        slab_us = [p[0] * ux + p[1] * uy for p in all_pts]
        slab_umin, slab_umax = min(slab_us), max(slab_us)
        dim1_lo, dim2_lo = slab_umin - 6.5 * sc, slab_umin - 12.2 * sc
        dim1_hi, dim2_hi = slab_umax + 6.5 * sc, slab_umax + 12.2 * sc
        req_blo, req_bhi = dim2_lo - 7.0 * sc, dim2_hi + 7.0 * sc
        for it in fam["items"]:
            t_lo = min(it["u0"], req_blo); t_hi = max(it["u1"], req_bhi)
            p_lo = (ux * t_lo + vx * it["v_pos"], uy * t_lo + vy * it["v_pos"])
            p_hi = (ux * t_hi + vx * it["v_pos"], uy * t_hi + vy * it["v_pos"])
            orig_u0 = ext_grids[it["idx"]]["p0"][0] * ux + ext_grids[it["idx"]]["p0"][1] * uy
            orig_u1 = ext_grids[it["idx"]]["p1"][0] * ux + ext_grids[it["idx"]]["p1"][1] * uy
            if orig_u0 <= orig_u1:
                ext_grids[it["idx"]]["p0"] = p_lo; ext_grids[it["idx"]]["p1"] = p_hi
            else:
                ext_grids[it["idx"]]["p0"] = p_hi; ext_grids[it["idx"]]["p1"] = p_lo
        sorted_it = sorted(fam["items"], key=lambda x: x["v_pos"])
        uniq = []
        for it in sorted_it:
            if not uniq or it["v_pos"] - uniq[-1]["v_pos"] >= 20.0:
                uniq.append(it)
        if len(uniq) < 2: continue
        for side in ("lo", "hi"):
            u1 = dim1_lo if side == "lo" else dim1_hi
            u2 = dim2_lo if side == "lo" else dim2_hi
            anchor_u = slab_umin if side == "lo" else slab_umax
            perp = (-ux, -uy) if side == "lo" else (ux, uy)
            for k in range(len(uniq) - 1):
                va, vb = uniq[k]["v_pos"], uniq[k + 1]["v_pos"]
                dims.append({
                    "p0": (ux * anchor_u + vx * va, uy * anchor_u + vy * va),
                    "p1": (ux * anchor_u + vx * vb, uy * anchor_u + vy * vb),
                    "dim_pt": (ux * u1 + vx * 0.5 * (va + vb), uy * u1 + vy * 0.5 * (va + vb)),
                    "layer": 1, "val_mm": int(round(abs(vb - va))), "dir": fam["v"], "perp": perp,
                })
            va, vb = uniq[0]["v_pos"], uniq[-1]["v_pos"]
            dims.append({
                "p0": (ux * anchor_u + vx * va, uy * anchor_u + vy * va),
                "p1": (ux * anchor_u + vx * vb, uy * anchor_u + vy * vb),
                "dim_pt": (ux * u2 + vx * 0.5 * (va + vb), uy * u2 + vy * 0.5 * (va + vb)),
                "layer": 2, "val_mm": int(round(abs(vb - va))), "dir": fam["v"], "perp": perp,
            })
    return ext_grids, dims

def summarize_by_dia(groups, sl_san=1):
    ck = max(1, int(round(sl_san or 1)))
    by_d = {}
    for g in groups:
        d = g["dia"]
        qty_tot = g["n"] * ck
        row_m = round((qty_tot * g["sumL"] / 1000.0), 2)
        row_kg = round(0.00617 * d * d * row_m, 2)
        row = by_d.setdefault(d, {"dia": d, "m": 0.0, "kg": 0.0, "bars_117": 0})
        row["m"] += row_m
        row["kg"] += row_kg
    out = []
    for d in sorted(by_d):
        r = by_d[d]
        r["m"] = round(r["m"], 2)
        r["kg"] = round(r["kg"], 2)
        r["bars_117"] = int(math.ceil(r["m"] / 11.7)) if r["m"] > 0 else 0
        out.append(r)
    return out

# ─── TRANSFORM & CAD HELPERS ──────────────────────────────────────────────────
def xf(pt, T):
    c, s = math.cos(T["theta"]), math.sin(T["theta"])
    sc = T.get("scale", 1.0)
    return (sc * (pt[0] * c - pt[1] * s) + T["tx"], sc * (pt[0] * s + pt[1] * c) + T["ty"])

def fit_transform(src_pts, dst_pts, allow_scale=False):
    n = len(src_pts)
    if n == 1:
        return {"theta": 0.0, "tx": dst_pts[0][0] - src_pts[0][0], "ty": dst_pts[0][1] - src_pts[0][1], "scale": 1.0}
    mx_s = sum(p[0] for p in src_pts) / n; my_s = sum(p[1] for p in src_pts) / n
    mx_d = sum(p[0] for p in dst_pts) / n; my_d = sum(p[1] for p in dst_pts) / n
    num = sum((s[0] - mx_s) * (d[1] - my_d) - (s[1] - my_s) * (d[0] - mx_d) for s, d in zip(src_pts, dst_pts))
    den = sum((s[0] - mx_s) * (d[0] - my_d) + (s[1] - my_s) * (d[1] - mx_d) for s, d in zip(src_pts, dst_pts))
    theta = math.atan2(num, den)
    sc = 1.0
    if allow_scale:
        ds = sum((s[0] - mx_s) ** 2 + (s[1] - my_s) ** 2 for s in src_pts)
        dd = sum((d[0] - mx_d) ** 2 + (d[1] - my_d) ** 2 for d in dst_pts)
        if ds > 1e-6:
            ratio = math.sqrt(dd / ds)
            for std in (0.001, 0.01, 0.1, 1.0, 10.0, 100.0, 1000.0):
                if abs(ratio - std) / std < 0.05:
                    sc = std; break
    c, s = math.cos(theta), math.sin(theta)
    tx = mx_d - sc * (mx_s * c - my_s * s)
    ty = my_d - sc * (mx_s * s + my_s * c)
    return {"theta": theta, "tx": tx, "ty": ty, "scale": sc}

def _cad_pt(x, y):
    import win32com.client, pythoncom
    return win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, (float(x), float(y), 0.0))

def _cad_pts2d(pts):
    import win32com.client, pythoncom
    flat = []
    for p in pts:
        flat.extend([float(p[0]), float(p[1])])
    return win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, flat)

def _com_call(fn, *args, **kwargs):
    for _ in range(5):
        try:
            return fn(*args, **kwargs)
        except Exception as ex:
            if "rejected" in str(ex).lower() or "-2147418111" in str(ex):
                time.sleep(0.15)
            else:
                raise
    return fn(*args, **kwargs)

def _ensure_layer(doc, name, color=7, lw=None):
    try:
        ly = doc.Layers.Item(name)
    except Exception:
        ly = doc.Layers.Add(name)
    try:
        ly.Color = color
        if lw is not None:
            ly.Lineweight = lw
    except Exception:
        pass
    return ly

def _ensure_textstyle(doc, name="Dce_Text", width=0.8):
    try:
        ts = doc.TextStyles.Item(name)
    except Exception:
        ts = doc.TextStyles.Add(name)
    try:
        ts.SetFont("Arial", False, False, 0, 0)
    except Exception:
        pass
    try:
        ts.Width = width
    except Exception:
        pass
    return ts

def _ensure_dimstyle(doc, sc, name="DIM_CHUAN", unit_scale=1.0):
    try:
        ds = doc.DimStyles.Item(name)
    except Exception:
        ds = doc.DimStyles.Add(name)
    try:
        doc.ActiveDimStyle = ds
    except Exception:
        pass
    dimlfac = (1.0 / unit_scale) if abs(unit_scale) > 1e-6 and abs(unit_scale - 1.0) > 1e-4 else 1.0
    for k, v in (
        ("DIMSCALE", float(sc)), ("DIMTXSTY", "Dce_Text"), ("DIMTXT", 2.2),
        ("DIMTSZ", 1.4), ("DIMASZ", 1.4), ("DIMEXE", 1.6), ("DIMEXO", 1.2),
        ("DIMGAP", 1.1), ("DIMDLI", 5.5), ("DIMCLRD", 3), ("DIMCLRE", 3), ("DIMCLRT", 3),
        ("DIMTAD", 1), ("DIMTIH", 0), ("DIMTOH", 0), ("DIMDEC", 0), ("DIMTIX", 1),
        ("DIMTOFL", 1), ("DIMLFAC", dimlfac),
    ):
        try:
            doc.SetVariable(k, v)
        except Exception:
            pass
    try:
        doc.SetVariable("DIMBLK", "_ARCHTICK")
    except Exception:
        pass
    try:
        ds.CopyFrom(doc)
    except Exception:
        pass
    return ds

def _add_text(ms, text, x, y, h, layer="Dce_text", color=256, align=0, ang_rad=0.0, style="Dce_Text"):
    t = _com_call(ms.AddText, text, _cad_pt(x, y), float(h))
    t.Layer = layer
    if color != 256: t.Color = color
    t.Rotation = ang_rad
    try: t.StyleName = style
    except Exception: pass
    if align != 0:
        t.Alignment = align
        t.TextAlignmentPoint = _cad_pt(x, y)
    return t

def _add_line(ms, x0, y0, x1, y1, layer, color=256):
    ln = _com_call(ms.AddLine, _cad_pt(x0, y0), _cad_pt(x1, y1))
    ln.Layer = layer
    if color != 256: ln.Color = color
    return ln

def _add_rect(ms, x0, y0, x1, y1, layer, color=256):
    pl = _com_call(ms.AddLightWeightPolyline, _cad_pts2d([(x0, y0), (x1, y0), (x1, y1), (x0, y1)]))
    pl.Closed = True
    pl.Layer = layer
    if color != 256: pl.Color = color
    return pl

# ─── TKINTER GUI ──────────────────────────────────────────────────────────────
class ThepSanApp:
    def __init__(self, json_path=None):
        self.root = tk.Tk()
        self.root.title("Triển khai Thép Sàn Revit -> AutoCAD (Chuẩn mẫu DXF)")
        self.root.geometry("1280x820")
        self.root.configure(bg="#0f172a")

        self.cfg = json.loads(json.dumps(DEFAULT_CFG))
        if os.path.isfile(CFG_FILE):
            try:
                saved = json.load(open(CFG_FILE, "r", encoding="utf-8"))
                self.cfg.update({k: v for k, v in saved.items() if k != "layers"})
                if "layers" in saved:
                    self.cfg["layers"].update(saved["layers"])
            except Exception:
                pass

        self.data = None
        self.cells = []; self.groups = []; self.syms = []; self.ax = "Y"
        self.T = None
        self.snap_pts = []
        self.pick_mode = False
        self.canvas_picks = []
        self._kh_diverged = False
        self.zoom = 1.0; self.pan_x = 0.0; self.pan_y = 0.0

        self._build_ui()
        if json_path and os.path.isfile(json_path):
            self.load_json(json_path)

    def _build_ui(self):
        top = tk.Frame(self.root, bg="#1e293b", height=44)
        top.pack(fill="x")
        tk.Button(top, text="Mở JSON Revit", command=self.open_json, bg="#334155", fg="white", relief="flat", padx=10).pack(side="left", padx=6, pady=6)
        self.lbl_info = tk.Label(top, text="Chưa tải JSON", bg="#1e293b", fg="#94a3b8", font=("Segoe UI", 9, "bold"))
        self.lbl_info.pack(side="left", padx=8)

        tk.Button(top, text="Xuất CAD ngay", command=self.do_export, bg="#10b981", fg="#052e16", font=("Segoe UI", 9, "bold"), relief="flat", padx=12).pack(side="right", padx=6, pady=6)
        tk.Button(top, text="Pick từ Revit -> CAD luôn", command=self.do_pick_and_export, bg="#f59e0b", fg="#1c1917", font=("Segoe UI", 9, "bold"), relief="flat", padx=12).pack(side="right", padx=4, pady=6)
        tk.Button(top, text="Pick điểm mốc (Canvas -> CAD)", command=self.start_canvas_pick, bg="#0284c7", fg="white", relief="flat", padx=10).pack(side="right", padx=4, pady=6)
        tk.Button(top, text="Tự căn lưới CAD", command=self.do_align_grids, bg="#475569", fg="white", relief="flat", padx=10).pack(side="right", padx=4, pady=6)

        body = tk.Frame(self.root, bg="#0f172a")
        body.pack(fill="both", expand=True)

        left = tk.Frame(body, bg="#111827", width=310)
        left.pack(side="left", fill="y", padx=4, pady=4)
        left.pack_propagate(False)

        self.v_scale_lock = tk.BooleanVar(value=self.cfg.get("lock_revit_scale", True))
        self.v_sample = tk.BooleanVar(value=self.cfg.get("sample_style", True))
        self.v_plan_geom = tk.BooleanVar(value=self.cfg.get("draw_plan_geom", True))
        self.v_range = tk.BooleanVar(value=self.cfg.get("draw_range", False))
        self.v_title = tk.BooleanVar(value=self.cfg.get("draw_title", True))
        self.v_sched = tk.BooleanVar(value=self.cfg.get("draw_schedule", True))
        self.v_split = tk.BooleanVar(value=self.cfg.get("split_table", True))
        self.v_maxrows = tk.StringVar(value=str(self.cfg.get("max_rows_per_frame", 30)))
        self.v_ten = tk.StringVar(value=self.cfg.get("ten_cau_kien", "SÀN TẦNG 2"))
        self.v_kh = tk.StringVar(value=self.cfg.get("ten_ky_hieu", "SÀN T2"))
        self.v_slsan = tk.StringVar(value=str(self.cfg.get("sl_san", 1)))
        self.v_cad_sc = tk.StringVar(value=str(self.cfg.get("cad_sc", 1.0)))
        self.v_cover = tk.StringVar(value=str(self.cfg.get("cover", 15)))
        self.v_bend = tk.StringVar(value=str(self.cfg.get("beam_end", 50)))
        self.v_holeskip = tk.StringVar(value=str(self.cfg.get("hole_skip", 500)))
        self.v_slabskip = tk.StringVar(value=str(self.cfg.get("slab_skip", 500)))

        def _row(lbl, var, on_key=None):
            f = tk.Frame(left, bg="#111827")
            f.pack(fill="x", padx=8, pady=2)
            tk.Label(f, text=lbl, bg="#111827", fg="#cbd5e1", width=18, anchor="w", font=("Segoe UI", 9)).pack(side="left")
            ent = tk.Entry(f, textvariable=var, bg="#1e293b", fg="white", insertbackground="white", relief="flat")
            ent.pack(side="right", fill="x", expand=True)
            ent.bind("<Return>", lambda e: self.recompute())
            ent.bind("<FocusOut>", lambda e: self.recompute())
            if on_key:
                ent.bind("<KeyRelease>", on_key)
            return ent

        def _on_ten_key(_e=None):
            if not self._kh_diverged:
                self.v_kh.set(self.v_ten.get().strip() or self.v_kh.get())

        def _on_kh_key(_e=None):
            self._kh_diverged = True

        tk.Label(left, text="THIẾT LẬP TỈ LỆ & MẪU DXF", bg="#111827", fg="#38bdf8", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=8, pady=(8, 4))
        self.chk_scale = tk.Checkbutton(left, text="Khoá tỉ lệ theo Revit", variable=self.v_scale_lock, bg="#111827", fg="white", selectcolor="#1e293b", command=self.recompute)
        self.chk_scale.pack(anchor="w", padx=8)
        tk.Checkbutton(left, text="Xuất mặt bằng Revit (Lưới, Sàn, Dầm, Cột)", variable=self.v_plan_geom, bg="#111827", fg="#22d3ee", selectcolor="#1e293b").pack(anchor="w", padx=8)
        tk.Checkbutton(left, text="Xuất kiểu mẫu (Vòng tròn SH + %%cØa)", variable=self.v_sample, bg="#111827", fg="white", selectcolor="#1e293b", command=self.recompute).pack(anchor="w", padx=8)
        tk.Checkbutton(left, text="Vẽ đường rải thép", variable=self.v_range, bg="#111827", fg="white", selectcolor="#1e293b", command=self.redraw).pack(anchor="w", padx=8)
        tk.Checkbutton(left, text="Xuất tên bản vẽ (TL 1/scale)", variable=self.v_title, bg="#111827", fg="white", selectcolor="#1e293b").pack(anchor="w", padx=8)
        tk.Checkbutton(left, text="Xuất Bảng Thống Kê + Tổng Hợp", variable=self.v_sched, bg="#111827", fg="white", selectcolor="#1e293b").pack(anchor="w", padx=8)
        tk.Checkbutton(left, text="Cắt khung bảng thống kê", variable=self.v_split, bg="#111827", fg="white", selectcolor="#1e293b").pack(anchor="w", padx=8)
        _row("Số dòng / khung:", self.v_maxrows)
        _row("Tên mặt bằng:", self.v_ten, on_key=_on_ten_key)
        _row("Ký hiệu Bảng TK:", self.v_kh, on_key=_on_kh_key)
        _row("Số lượng sàn (CK):", self.v_slsan)
        _row("Hệ số ĐV CAD (mm=1):", self.v_cad_sc)
        _row("Bảo vệ bê tông (mm):", self.v_cover)
        _row("Neo vào dầm biên:", self.v_bend)
        _row("Bỏ lỗ <= (mm):", self.v_holeskip)
        _row("Bỏ ô sàn <= (mm):", self.v_slabskip)

        tk.Label(left, text="4 LỚP THÉP SÀN", bg="#111827", fg="#38bdf8", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=8, pady=(10, 4))
        self.layer_vars = {}
        for key, label, col in LAYER_META:
            lc = self.cfg["layers"][key]
            f = tk.Frame(left, bg="#1e293b")
            f.pack(fill="x", padx=8, pady=2)
            von = tk.BooleanVar(value=lc.get("on", True))
            vdia = tk.StringVar(value=str(lc["dia"]))
            vpitch = tk.StringVar(value=str(lc["pitch"]))
            vhook = tk.StringVar(value=lc["hook"])
            tk.Checkbutton(f, text=label, variable=von, bg="#1e293b", fg=col, selectcolor="#0f172a", width=11, anchor="w", command=self.recompute).pack(side="left")
            e_dia = tk.Entry(f, textvariable=vdia, width=3, bg="#0f172a", fg="white", relief="flat")
            e_dia.pack(side="left", padx=2)
            e_dia.bind("<Return>", lambda e: self.recompute())
            e_dia.bind("<FocusOut>", lambda e: self.recompute())
            tk.Label(f, text="a", bg="#1e293b", fg="#94a3b8").pack(side="left")
            e_pit = tk.Entry(f, textvariable=vpitch, width=4, bg="#0f172a", fg="white", relief="flat")
            e_pit.pack(side="left", padx=2)
            e_pit.bind("<Return>", lambda e: self.recompute())
            e_pit.bind("<FocusOut>", lambda e: self.recompute())
            cb_hk = ttk.Combobox(f, textvariable=vhook, values=["thang", "vuong", "135"], width=6, state="readonly")
            cb_hk.pack(side="right", padx=2)
            cb_hk.bind("<<ComboboxSelected>>", lambda e: self.recompute())
            self.layer_vars[key] = (von, vdia, vpitch, vhook)

        tk.Button(left, text="Cập nhật tính toán", command=self.recompute, bg="#3b82f6", fg="white", relief="flat", pady=5).pack(fill="x", padx=8, pady=8)
        self.lbl_stats = tk.Label(left, text="SH: 0 | Tổng: 0 thanh | 0.00 m | 0.00 kg", bg="#111827", fg="#34d399", justify="left", wraplength=290, font=("Consolas", 8, "bold"))
        self.lbl_stats.pack(anchor="w", padx=8, pady=2)
        self.lbl_align = tk.Label(left, text="Chưa căn tọa độ CAD", bg="#111827", fg="#fbbf24", justify="left", wraplength=290, font=("Consolas", 8))
        self.lbl_align.pack(anchor="w", padx=8, pady=4)

        self.canvas = tk.Canvas(body, bg="#14181f", highlightthickness=0)
        self.canvas.pack(side="right", fill="both", expand=True, padx=4, pady=4)
        self.canvas.bind("<Configure>", lambda e: self.redraw())
        self.canvas.bind("<Button-1>", self._on_click)
        self.canvas.bind("<MouseWheel>", self._on_wheel)
        self.canvas.bind("<B2-Motion>", self._on_pan)
        self.canvas.bind("<Button-2>", self._on_pan_start)

    def open_json(self):
        p = filedialog.askopenfilename(filetypes=[("Revit JSON", "*.json")])
        if p: self.load_json(p)

    def load_json(self, path):
        with open(path, "r", encoding="utf-8") as f:
            self.data = json.load(f)
        v = self.data.get("view", {})
        sc = int(round(float(v.get("scale") or 100)))
        self.chk_scale.config(text=f"Khoá tỉ lệ theo Revit (1/{sc})")
        vname = (v.get("name") or "").strip().upper()
        if vname:
            self.v_ten.set(vname)
            if not self._kh_diverged:
                self.v_kh.set(vname[:18])
        # Build snap points from grids & slab corners
        self.snap_pts = []
        grids = self.data.get("grids", [])
        for i in range(len(grids)):
            for j in range(i + 1, len(grids)):
                ip = _line_line_int(grids[i]["p0"], grids[i]["p1"], grids[j]["p0"], grids[j]["p1"])
                if ip: self.snap_pts.append(ip)
        for s in self.data.get("slabs", []):
            self.snap_pts.extend(s["outer"])
        # If Revit already passed pick_pts, notify
        pp = self.data.get("pick_pts", [])
        if pp:
            self.lbl_info.config(text=f"View: {v.get('name')} | TL 1/{sc} | Có {len(pp)} điểm Pick từ Revit -> Bấm 'Pick từ Revit -> CAD luôn'")
        else:
            self.lbl_info.config(text=f"View: {v.get('name')} | TL 1/{sc} | {len(self.data['slabs'])} sàn")
        self.recompute()
        self.fit_view()
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(250, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass

    def _sync_cfg(self):
        self.cfg["lock_revit_scale"] = self.v_scale_lock.get()
        self.cfg["sample_style"] = self.v_sample.get()
        self.cfg["draw_plan_geom"] = self.v_plan_geom.get()
        self.cfg["draw_range"] = self.v_range.get()
        self.cfg["draw_title"] = self.v_title.get()
        self.cfg["draw_schedule"] = self.v_sched.get()
        self.cfg["split_table"] = self.v_split.get()
        try: self.cfg["max_rows_per_frame"] = max(1, int(float(self.v_maxrows.get())))
        except Exception: self.cfg["max_rows_per_frame"] = 30
        self.cfg["ten_cau_kien"] = self.v_ten.get().strip() or "SÀN"
        self.cfg["ten_ky_hieu"] = self.v_kh.get().strip() or "SÀN"
        try: self.cfg["sl_san"] = max(1, int(round(float(self.v_slsan.get() or 1))))
        except Exception: self.cfg["sl_san"] = 1
        try: self.cfg["cad_sc"] = float(self.v_cad_sc.get())
        except Exception: pass
        try: self.cfg["cover"] = float(self.v_cover.get())
        except Exception: pass
        try: self.cfg["beam_end"] = float(self.v_bend.get())
        except Exception: pass
        try: self.cfg["hole_skip"] = max(0.0, float(self.v_holeskip.get()))
        except Exception: pass
        try: self.cfg["slab_skip"] = max(0.0, float(self.v_slabskip.get()))
        except Exception: pass
        for key, (von, vdia, vpitch, vhook) in self.layer_vars.items():
            self.cfg["layers"][key]["on"] = von.get()
            try: self.cfg["layers"][key]["dia"] = int(float(vdia.get()))
            except Exception: pass
            try: self.cfg["layers"][key]["pitch"] = int(float(vpitch.get()))
            except Exception: pass
            self.cfg["layers"][key]["hook"] = vhook.get()
        try:
            with open(CFG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _active_scale(self):
        if not self.data: return 100.0
        rsc = float(self.data.get("view", {}).get("scale") or 100.0)
        return rsc if self.cfg.get("lock_revit_scale", True) else float(self.cfg.get("custom_scale", rsc))

    def recompute(self):
        if not self.data: return
        self._sync_cfg()
        self.cells, self.groups, self.ax = build_model(self.data, self.cfg)
        self.syms = plan_symbols(self.groups, self.cfg["draw_sep"], self._active_scale())
        sl_san = max(1, int(round(self.cfg.get("sl_san", 1) or 1)))
        tot_n = sum(g["n"] * sl_san for g in self.groups)
        tot_m = sum(round((g["n"] * sl_san * g["sumL"] / 1000.0), 2) for g in self.groups)
        tot_kg = sum(round(0.00617 * g["dia"] * g["dia"] * round((g["n"] * sl_san * g["sumL"] / 1000.0), 2), 2) for g in self.groups)
        self.lbl_stats.config(text=f"SH: {len(self.groups)} | SL sàn: {sl_san} | Tổng: {tot_n} thanh | {tot_m:.2f} m | {tot_kg:.2f} kg")
        self.redraw()

    def fit_view(self):
        if not self.data: return
        pts = [p for s in self.data["slabs"] for p in s["outer"]]
        x0, y0, x1, y1 = _poly_bbox(pts)
        w = max(self.canvas.winfo_width(), 800); h = max(self.canvas.winfo_height(), 600)
        self.zoom = min(w / max(x1 - x0, 1), h / max(y1 - y0, 1)) * 0.78
        self.pan_x = w * 0.5 - 0.5 * (x0 + x1) * self.zoom
        self.pan_y = h * 0.5 + 0.5 * (y0 + y1) * self.zoom
        self.redraw()

    def _w2c(self, x, y): return x * self.zoom + self.pan_x, -y * self.zoom + self.pan_y
    def _c2w(self, cx, cy): return (cx - self.pan_x) / self.zoom, -(cy - self.pan_y) / self.zoom
    def _on_pan_start(self, e): self._pan0 = (e.x, e.y)
    def _on_pan(self, e):
        self.pan_x += e.x - self._pan0[0]; self.pan_y += e.y - self._pan0[1]
        self._pan0 = (e.x, e.y); self.redraw()
    def _on_wheel(self, e):
        f = 1.15 if e.delta > 0 else 1 / 1.15
        wx, wy = self._c2w(e.x, e.y); self.zoom *= f
        self.pan_x = e.x - wx * self.zoom; self.pan_y = e.y + wy * self.zoom; self.redraw()

    def _on_click(self, e):
        if not self.pick_mode or not self.data: return
        wx, wy = self._c2w(e.x, e.y)
        best, bd = (wx, wy), 15.0 / max(self.zoom, 1e-6)
        for sp in self.snap_pts:
            d = _pdist((wx, wy), sp)
            if d < bd: bd = d; best = sp
        self.canvas_picks.append(best)
        self.redraw()
        if len(self.canvas_picks) >= 1:
            ans = messagebox.askyesnocancel("Pick điểm mốc", f"Đã chọn điểm #{len(self.canvas_picks)}: ({best[0]:.1f}, {best[1]:.1f}).\nYes = Chọn thêm điểm thứ 2 (để xoay)\nNo = Pick sang AutoCAD ngay bây giờ")
            if ans is None:
                self.pick_mode = False; self.canvas_picks = []; self.redraw(); return
            if ans is False or len(self.canvas_picks) == 2:
                self.pick_mode = False
                self._align_from_revit_pts(self.canvas_picks)

    def start_canvas_pick(self):
        if not self.data: return
        self.pick_mode = True; self.canvas_picks = []
        messagebox.showinfo("Pick trên bản vẽ", "Click 1 điểm mốc (hoặc 2 điểm để xoay) trên bản vẽ Revit.\nHệ thống tự bắt dính (Snap) vào giao lưới / góc sàn.")

    def _connect_cad(self):
        import win32com.client
        try:
            acad = win32com.client.GetActiveObject("AutoCAD.Application")
        except Exception:
            raise RuntimeError("Chưa mở AutoCAD! Hãy mở sẵn AutoCAD và bản vẽ cần xuất thép rồi thử lại.")
        acad.Visible = True
        return acad, acad.ActiveDocument

    def _cad_get_point(self, acad, doc, prompt):
        import win32com.client, pythoncom, ctypes
        try:
            hwnd = int(acad.HWND)
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 9)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
        missing = win32com.client.VARIANT(pythoncom.VT_ERROR, -2147352572)  # DISP_E_PARAMNOTFOUND
        last_ex = None
        for call_fn in (
            lambda: _com_call(doc.Utility.GetPoint, missing, prompt),
            lambda: _com_call(doc.Utility.GetPoint, Prompt=prompt),
        ):
            try:
                return call_fn()
            except Exception as ex:
                last_ex = ex
                if "invalid argument point" not in str(ex).lower():
                    raise
        raise last_ex

    def _align_from_revit_pts(self, src_pts):
        try:
            acad, doc = self._connect_cad()
            dst_pts = []
            for i, _ in enumerate(src_pts):
                p = self._cad_get_point(acad, doc, f"\nPick diem dat tuong ung #{i + 1} trong AutoCAD: ")
                dst_pts.append((p[0], p[1]))
            self.T = fit_transform(src_pts, dst_pts, allow_scale=(len(src_pts) >= 2))
            self.lbl_align.config(text=f"Đã căn CAD ({len(src_pts)} điểm): dX={self.T['tx']:.1f}, dY={self.T['ty']:.1f}, θ={math.degrees(self.T['theta']):.2f}°, sc={self.T['scale']}")
            return True
        except Exception as ex:
            messagebox.showerror("Lỗi AutoCAD", str(ex))
            return False

    def do_pick_and_export(self, auto_schedule=True):
        if not self.data: return False
        pp = self.data.get("pick_pts") or []
        if pp:
            if self._align_from_revit_pts(pp):
                return self.do_export(auto_schedule=auto_schedule)
            return False
        if self.snap_pts:
            if messagebox.askyesno("Pick Revit -> CAD", "JSON chưa có điểm Pick từ Revit.\nBạn có muốn tự Pick 1-2 điểm trên màn hình rồi sang CAD không?\n(No = lấy giao lưới đầu tiên làm mốc)"):
                self.start_canvas_pick()
                return False
            if self._align_from_revit_pts([self.snap_pts[0]]):
                return self.do_export(auto_schedule=auto_schedule)
        return False

    def do_align_grids(self):
        if not self.data or len(self.data.get("grids", [])) < 2:
            messagebox.showwarning("Thiếu lưới", "Không đủ lưới trục để tự căn."); return
        try:
            _, doc = self._connect_cad()
            ms = doc.ModelSpace
            cad_lines = {}
            for i in range(ms.Count):
                try:
                    ent = ms.Item(i)
                    if ent.ObjectName == "AcDbLine" and ent.Layer in ("3", "S-GRID-IDEN"):
                        sp, ep = ent.StartPoint, ent.EndPoint
                        cad_lines.setdefault(ent.Layer, []).append(((sp[0], sp[1]), (ep[0], ep[1])))
                except Exception:
                    pass
            if len(self.snap_pts) >= 2:
                self._align_from_revit_pts([self.snap_pts[0], self.snap_pts[-1]])
        except Exception as ex:
            messagebox.showerror("Lỗi căn lưới", str(ex))

    def do_export(self, auto_schedule=True):
        if not self.data: return False
        self._sync_cfg()
        if not self.T:
            pp = self.data.get("pick_pts") or []
            src_pts = pp if pp else ([self.snap_pts[0]] if self.snap_pts else [self.data["slabs"][0]["outer"][0]])
            if not self._align_from_revit_pts(src_pts):
                return False
        try:
            acad, doc = self._connect_cad()
            ms = doc.ModelSpace
            sc_revit = self._active_scale()
            cad_sc = self.cfg.get("cad_sc", 1.0) * self.T.get("scale", 1.0)
            sc = sc_revit * cad_sc

            # Clean previous exported handles
            if os.path.isfile(HDL_FILE):
                try:
                    old = json.load(open(HDL_FILE, "r"))
                    for h in old:
                        try: doc.HandleToObject(h).Delete()
                        except Exception: pass
                except Exception: pass

            _ensure_layer(doc, "3", 3)
            _ensure_layer(doc, "S-GRID-IDEN", 1)
            _ensure_layer(doc, "A-ANNO-DIMS", 3)
            _ensure_layer(doc, "A-FLOR", 8)
            _ensure_layer(doc, "S-BEAM", 3)
            _ensure_layer(doc, "S-COLS", 7)
            _ensure_layer(doc, "DCE_ThepChu", 1, 35)
            _ensure_layer(doc, "DCE_ThepDuoi", 1, 35)
            _ensure_layer(doc, "DCE_ThepTren", 1, 35)
            _ensure_layer(doc, "DCE_Block", 8)
            _ensure_layer(doc, "Dce_text", 7)
            _ensure_textstyle(doc, "Dce_Text", 0.8)
            _ensure_dimstyle(doc, sc_revit, "DIM_CHUAN", cad_sc)

            handles = []
            grid_bubble_pts = []

            # Export Revit Floor Plan geometry (Extended Grids + Bubbles + 2-Layer Grid Dims, Slabs + Openings, Beams, Columns)
            if self.cfg.get("draw_plan_geom", True):
                ext_grids, g_dims = _build_grid_layout(self.data.get("grids", []), self.data.get("slabs", []), sc_revit)
                r_bub = 3.5 * sc
                for gr in ext_grids:
                    p0 = xf(gr["p0"], self.T); p1 = xf(gr["p1"], self.T)
                    handles.append(_add_line(ms, p0[0], p0[1], p1[0], p1[1], "3", 3).Handle)
                    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
                    L = math.hypot(dx, dy) or 1.0
                    ux, uy = dx / L, dy / L
                    cs = (p0[0] - ux * r_bub, p0[1] - uy * r_bub)
                    ce = (p1[0] + ux * r_bub, p1[1] + uy * r_bub)
                    grid_bubble_pts.extend([
                        (cs[0] - ux * r_bub, cs[1] - uy * r_bub),
                        (ce[0] + ux * r_bub, ce[1] + uy * r_bub),
                    ])
                    for cc in (cs, ce):
                        cir = _com_call(ms.AddCircle, _cad_pt(cc[0], cc[1]), float(r_bub))
                        cir.Layer = "S-GRID-IDEN"; cir.Color = 1
                        handles.append(cir.Handle)
                        handles.append(_add_text(ms, str(gr.get("name", "")), cc[0], cc[1], 2.5 * sc, "S-GRID-IDEN", 1, 10).Handle)

                # 2-Layer Revit Grid Dimensions (inner bay-by-bay + outer total span)
                for gd in g_dims:
                    p0 = xf(gd["p0"], self.T); p1 = xf(gd["p1"], self.T); dp = xf(gd["dim_pt"], self.T)
                    try:
                        dim_ent = _com_call(ms.AddDimAligned, _cad_pt(p0[0], p0[1]), _cad_pt(p1[0], p1[1]), _cad_pt(dp[0], dp[1]))
                        dim_ent.Layer = "A-ANNO-DIMS"
                        dim_ent.Color = 3
                        try: dim_ent.StyleName = "DIM_CHUAN"
                        except Exception: pass
                        handles.append(dim_ent.Handle)
                    except Exception:
                        cos_t, sin_t = math.cos(self.T["theta"]), math.sin(self.T["theta"])
                        perp_w = (gd["perp"][0] * cos_t - gd["perp"][1] * sin_t, gd["perp"][0] * sin_t + gd["perp"][1] * cos_t)
                        dist_p = (dp[0] - p0[0]) * perp_w[0] + (dp[1] - p0[1]) * perp_w[1]
                        sgn_p = 1.0 if dist_p >= 0 else -1.0
                        d0 = (p0[0] + perp_w[0] * dist_p, p0[1] + perp_w[1] * dist_p)
                        d1 = (p1[0] + perp_w[0] * dist_p, p1[1] + perp_w[1] * dist_p)
                        ext_s = 1.2 * sc * sgn_p; ext_e = dist_p + 1.6 * sc * sgn_p
                        handles.append(_add_line(ms, p0[0] + perp_w[0] * ext_s, p0[1] + perp_w[1] * ext_s, p0[0] + perp_w[0] * ext_e, p0[1] + perp_w[1] * ext_e, "A-ANNO-DIMS", 3).Handle)
                        handles.append(_add_line(ms, p1[0] + perp_w[0] * ext_s, p1[1] + perp_w[1] * ext_s, p1[0] + perp_w[0] * ext_e, p1[1] + perp_w[1] * ext_e, "A-ANNO-DIMS", 3).Handle)
                        dl = math.hypot(d1[0] - d0[0], d1[1] - d0[1]) or 1.0
                        ux_d, uy_d = (d1[0] - d0[0]) / dl, (d1[1] - d0[1]) / dl
                        handles.append(_add_line(ms, d0[0] - ux_d * 1.4 * sc, d0[1] - uy_d * 1.4 * sc, d1[0] + ux_d * 1.4 * sc, d1[1] + uy_d * 1.4 * sc, "A-ANNO-DIMS", 3).Handle)
                        ang_d = math.atan2(uy_d, ux_d)
                        if ang_d > math.pi * 0.5: ang_d -= math.pi
                        if ang_d <= -math.pi * 0.5: ang_d += math.pi
                        nx_t, ny_t = -math.sin(ang_d), math.cos(ang_d)
                        handles.append(_add_text(ms, str(gd["val_mm"]), 0.5 * (d0[0] + d1[0]) + nx_t * 1.55 * sc, 0.5 * (d0[1] + d1[1]) + ny_t * 1.55 * sc, 2.2 * sc, "A-ANNO-DIMS", 3, 10, ang_d).Handle)

                for sl in self.data.get("slabs", []):
                    pts_s = [xf(p, self.T) for p in sl["outer"]]
                    if len(pts_s) >= 3:
                        ps = _com_call(ms.AddLightWeightPolyline, _cad_pts2d(pts_s))
                        ps.Closed = True; ps.Layer = "A-FLOR"; ps.Color = 8
                        handles.append(ps.Handle)
                    for hl_pts in sl.get("holes", []):
                        hx = [xf(p, self.T) for p in hl_pts]
                        if len(hx) >= 3:
                            ph = _com_call(ms.AddLightWeightPolyline, _cad_pts2d(hx))
                            ph.Closed = True; ph.Layer = "A-FLOR"; ph.Color = 3
                            handles.append(ph.Handle)
                        if len(hx) >= 4:
                            handles.append(_add_line(ms, hx[0][0], hx[0][1], hx[2][0], hx[2][1], "A-FLOR", 3).Handle)
                            handles.append(_add_line(ms, hx[1][0], hx[1][1], hx[3][0], hx[3][1], "A-FLOR", 3).Handle)

                for bm in self.data.get("beams", []):
                    for poly in bm.get("polys", []):
                        bp_xf = [xf(p, self.T) for p in poly]
                        if len(bp_xf) >= 3:
                            pb = _com_call(ms.AddLightWeightPolyline, _cad_pts2d(bp_xf))
                            pb.Closed = True; pb.Layer = "S-BEAM"; pb.Color = 3
                            handles.append(pb.Handle)

                for col in self.data.get("columns", []):
                    for poly in col.get("polys", []):
                        cp_xf = [xf(p, self.T) for p in poly]
                        if len(cp_xf) >= 3:
                            pc = _com_call(ms.AddLightWeightPolyline, _cad_pts2d(cp_xf))
                            pc.Closed = True; pc.Layer = "S-COLS"; pc.Color = 7
                            handles.append(pc.Handle)

            bar_w = 0.35 * sc
            drawn_bars = set()
            if self.cfg.get("sample_style", True):
                # Representative bars per cluster separated by Top (DCE_ThepTren) & Bottom (DCE_ThepDuoi)
                for s in self.syms:
                    rb = s["rep_bar"]
                    key = (s["sh"], round(rb["v"], 1))
                    if key in drawn_bars: continue
                    drawn_bars.add(key)
                    pts_xf = [xf(p, self.T) for p in rb["pts"]]
                    pl = _com_call(ms.AddLightWeightPolyline, _cad_pts2d(pts_xf))
                    pl.Layer = "DCE_ThepTren" if s["is_top"] else "DCE_ThepDuoi"
                    pl.Color = 1
                    try: pl.ConstantWidth = bar_w
                    except Exception: pass
                    handles.append(pl.Handle)
            else:
                for g in self.groups:
                    blayer = "DCE_ThepTren" if g["layer"].startswith("tren") else "DCE_ThepDuoi"
                    for b in g["bars"]:
                        pts_xf = [xf(p, self.T) for p in b["pts"]]
                        pl = _com_call(ms.AddLightWeightPolyline, _cad_pts2d(pts_xf))
                        pl.Layer = blayer; pl.Color = 1
                        try: pl.ConstantWidth = bar_w
                        except Exception: pass
                        handles.append(pl.Handle)

            # Ensure attributed callout block Dce_KhThepSan for AutoLISP SAN_SUATHEP / SAN_TKT
            bname = "Dce_KhThepSan"
            extra_defs = [
                ("SLCK", "1", -7.0), ("ZDATA", "", -7.5),
                ("ZDATA2", "", -8.0), ("ZDATA3", "", -8.5), ("ZDATA4", "", -9.0),
            ]
            try:
                blk = doc.Blocks.Item(bname)
                existing_tags = set()
                try:
                    for bi in range(blk.Count):
                        it_b = blk.Item(bi)
                        if it_b.ObjectName == "AcDbAttributeDefinition":
                            existing_tags.add(it_b.TagString.upper())
                except Exception:
                    pass
                for tg, df, yy in extra_defs:
                    if tg not in existing_tags:
                        try:
                            az = _com_call(blk.AddAttribute, 2.0, 1, tg, _cad_pt(0.0, yy), tg, df)
                            az.Layer = "Dce_text"; az.Color = 7
                            try: az.StyleName = "Dce_Text"
                            except Exception: pass
                        except Exception:
                            pass
            except Exception:
                blk = doc.Blocks.Add(_cad_pt(0, 0), bname)
                c_ent = _com_call(blk.AddCircle, _cad_pt(-2.5, 0.0), 2.5)
                c_ent.Layer = "DCE_Block"; c_ent.Color = 8
                def _add_att(tag, prompt, defv, x, y, col, flags, align):
                    a = _com_call(blk.AddAttribute, 2.0, flags, prompt, _cad_pt(x, y), tag, defv)
                    a.Layer = "Dce_text"; a.Color = col
                    try: a.StyleName = "Dce_Text"
                    except Exception: pass
                    if align != 0:
                        a.Alignment = align; a.TextAlignmentPoint = _cad_pt(x, y)
                    return a
                _add_att("SH", "So hieu", "1", -2.5, 0.0, 2, 0, 10)
                _add_att("DKVAKC", "Duong kinh a", "%%c10a200", 1.0, 0.0, 3, 0, 9)
                for tg, df, yy in (
                    ("TENCK", self.cfg["ten_ky_hieu"], -3.0), ("DK", "10", -3.5), ("KC", "200", -4.0),
                    ("SL", "1", -4.5), ("DAITHANH", "1000", -5.0), ("MOC", "0", -5.5),
                    ("HINH", "thang", -6.0), ("LOP", "duoi_chinh", -6.5),
                    ("SLCK", "1", -7.0), ("ZDATA", "", -7.5),
                    ("ZDATA2", "", -8.0), ("ZDATA3", "", -8.5), ("ZDATA4", "", -9.0),
                ):
                    _add_att(tg, tg, df, 0.0, yy, 7, 1, 0)

            sl_san = max(1, int(round(self.cfg.get("sl_san", 1) or 1)))
            for s in self.syms:
                cx, cy = xf((s["cx"], s["cy"]), self.T)
                ang = math.radians(s["ang"]) + self.T["theta"]
                # Subtle leader tick from bar to circle edge
                rb = s["rep_bar"]
                ud_w = (s["u_dir"][0] * math.cos(self.T["theta"]) - s["u_dir"][1] * math.sin(self.T["theta"]),
                        s["u_dir"][0] * math.sin(self.T["theta"]) + s["u_dir"][1] * math.cos(self.T["theta"]))
                bp = xf(rb["p0"], self.T)
                bp1 = xf(rb["p1"], self.T)
                cir_c = (cx - 2.5 * sc * math.cos(ang), cy - 2.5 * sc * math.sin(ang))
                bar_span = (bp1[0] - bp[0]) * ud_w[0] + (bp1[1] - bp[1]) * ud_w[1]
                raw_proj = (cir_c[0] - bp[0]) * ud_w[0] + (cir_c[1] - bp[1]) * ud_w[1]
                proj = max(0.0, min(bar_span, raw_proj)) if bar_span >= 0 else min(0.0, max(bar_span, raw_proj))
                on_bar = (bp[0] + proj * ud_w[0], bp[1] + proj * ud_w[1])
                d_bar = math.hypot(cir_c[0] - on_bar[0], cir_c[1] - on_bar[1])
                if d_bar > 2.6 * sc:
                    ux, uy = (cir_c[0] - on_bar[0]) / d_bar, (cir_c[1] - on_bar[1]) / d_bar
                    tick = _add_line(ms, on_bar[0], on_bar[1], cir_c[0] - ux * 2.5 * sc, cir_c[1] - uy * 2.5 * sc, "DCE_Block", 8)
                    handles.append(tick.Handle)

                ins = _com_call(ms.InsertBlock, _cad_pt(cx, cy), bname, sc, sc, sc, ang)
                ins.Layer = "DCE_Block"
                qty_val = s.get("n_cluster", s["n_total"])
                len_val = s.get("len_eff", s["len"])
                zgs = s.get("zone_groups") or []
                z_full = (
                    f"{qty_val}|{len_val}#" + ";".join(f"{zg['sh']},{zg['len']},{zg['n']}" for zg in zgs)
                    if len(zgs) > 1 else ""
                )
                z_chunks = []
                if z_full:
                    cur_c = ""
                    for part in z_full.split(";"):
                        next_c = f"{cur_c};{part}" if cur_c else part
                        if len(next_c) > 235 and cur_c:
                            z_chunks.append(f"{cur_c};")
                            cur_c = part
                        else:
                            cur_c = next_c
                    if cur_c:
                        z_chunks.append(cur_c)
                attr_vals = {
                    "SH": str(s["sh"]), "DKVAKC": s["label"],
                    "TENCK": self.cfg["ten_ky_hieu"], "DK": str(s["dia"]), "KC": str(s["pitch"]),
                    "SL": str(qty_val),
                    "DAITHANH": str(len_val), "MOC": str(s["hl"]),
                    "HINH": s["hook"], "LOP": s["layer"],
                    "SLCK": str(sl_san),
                    "ZDATA": z_chunks[0] if len(z_chunks) > 0 else "",
                    "ZDATA2": z_chunks[1] if len(z_chunks) > 1 else "",
                    "ZDATA3": z_chunks[2] if len(z_chunks) > 2 else "",
                    "ZDATA4": z_chunks[3] if len(z_chunks) > 3 else "",
                }
                for att in ins.GetAttributes():
                    tg = att.TagString.upper()
                    if tg in attr_vals:
                        att.TextString = attr_vals[tg]
                handles.append(ins.Handle)

            # Title block below plan (clearing bottom grid bubbles)
            all_w = [xf(p, self.T) for sl in self.data["slabs"] for p in sl["outer"]] + grid_bubble_pts
            wx0, wy0, wx1, wy1 = _poly_bbox(all_w)
            if self.cfg.get("draw_title", True):
                tx_c = 0.5 * (wx0 + wx1); ty_c = wy0 - 9.0 * sc
                t1 = _add_text(ms, f"%%uMẶT BẰNG THÉP SÀN {self.cfg['ten_cau_kien']}", tx_c, ty_c, 4.0 * sc, layer="Dce_text", color=7, align=10)
                t2 = _add_text(ms, f"TL: 1/{int(round(sc_revit))}", tx_c, ty_c - 6.0 * sc, 2.0 * sc, layer="Dce_text", color=1, align=10)
                handles.extend([t1.Handle, t2.Handle])

            # Schedule tables (with frame splitting max_rows_per_frame, default 30)
            if self.cfg.get("draw_schedule", True) and self.groups:
                tsc = sc * (50.0 / 75.0)
                tb_x, tb_y = wx0, wy0 - 33.0 * sc
                if not auto_schedule:
                    try:
                        tp = self._cad_get_point(acad, doc, "\nPick vi tri dat BANG THONG KE COT THEP (Enter de dat duoi mat bang): ")
                        tb_x, tb_y = tp[0], tp[1]
                    except Exception:
                        pass
                handles.extend(self._draw_cad_tables(ms, tb_x, tb_y, tsc))

            with open(HDL_FILE, "w") as f:
                json.dump(handles, f)
            messagebox.showinfo("Thành công", f"Đã xuất {len(handles)} đối tượng sang AutoCAD theo tỉ lệ 1/{int(round(sc_revit))}!")
            return True
        except Exception as ex:
            messagebox.showerror("Lỗi xuất CAD", str(ex))
            return False

    def _draw_cad_tables(self, ms, x0_base, y0, tsc):
        hdls = []
        cols = [0, 15, 25, 75, 90, 110, 122.5, 135, 147.5, 167.5, 192.5]
        W = 192.5 * tsc; H_hdr = 35.0 * tsc; H_row = 8.0 * tsc; gap_f = 12.0 * tsc
        max_rows = max(1, int(self.cfg.get("max_rows_per_frame", 30))) if self.cfg.get("split_table", True) else len(self.groups)
        frames = [self.groups[i:i + max_rows] for i in range(0, len(self.groups), max_rows)] or [[]]
        lowest_y = y0 - H_hdr

        for f_idx, f_rows in enumerate(frames):
            x0 = x0_base + f_idx * (W + gap_f)
            hdls.append(_add_rect(ms, x0, y0 - H_hdr, x0 + W, y0, "DCE_Block", 7).Handle)
            hdls.append(_add_line(ms, x0, y0 - 10 * tsc, x0 + W, y0 - 10 * tsc, "DCE_Block", 7).Handle)
            t_suf = f" ({f_idx + 1}/{len(frames)})" if len(frames) > 1 else ""
            hdls.append(_add_text(ms, f"BẢNG THỐNG KÊ CỐT THÉP{t_suf}", x0 + W * 0.5, y0 - 5 * tsc, 4.5 * tsc, "Dce_text", 3, 10).Handle)
            hdrs = [
                (0, 1, "TÊN\nCẤU KIỆN"), (1, 2, "SỐ\nHIỆU"), (2, 3, "HÌNH DẠNG, KÍCH THƯỚC"),
                (3, 4, "ĐƯỜNG\nKÍNH\n(mm)"), (4, 5, "CHIỀU DÀI\nTHANH\n(mm)"), (5, 6, "SỐ\nCẤU KIỆN"),
                (8, 9, "TỔNG\nCHIỀU DÀI\n(m)"), (9, 10, "TỔNG\nKHỐI LƯỢNG\n(kg)")
            ]
            for c in cols[1:-1]:
                top_off = 22.5 * tsc if c == 135 else 10.0 * tsc
                hdls.append(_add_line(ms, x0 + c * tsc, y0 - H_hdr, x0 + c * tsc, y0 - top_off, "DCE_Block", 7).Handle)
            hdls.append(_add_line(ms, x0 + 122.5 * tsc, y0 - 22.5 * tsc, x0 + 147.5 * tsc, y0 - 22.5 * tsc, "DCE_Block", 7).Handle)
            for c0, c1, txt in hdrs:
                cx = x0 + 0.5 * (cols[c0] + cols[c1]) * tsc
                lines = txt.split("\n")
                for li, ln in enumerate(lines):
                    yy = y0 - (22.5 - (len(lines) - 1) * 1.5 + li * 3.0) * tsc
                    hdls.append(_add_text(ms, ln, cx, yy, 2.0 * tsc, "Dce_text", 3, 10).Handle)
            hdls.append(_add_text(ms, "SỐ LƯỢNG", x0 + 135 * tsc, y0 - 16.5 * tsc, 2.0 * tsc, "Dce_text", 3, 10).Handle)
            hdls.append(_add_text(ms, "1 CK", x0 + 128.75 * tsc, y0 - 28.5 * tsc, 2.0 * tsc, "Dce_text", 3, 10).Handle)
            hdls.append(_add_text(ms, "T. BỘ", x0 + 141.25 * tsc, y0 - 28.5 * tsc, 2.0 * tsc, "Dce_text", 3, 10).Handle)

            y_cur = y0 - H_hdr
            for g in f_rows:
                y_bot = y_cur - H_row
                hdls.append(_add_line(ms, x0 + 15 * tsc, y_bot, x0 + W, y_bot, "DCE_Block", 7).Handle)
                for c in cols[1:]:
                    hdls.append(_add_line(ms, x0 + c * tsc, y_cur, x0 + c * tsc, y_bot, "DCE_Block", 7).Handle)
                ym = y_cur - 0.5 * H_row
                hdls.append(_add_text(ms, str(g["sh"]), x0 + 20 * tsc, ym, 2.2 * tsc, "Dce_text", 2, 10).Handle)
                sx0, sx1 = x0 + 35 * tsc, x0 + 65 * tsc
                if g["hook"] == "thang":
                    pl = _com_call(ms.AddLightWeightPolyline, _cad_pts2d([(sx0, ym - 1 * tsc), (sx1, ym - 1 * tsc)]))
                    pl.Layer = "DCE_ThepChu"; pl.Color = 1; hdls.append(pl.Handle)
                    hdls.append(_add_text(ms, str(g["sumL"]), x0 + 50 * tsc, ym + 1.3 * tsc, 1.8 * tsc, "Dce_text", 2, 10).Handle)
                elif g["hook"] == "135":
                    pl = _com_call(ms.AddLightWeightPolyline, _cad_pts2d([
                        (sx0 + 3.2 * tsc, ym + 0.9 * tsc),
                        (sx0, ym - 1.5 * tsc),
                        (sx0 + 1.1 * tsc, ym - 2.1 * tsc),
                        (sx1 - 1.1 * tsc, ym - 2.1 * tsc),
                        (sx1, ym - 1.5 * tsc),
                        (sx1 - 3.2 * tsc, ym + 0.9 * tsc),
                    ]))
                    pl.Layer = "DCE_ThepChu"; pl.Color = 1; hdls.append(pl.Handle)
                    hdls.append(_add_text(ms, str(g["len"]), x0 + 50 * tsc, ym + 0.6 * tsc, 1.8 * tsc, "Dce_text", 2, 10).Handle)
                    hdls.append(_add_text(ms, str(g["hl"]), sx0 - 4 * tsc, ym - 0.5 * tsc, 1.6 * tsc, "Dce_text", 2, 10).Handle)
                    hdls.append(_add_text(ms, str(g["hl"]), sx1 + 4 * tsc, ym - 0.5 * tsc, 1.6 * tsc, "Dce_text", 2, 10).Handle)
                else:
                    pl = _com_call(ms.AddLightWeightPolyline, _cad_pts2d([(sx0, ym - 2.2 * tsc), (sx0, ym + 0.5 * tsc), (sx1, ym + 0.5 * tsc), (sx1, ym - 2.2 * tsc)]))
                    pl.Layer = "DCE_ThepChu"; pl.Color = 1; hdls.append(pl.Handle)
                    hdls.append(_add_text(ms, str(g["len"]), x0 + 50 * tsc, ym + 2.0 * tsc, 1.8 * tsc, "Dce_text", 2, 10).Handle)
                    hdls.append(_add_text(ms, str(g["hl"]), sx0 - 4 * tsc, ym - 1 * tsc, 1.6 * tsc, "Dce_text", 2, 10).Handle)
                    hdls.append(_add_text(ms, str(g["hl"]), sx1 + 4 * tsc, ym - 1 * tsc, 1.6 * tsc, "Dce_text", 2, 10).Handle)
                sl_san = max(1, int(round(self.cfg.get("sl_san", 1) or 1)))
                qty_tot = g["n"] * sl_san
                row_m = round((qty_tot * g["sumL"] / 1000.0), 2)
                row_kg = round(0.00617 * g["dia"] * g["dia"] * row_m, 2)
                vals = [
                    (82.5, str(g["dia"])), (100.0, str(g["sumL"])), (116.25, str(sl_san)),
                    (128.75, str(g["n"])), (141.25, str(qty_tot)),
                    (157.5, f"{row_m:.2f}"), (180.0, f"{row_kg:.2f}")
                ]
                for cx_mm, txt in vals:
                    hdls.append(_add_text(ms, txt, x0 + cx_mm * tsc, ym, 2.0 * tsc, "Dce_text", 2, 10).Handle)
                y_cur = y_bot

            n_f = len(f_rows)
            hdls.append(_add_rect(ms, x0, y_cur, x0 + 15 * tsc, y0 - H_hdr, "DCE_Block", 7).Handle)
            if n_f > 0:
                hdls.append(_add_text(ms, self.cfg["ten_ky_hieu"], x0 + 6.5 * tsc, y0 - H_hdr - 0.5 * n_f * H_row, 2.5 * tsc, "Dce_text", 7, 10, math.pi * 0.5).Handle)
                hdls.append(_add_text(ms, f"SL: {sl_san}", x0 + 11 * tsc, y0 - H_hdr - 0.5 * n_f * H_row, 2.0 * tsc, "Dce_text", 7, 10, math.pi * 0.5).Handle)
            lowest_y = min(lowest_y, y_cur)

        # Summary table below
        sl_san = max(1, int(round(self.cfg.get("sl_san", 1) or 1)))
        sum_rows = summarize_by_dia(self.groups, sl_san)
        sy = lowest_y - 6 * tsc
        sh_hdr = 10 * tsc; sh_row = 7 * tsc; sw = 85 * tsc
        hdls.append(_add_rect(ms, x0_base, sy - sh_hdr, x0_base + sw, sy, "DCE_Block", 7).Handle)
        hdls.append(_add_text(ms, "TỔNG HỢP CỐT THÉP", x0_base + sw * 0.5, sy - 5 * tsc, 3.0 * tsc, "Dce_text", 3, 10).Handle)
        sy -= sh_hdr
        for sr in sum_rows:
            hdls.append(_add_rect(ms, x0_base, sy - sh_row, x0_base + sw, sy, "DCE_Block", 7).Handle)
            hdls.append(_add_text(ms, f"%%c{sr['dia']}: {sr['m']:.2f} m  |  {sr['kg']:.2f} kg  |  {sr['bars_117']} cây 11.7m", x0_base + 3 * tsc, sy - 3.5 * tsc, 2.0 * tsc, "Dce_text", 2, 9).Handle)
            sy -= sh_row
        kg_le10 = sum(r["kg"] for r in sum_rows if r["dia"] <= 10)
        kg_gt10 = sum(r["kg"] for r in sum_rows if r["dia"] > 10)
        hdls.append(_add_rect(ms, x0_base, sy - sh_row, x0_base + sw, sy, "DCE_Block", 7).Handle)
        hdls.append(_add_text(ms, f"- Nhóm %%c <= 10: {kg_le10:.2f} kg   |   > 10: {kg_gt10:.2f} kg", x0_base + 3 * tsc, sy - 3.5 * tsc, 2.0 * tsc, "Dce_text", 7, 9).Handle)
        return hdls

    def redraw(self):
        c = self.canvas; c.delete("all")
        if not self.data: return
        sc_rev = self._active_scale()
        ext_grids, g_dims = _build_grid_layout(self.data.get("grids", []), self.data.get("slabs", []), sc_rev)
        # Extended Grids & 2-Layer Grid Dimensions
        for g in ext_grids:
            x0, y0 = self._w2c(*g["p0"]); x1, y1 = self._w2c(*g["p1"])
            c.create_line(x0, y0, x1, y1, fill="#166534", dash=(4, 4))
            c.create_text(x0, y0 - 10, text=g["name"], fill="#ef4444", font=("Segoe UI", 9, "bold"))
            c.create_text(x1, y1 - 10, text=g["name"], fill="#ef4444", font=("Segoe UI", 9, "bold"))
        for gd in g_dims:
            p0, p1, dp, perp = gd["p0"], gd["p1"], gd["dim_pt"], gd["perp"]
            dist_p = (dp[0] - p0[0]) * perp[0] + (dp[1] - p0[1]) * perp[1]
            sgn_p = 1.0 if dist_p >= 0 else -1.0
            d0 = (p0[0] + perp[0] * dist_p, p0[1] + perp[1] * dist_p)
            d1 = (p1[0] + perp[0] * dist_p, p1[1] + perp[1] * dist_p)
            ext_s, ext_e = 1.2 * sc_rev * sgn_p, dist_p + 1.6 * sc_rev * sgn_p
            c.create_line(*self._w2c(p0[0] + perp[0] * ext_s, p0[1] + perp[1] * ext_s),
                          *self._w2c(p0[0] + perp[0] * ext_e, p0[1] + perp[1] * ext_e), fill="#22c55e")
            c.create_line(*self._w2c(p1[0] + perp[0] * ext_s, p1[1] + perp[1] * ext_s),
                          *self._w2c(p1[0] + perp[0] * ext_e, p1[1] + perp[1] * ext_e), fill="#22c55e")
            c.create_line(*self._w2c(*d0), *self._w2c(*d1), fill="#22c55e")
            c.create_text(*self._w2c(0.5 * (d0[0] + d1[0]), 0.5 * (d0[1] + d1[1])), text=str(gd["val_mm"]), fill="#4ade80", font=("Consolas", 8, "bold"))
        # Slabs
        for s in self.data["slabs"]:
            pts = [v for p in s["outer"] for v in self._w2c(*p)]
            c.create_polygon(pts, outline="#475569", fill="#1e293b", width=1)
            for h in s.get("holes", []):
                hpts = [v for p in h for v in self._w2c(*p)]
                c.create_polygon(hpts, outline="#22c55e", fill="#0f172a", width=1)
        # Beams & Columns
        for b in self.data.get("beams", []):
            for p in b["polys"]:
                pts = [v for q in p for v in self._w2c(*q)]
                c.create_polygon(pts, outline="#7f1d1d", fill="", width=1)
        for col in self.data.get("columns", []):
            for p in col["polys"]:
                pts = [v for q in p for v in self._w2c(*q)]
                c.create_polygon(pts, outline="#94a3b8", fill="#334155", width=1)
        # Bars (separated Top vs Bottom)
        if self.cfg.get("sample_style", True):
            for s in self.syms:
                rb = s["rep_bar"]
                pts = [v for p in rb["pts"] for v in self._w2c(*p)]
                c.create_line(pts, fill=("#ef4444" if s["is_top"] else "#22d3ee"), width=2)
        else:
            for g in self.groups:
                col_b = "#ef4444" if g["layer"].startswith("tren") else "#22d3ee"
                for b in g["bars"]:
                    pts = [v for p in b["pts"] for v in self._w2c(*p)]
                    c.create_line(pts, fill=col_b, width=1)
        # Callouts & thin leader ticks (matching CadCanvas + DXF geometry)
        sc_rev = self._active_scale()
        r_px = max(4.5, min(12.5, 2.25 * sc_rev * self.zoom))
        f_sz = max(7, min(11, int(round(1.9 * sc_rev * self.zoom))))
        for s in self.syms:
            cx, cy = self._w2c(s["cx"], s["cy"])
            ang_rad = math.radians(s["ang"])
            cir_x = cx - r_px * math.cos(ang_rad)
            cir_y = cy + r_px * math.sin(ang_rad)

            rb = s["rep_bar"]
            bx0, by0 = self._w2c(*rb["p0"])
            bx1, by1 = self._w2c(*rb["p1"])
            ux_w, uy_w = math.cos(ang_rad), -math.sin(ang_rad)
            bar_span = (bx1 - bx0) * ux_w + (by1 - by0) * uy_w
            raw_proj = (cir_x - bx0) * ux_w + (cir_y - by0) * uy_w
            proj = max(0.0, min(bar_span, raw_proj)) if bar_span >= 0 else min(0.0, max(bar_span, raw_proj))
            on_bx, on_by = bx0 + proj * ux_w, by0 + proj * uy_w
            d_px = math.hypot(cir_x - on_bx, cir_y - on_by)
            if d_px > r_px + 1.0:
                vx, vy = (cir_x - on_bx) / d_px, (cir_y - on_by) / d_px
                c.create_line(on_bx, on_by, cir_x - vx * r_px, cir_y - vy * r_px, fill="#64748b", width=1)

            c.create_oval(cir_x - r_px, cir_y - r_px, cir_x + r_px, cir_y + r_px, outline="#94a3b8", fill="#0f172a")
            c.create_text(cir_x, cir_y, text=str(s["sh"]), fill="#facc15", font=("Segoe UI", f_sz, "bold"))
            lbl = s["label"].replace("%%c", "Ø")
            tx = cx + (r_px * 0.45) * math.cos(ang_rad)
            ty = cy - (r_px * 0.45) * math.sin(ang_rad)
            try:
                c.create_text(tx, ty, text=lbl, fill="#22c55e", font=("Consolas", f_sz, "bold"), anchor="w", angle=s["ang"])
            except Exception:
                c.create_text(tx, ty, text=lbl, fill="#22c55e", font=("Consolas", f_sz, "bold"), anchor="w")
        # Canvas Pick Points
        for i, p in enumerate(self.canvas_picks):
            px, py = self._w2c(*p)
            c.create_oval(px - 6, py - 6, px + 6, py + 6, outline="#06b6d4", width=2)
            c.create_text(px + 12, py - 10, text=f"P{i+1}", fill="#06b6d4", font=("Segoe UI", 9, "bold"))

if __name__ == "__main__":
    args = sys.argv[1:]
    direct_mode = "--direct" in args
    jp = next((a for a in args if not a.startswith("--")), None)
    try:
        app = ThepSanApp(jp)
        if direct_mode and app.data:
            app.root.withdraw()
            ok = app.do_pick_and_export(auto_schedule=True)
            if ok:
                app.root.destroy()
            else:
                app.root.deiconify()
                app.root.mainloop()
        else:
            app.root.mainloop()
    except Exception as _ex:
        import traceback
        err_txt = traceback.format_exc()
        try:
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror("Lỗi khởi chạy ThepSan_CAD", "{0}\n\n{1}".format(_ex, err_txt[-800:]))
        except Exception:
            sys.stderr.write(err_txt)

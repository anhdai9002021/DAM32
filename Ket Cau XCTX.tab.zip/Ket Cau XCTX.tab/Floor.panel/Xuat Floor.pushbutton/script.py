# -*- coding: utf-8 -*-
"""pyRevit -> JSON v2 (Slabs, Openings, Grids, Beams, Columns, View Scale & Pick Points) -> AutoCAD Tool"""
import os, json, re, math, subprocess
from pyrevit import revit, DB, forms, UI

doc = revit.doc
uidoc = revit.uidoc
view = doc.ActiveView
FT_MM = 304.8

if not isinstance(view, DB.ViewPlan) or view.IsTemplate or view.ViewType == DB.ViewType.CeilingPlan:
    forms.alert(u"Hãy mở Floor Plan hoặc Structural Plan (không dùng Template / Ceiling Plan).", exitscript=True)

VO = view.Origin
VX = view.RightDirection
VY = view.UpDirection
VROT = round(math.degrees(math.atan2(VX.Y, VX.X)), 4)

def tv(p):
    d = p - VO
    return [round(d.DotProduct(VX) * FT_MM, 1), round(d.DotProduct(VY) * FT_MM, 1)]

def _pt_key(pt):
    return (round(pt[0], 1), round(pt[1], 1))

def _poly_area(pts):
    n = len(pts)
    if n < 3:
        return 0.0
    a = 0.0
    for i in range(n):
        j = (i + 1) % n
        a += pts[i][0] * pts[j][1] - pts[j][0] * pts[i][1]
    return abs(a) * 0.5

def _clean_loop(pts):
    res = []
    for p in pts:
        if not res or abs(p[0] - res[-1][0]) > 0.5 or abs(p[1] - res[-1][1]) > 0.5:
            res.append(p)
    if len(res) > 2 and abs(res[0][0] - res[-1][0]) <= 0.5 and abs(res[0][1] - res[-1][1]) <= 0.5:
        res.pop()
    return res

def _extract_loops_2d(face):
    loops = []
    try:
        for cl in face.GetEdgesAsCurveLoops():
            pts = []
            for crv in cl:
                tess = crv.Tessellate()
                for k, p in enumerate(tess):
                    if k == len(tess) - 1:
                        continue
                    pts.append(tv(p))
            pts = _clean_loop(pts)
            if len(pts) >= 3:
                loops.append((_poly_area(pts), pts))
    except Exception:
        pass
    loops.sort(key=lambda t: t[0], reverse=True)
    return [p for _, p in loops]

# ─── 1. SLABS ─────────────────────────────────────────────────────────────────
sel_ids = list(uidoc.Selection.GetElementIds())
floors = []
for eid in sel_ids:
    el = doc.GetElement(eid)
    if el and el.Category and el.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_Floors):
        floors.append(el)
if not floors:
    floors = list(
        DB.FilteredElementCollector(doc, view.Id)
        .OfCategory(DB.BuiltInCategory.OST_Floors)
        .WhereElementIsNotElementType()
        .ToElements()
    )
if not floors:
    forms.alert(u"Không tìm thấy sàn (Floor) nào trong View.", exitscript=True)

slabs = []
s_xmin, s_ymin, s_xmax, s_ymax = 1e18, 1e18, -1e18, -1e18
for fl in floors:
    try:
        refs = DB.HostObjectUtils.GetTopFaces(fl)
    except Exception:
        refs = []
    if not refs:
        continue
    all_loops = []
    z_vals = []
    for r in refs:
        f = fl.GetGeometryObjectFromReference(r)
        if not f:
            continue
        all_loops.extend(_extract_loops_2d(f))
        try:
            for e in f.EdgeLoops:
                for edge in e:
                    for p in edge.Tessellate():
                        z_vals.append(p.Z * FT_MM)
        except Exception:
            pass
    if not all_loops:
        continue
    all_loops.sort(key=_poly_area, reverse=True)
    outer = all_loops[0]
    holes = [h for h in all_loops[1:] if _poly_area(h) > 100.0]
    for p in outer:
        s_xmin = min(s_xmin, p[0]); s_ymin = min(s_ymin, p[1])
        s_xmax = max(s_xmax, p[0]); s_ymax = max(s_ymax, p[1])
    thick = 120.0
    try:
        tp = fl.get_Parameter(DB.BuiltInParameter.FLOOR_ATTR_THICKNESS_PARAM)
        if tp and tp.HasValue:
            thick = round(tp.AsDouble() * FT_MM, 1)
    except Exception:
        pass
    top_mm = round(sum(z_vals) / len(z_vals), 1) if z_vals else 0.0
    z_rng = round(max(z_vals) - min(z_vals), 1) if z_vals else 0.0
    try:
        lvl = doc.GetElement(fl.LevelId).Name if fl.LevelId != DB.ElementId.InvalidElementId else ""
    except Exception:
        lvl = ""
    slabs.append({
        "id": fl.Id.IntegerValue,
        "name": fl.Name,
        "level": lvl,
        "thick": thick,
        "top": top_mm,
        "z_range": z_rng,
        "outer": outer,
        "holes": holes,
    })

if not slabs:
    forms.alert(u"Không trích xuất được biên dạng mặt trên sàn.", exitscript=True)

# ─── 2. GRIDS ─────────────────────────────────────────────────────────────────
grids = []
for g in DB.FilteredElementCollector(doc, view.Id).OfCategory(DB.BuiltInCategory.OST_Grids).WhereElementIsNotElementType():
    crv = None
    try:
        crvs = g.GetCurvesInView(DB.DatumExtentType.ViewSpecific, view)
        if crvs and len(crvs) > 0:
            crv = crvs[0]
    except Exception:
        pass
    if crv is None:
        crv = g.Curve
    if isinstance(crv, DB.Line):
        p0 = tv(crv.GetEndPoint(0))
        p1 = tv(crv.GetEndPoint(1))
        grids.append({"name": g.Name, "p0": p0, "p1": p1})

# ─── 3. BEAMS & COLUMNS (within slab bbox + 1000mm) ──────────────────────────
MG = 1000.0
bx0, by0, bx1, by1 = s_xmin - MG, s_ymin - MG, s_xmax + MG, s_ymax + MG

def _elem_solid_geom(el, opts):
    ge = el.get_Geometry(opts)
    if not ge:
        return [], None, None
    polys = []
    zbots, ztops = [], []
    stack = list(ge)
    while stack:
        obj = stack.pop()
        if isinstance(obj, DB.GeometryInstance):
            ig = obj.GetInstanceGeometry()
            if ig:
                stack.extend(list(ig))
        elif isinstance(obj, DB.Solid) and obj.Volume > 1e-6:
            for face in obj.Faces:
                if not isinstance(face, DB.PlanarFace):
                    continue
                nz = face.FaceNormal.Z
                if nz < -0.99:
                    loops = _extract_loops_2d(face)
                    for lp in loops:
                        if _poly_area(lp) > 500.0:
                            polys.append(lp)
                            zbots.append(face.Origin.Z * FT_MM)
                elif nz > 0.99:
                    ztops.append(face.Origin.Z * FT_MM)
    z_bot = round(min(zbots), 1) if zbots else None
    z_top = round(max(ztops), 1) if ztops else None
    return polys, z_bot, z_top

def _in_bbox(polys):
    for lp in polys:
        for p in lp:
            if bx0 <= p[0] <= bx1 and by0 <= p[1] <= by1:
                return True
    return False

opts = DB.Options()
opts.DetailLevel = DB.ViewDetailLevel.Medium
opts.ComputeReferences = False

beams = []
for bm in DB.FilteredElementCollector(doc, view.Id).OfCategory(DB.BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType():
    polys, zbot, ztop = _elem_solid_geom(bm, opts)
    if not polys or not _in_bbox(polys):
        continue
    beams.append({"id": bm.Id.IntegerValue, "name": bm.Name, "z_top": ztop, "z_bot": zbot, "polys": polys})

columns = []
for col in DB.FilteredElementCollector(doc, view.Id).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType():
    polys, zbot, ztop = _elem_solid_geom(col, opts)
    if not polys or not _in_bbox(polys):
        continue
    columns.append({"id": col.Id.IntegerValue, "name": col.Name, "z_top": ztop, "z_bot": zbot, "polys": polys})

# ─── 4. PICK REFERENCE POINTS IN REVIT (Revit -> CAD trực tiếp) ─────────────
pick_pts = []
td = UI.TaskDialog(u"Triển khai Thép Sàn -> AutoCAD")
td.MainInstruction = u"Chọn cách xuất sang AutoCAD"
td.MainContent = (
    u"View: {0} | Tỉ lệ Revit: 1/{1}\n"
    u"Đã quét {2} sàn, {3} dầm, {4} cột, {5} trục lưới."
).format(view.Name, int(view.Scale or 100), len(slabs), len(beams), len(columns), len(grids))
td.AddCommandLink(UI.TaskDialogCommandLinkId.CommandLink1, u"Mở bảng thiết lập + Pick 1 điểm Revit → CAD (Chỉnh Ø, khoảng rải, lỗ mở, số lượng... rồi xuất)")
td.AddCommandLink(UI.TaskDialogCommandLinkId.CommandLink2, u"Mở bảng thiết lập + Pick 2 điểm Revit → CAD (Mặt bằng xoay góc)")
td.AddCommandLink(UI.TaskDialogCommandLinkId.CommandLink3, u"Xuất nhanh sang CAD bỏ qua bảng thiết lập (Pick 1 điểm, dùng thông số đã lưu)")
res = td.Show()

n_pick = 1
direct_mode = False
if res == UI.TaskDialogResult.CommandLink1:
    n_pick = 1
    direct_mode = False
elif res == UI.TaskDialogResult.CommandLink2:
    n_pick = 2
    direct_mode = False
elif res == UI.TaskDialogResult.CommandLink3:
    n_pick = 1
    direct_mode = True
else:
    n_pick = 0
    direct_mode = False

if n_pick > 0:
    sp_created = False
    if view.SketchPlane is None:
        t = DB.Transaction(doc, "Temp SketchPlane for Pick")
        t.Start()
        try:
            plane = DB.Plane.CreateByNormalAndOrigin(view.ViewDirection, view.Origin)
            view.SketchPlane = DB.SketchPlane.Create(doc, plane)
            t.Commit()
            sp_created = True
        except Exception:
            if t.HasStarted():
                t.RollBack()
    try:
        snaps = (
            UI.Selection.ObjectSnapTypes.Endpoints
            | UI.Selection.ObjectSnapTypes.Intersections
            | UI.Selection.ObjectSnapTypes.Midpoints
            | UI.Selection.ObjectSnapTypes.Nearest
        )
        p1 = uidoc.Selection.PickPoint(snaps, u"Pick điểm mốc số 1 trong Revit (Esc để bỏ qua)")
        pick_pts.append(tv(p1))
        if n_pick == 2:
            p2 = uidoc.Selection.PickPoint(snaps, u"Pick điểm mốc số 2 trong Revit (hướng trục X)")
            pick_pts.append(tv(p2))
    except Exception:
        pass

# ─── 5. EXPORT JSON ───────────────────────────────────────────────────────────
out_dir = os.path.join(os.path.expanduser("~"), "ThepSan_json")
if not os.path.isdir(out_dir):
    os.makedirs(out_dir)

safe_name = re.sub(r'[\\/:*?"<>|]+', '_', view.Name).strip() or "view"
json_path = os.path.join(out_dir, "thep_san_{0}.json".format(safe_name))

view_title = ""
try:
    p_title = view.get_Parameter(DB.BuiltInParameter.VIEW_DESCRIPTION)
    if p_title and p_title.HasValue:
        view_title = p_title.AsString() or ""
except Exception:
    pass

data = {
    "version": 2,
    "unit": "mm",
    "view": {
        "name": view.Name,
        "title": view_title or view.Name,
        "scale": int(view.Scale or 100),
        "rotation_deg": VROT,
    },
    "pick_pts": pick_pts,
    "grids": grids,
    "slabs": slabs,
    "beams": beams,
    "columns": columns,
}

with open(json_path, "wb") as f:
    f.write(json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"))

# ─── 6. LAUNCH VIEWER ─────────────────────────────────────────────────────────
viewer_py = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ThepSan_CAD.py")
if not os.path.isfile(viewer_py):
    forms.alert(
        u"Đã xuất JSON từ Revit:\n{0}\n\nKhông tìm thấy file ThepSan_CAD.py cùng thư mục với script.py!\n"
        u"Hãy chép cả 2 file (script.py + ThepSan_CAD.py) vào cùng thư mục .pushbutton.".format(json_path)
    )
else:
    def _is_valid_python(exe_path):
        try:
            if "WindowsApps" in exe_path:
                return False
            p = subprocess.Popen([exe_path, "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            txt = (out or b"") + (err or b"")
            return p.returncode == 0 and b"Python " in txt
        except Exception:
            return False

    py_exe = None
    for cand in ["python", "python3", "py"]:
        if _is_valid_python(cand):
            py_exe = cand
            break
    if not py_exe:
        local = os.environ.get("LOCALAPPDATA", "")
        prog = os.environ.get("ProgramFiles", "C:\\Program Files")
        home = os.path.expanduser("~")
        roots = [
            os.path.join(local, "Programs", "Python"),
            os.path.join(prog, "Python312"),
            os.path.join(prog, "Python311"),
            os.path.join(prog, "Python310"),
            os.path.join(home, "anaconda3"),
            os.path.join(home, "miniconda3"),
            "C:\\Python312", "C:\\Python311", "C:\\Python310", "C:\\Python39",
        ]
        for root in roots:
            if not os.path.isdir(root):
                continue
            exe2 = os.path.join(root, "python.exe")
            if os.path.isfile(exe2) and _is_valid_python(exe2):
                py_exe = exe2
                break
            try:
                for sub in sorted(os.listdir(root), reverse=True):
                    exe = os.path.join(root, sub, "python.exe")
                    if os.path.isfile(exe) and _is_valid_python(exe):
                        py_exe = exe
                        break
            except Exception:
                pass
            if py_exe:
                break

    if py_exe:
        import time as _time
        err_log = os.path.join(out_dir, "thepsan_cad_error.log")
        flags = 0x08000000 if os.name == "nt" else 0
        try:
            ef = open(err_log, "wb")
            cmd_args = [py_exe, viewer_py, json_path]
            if direct_mode and pick_pts:
                cmd_args.append("--direct")
            proc = subprocess.Popen(cmd_args, stderr=ef, creationflags=flags)
            _time.sleep(0.8)
            rc = proc.poll()
            if rc is not None and rc != 0:
                ef.close()
                msg = ""
                try:
                    with open(err_log, "rb") as rf:
                        msg = rf.read().decode("utf-8", errors="ignore")[-800:]
                except Exception:
                    pass
                forms.alert(
                    u"Đã xuất JSON:\n{0}\n\nLỗi khi mở ThepSan_CAD.py (code {1}):\n{2}".format(json_path, rc, msg)
                )
        except Exception as _ex:
            forms.alert(u"Đã xuất JSON:\n{0}\nKhông mở được ThepSan_CAD.py: {1}".format(json_path, _ex))
    else:
        forms.alert(
            u"Đã xuất JSON:\n{0}\n\nKhông tìm thấy Python 3 trên máy (bỏ qua stub Windows Store).\n"
            u"Hãy cài Python 3 + pip install pywin32, hoặc nạp file JSON này trực tiếp lên ứng dụng Web để xuất .DXF.".format(json_path)
        )
